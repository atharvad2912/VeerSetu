import React, { useState, useEffect } from 'react';
import { UserProfile, SchemeOrExam, Language, UserCategory } from './types';
import { INITIAL_SCHEMES_AND_EXAMS, OFFICIAL_NOTICES } from './data/schemesAndExams';
import { Navbar } from './components/Navbar';
import { SplashScreen } from './components/SplashScreen';
import { OnboardingModal } from './components/OnboardingModal';
import { AuthModal } from './components/AuthModal';
import { DashboardView } from './components/DashboardView';
import { SearchView } from './components/SearchView';
import { SavedView } from './components/SavedView';
import { NotificationsView } from './components/NotificationsView';
import { ProfileForm } from './components/ProfileForm';
import { SchemeDetailModal } from './components/SchemeDetailModal';
import { AdminCmsModal } from './components/AdminCmsModal';
import { Footer } from './components/Footer';

// Initial demo user (Serving soldier preset so the app feels rich immediately upon entry)
const DEFAULT_USER: UserProfile = {
  id: 'veersetu_user_1',
  fullName: 'Havildar Rajesh Kumar',
  mobile: '9876543210',
  email: 'rajesh.kumar@example.com',
  dob: '1996-06-15',
  gender: 'Male',
  state: 'Rajasthan',
  district: 'Jhunjhunu',
  category: 'serving',
  savedSchemeIds: ['serving-cea', 'serving-agif-cover', 'serving-csd'],
  savedExamIds: [],
  notificationPreferences: {
    recruitment: true,
    scholarships: true,
    schemeUpdates: true
  },
  servingDetails: {
    rank: 'Havildar',
    serviceCategory: 'Other Ranks / Agniveer',
    dateOfJoining: '2015-03-20',
    dateOfBirth: '1996-06-15',
    postingState: 'Rajasthan',
    maritalStatus: 'Married',
    spouseName: 'Sunita',
    childrenCount: 2,
    childrenAges: [8, 5],
    educationLevel: '12th Pass',
    hasDisability: false,
    isBattleCasualty: false
  }
};

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    return (localStorage.getItem('veersetu_lang') as Language) || 'en';
  });

  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [selectedSchemeForDetail, setSelectedSchemeForDetail] = useState<SchemeOrExam | null>(null);

  const [activeView, setActiveView] = useState<'home' | 'search' | 'saved' | 'notices' | 'profile'>('home');
  const [searchInitialQuery, setSearchInitialQuery] = useState<string>('');

  // Persistent User state
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('veersetu_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_USER;
      }
    }
    return DEFAULT_USER;
  });

  // Persistent Schemes & Exams (CMS enabled)
  const [schemes, setSchemes] = useState<SchemeOrExam[]>(() => {
    const saved = localStorage.getItem('veersetu_schemes');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_SCHEMES_AND_EXAMS;
      }
    }
    return INITIAL_SCHEMES_AND_EXAMS;
  });

  // Notices
  const [notices] = useState(OFFICIAL_NOTICES);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('veersetu_lang', lang);
  }, [lang]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('veersetu_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('veersetu_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('veersetu_schemes', JSON.stringify(schemes));
  }, [schemes]);

  // Handle splash completion
  const handleSplashComplete = () => {
    setShowSplash(false);
    const hasSeenOnboarding = localStorage.getItem('veersetu_has_onboarded');
    if (!hasSeenOnboarding) {
      setShowOnboarding(true);
    }
  };

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
    localStorage.setItem('veersetu_has_onboarded', 'true');
  };

  // Toggle bookmark / save
  const handleToggleSave = (id: string, isExam: boolean) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }

    if (isExam) {
      const isAlreadySaved = user.savedExamIds.includes(id);
      const updatedExamIds = isAlreadySaved
        ? user.savedExamIds.filter((eId) => eId !== id)
        : [...user.savedExamIds, id];

      setUser({
        ...user,
        savedExamIds: updatedExamIds
      });
    } else {
      const isAlreadySaved = user.savedSchemeIds.includes(id);
      const updatedSchemeIds = isAlreadySaved
        ? user.savedSchemeIds.filter((sId) => sId !== id)
        : [...user.savedSchemeIds, id];

      setUser({
        ...user,
        savedSchemeIds: updatedSchemeIds
      });
    }
  };

  // Change category
  const handleSelectCategory = (category: UserCategory) => {
    if (user) {
      setUser({
        ...user,
        category
      });
    } else {
      // Create guest profile with this category
      const guest: UserProfile = {
        id: 'guest_' + Date.now(),
        fullName: category === 'candidate' ? 'Aman Candidate' : 'Veer User',
        mobile: '9999999999',
        dob: category === 'candidate' ? '2008-01-15' : '1990-01-01',
        gender: 'Male',
        state: 'Rajasthan',
        district: 'Jaipur',
        category,
        savedSchemeIds: [],
        savedExamIds: [],
        notificationPreferences: { recruitment: true, scholarships: true, schemeUpdates: true }
      };
      setUser(guest);
    }
  };

  // Quick search jump from home
  const handleQuickSearch = (query: string) => {
    setSearchInitialQuery(query);
    setActiveView('search');
  };

  const savedCount = user ? user.savedSchemeIds.length + user.savedExamIds.length : 0;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased selection:bg-amber-100 selection:text-amber-900">
      {/* 1. SPLASH SCREEN */}
      {showSplash && (
        <SplashScreen onComplete={handleSplashComplete} lang={lang} />
      )}

      {/* 2. ONBOARDING MODAL */}
      {showOnboarding && (
        <OnboardingModal onComplete={handleOnboardingComplete} lang={lang} />
      )}

      {/* 3. AUTH MODAL */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLoginSuccess={(loggedInUser) => {
          setUser(loggedInUser);
        }}
        lang={lang}
      />

      {/* 4. ADMIN CMS MODAL */}
      <AdminCmsModal
        isOpen={showAdminModal}
        onClose={() => setShowAdminModal(false)}
        schemes={schemes}
        onUpdateSchemes={(updated) => setSchemes(updated)}
        lang={lang}
      />

      {/* 5. SCHEME / EXAM DETAIL MODAL */}
      <SchemeDetailModal
        scheme={selectedSchemeForDetail}
        onClose={() => setSelectedSchemeForDetail(null)}
        user={user}
        onToggleSave={handleToggleSave}
        isSaved={
          selectedSchemeForDetail
            ? user
              ? selectedSchemeForDetail.isExam
                ? user.savedExamIds.includes(selectedSchemeForDetail.id)
                : user.savedSchemeIds.includes(selectedSchemeForDetail.id)
              : false
            : false
        }
        lang={lang}
      />

      {/* TOP NAVIGATION BAR */}
      <Navbar
        user={user}
        onOpenAuth={() => setShowAuthModal(true)}
        onLogout={() => setUser(null)}
        onOpenProfile={() => setActiveView('profile')}
        onOpenAdmin={() => setShowAdminModal(true)}
        lang={lang}
        onSelectLang={(l) => setLang(l)}
        activeView={activeView}
        onChangeView={(view) => setActiveView(view)}
        savedCount={savedCount}
      />

      {/* MAIN VIEWPORT CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {activeView === 'home' && (
          <DashboardView
            user={user}
            schemes={schemes}
            onOpenDetails={(s) => setSelectedSchemeForDetail(s)}
            onToggleSave={handleToggleSave}
            onSelectCategory={handleSelectCategory}
            onOpenAuth={() => setShowAuthModal(true)}
            onOpenProfile={() => setActiveView('profile')}
            onQuickSearch={handleQuickSearch}
            lang={lang}
          />
        )}

        {activeView === 'search' && (
          <SearchView
            schemes={schemes}
            user={user}
            initialQuery={searchInitialQuery}
            onOpenDetails={(s) => setSelectedSchemeForDetail(s)}
            onToggleSave={handleToggleSave}
            lang={lang}
          />
        )}

        {activeView === 'saved' && (
          <SavedView
            user={user}
            schemes={schemes}
            onOpenDetails={(s) => setSelectedSchemeForDetail(s)}
            onToggleSave={handleToggleSave}
            onOpenAuth={() => setShowAuthModal(true)}
            lang={lang}
          />
        )}

        {activeView === 'notices' && (
          <NotificationsView notices={notices} lang={lang} />
        )}

        {activeView === 'profile' && user && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <button
                onClick={() => setActiveView('home')}
                className="text-xs font-semibold text-blue-900 hover:underline cursor-pointer flex items-center gap-1"
              >
                ← Back to Dashboard
              </button>
            </div>
            <ProfileForm
              user={user}
              onSave={(updated) => setUser(updated)}
              lang={lang}
            />
          </div>
        )}

        {activeView === 'profile' && !user && (
          <div className="text-center py-20 space-y-4">
            <h2 className="text-xl font-bold">Please sign in to view your profile</h2>
            <button
              onClick={() => setShowAuthModal(true)}
              className="py-2.5 px-6 rounded-xl bg-blue-900 text-white font-semibold text-xs"
            >
              Sign In / Register
            </button>
          </div>
        )}
      </main>

      {/* FOOTER */}
      <Footer
        lang={lang}
        onSelectCategory={handleSelectCategory}
        onOpenAdmin={() => setShowAdminModal(true)}
      />
    </div>
  );
}
