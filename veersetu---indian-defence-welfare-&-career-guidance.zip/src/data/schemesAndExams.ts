import { SchemeOrExam, OfficialNotification } from '../types';

export const INITIAL_SCHEMES_AND_EXAMS: SchemeOrExam[] = [
  // ==========================================
  // SECTION C — ASPIRING CANDIDATE (EXAMS ONLY)
  // ==========================================
  {
    id: 'exam-nda',
    name: 'National Defence Academy (NDA & NA) Examination',
    nameHindi: 'राष्ट्रीय रक्षा अकादमी (एनडीए एवं एनए) परीक्षा',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Unmarried Male & Female candidates aged 16.5 to 19.5 years who have passed or are appearing in Class 12',
    targetAudienceHindi: '16.5 से 19.5 वर्ष के अविवाहित पुरुष एवं महिला अभ्यर्थी जिन्होंने 12वीं उत्तीर्ण की हो या उपस्थित हो रहे हों',
    potentialBenefit: 'Permanent Commission in the Indian Army as a Commissioned Officer (Lieutenant) with degree from JNU & full military training stipend',
    potentialBenefitHindi: 'जेएनयू डिग्री एवं पूर्ण सैन्य प्रशिक्षण वजीफे के साथ भारतीय सेना में लेफ्टिनेंट पद पर स्थायी कमीशन',
    rules: {
      minAge: 16.5,
      maxAge: 19.5,
      beneficiaryTypes: ['candidate'],
      genders: ['Male', 'Female'],
      requiredStream: ['PCM', 'PCB', 'Commerce', 'Arts'], // Army wing accepts all streams
    },
    eligibilityDescription: 'Army Wing: 12th Class pass of 10+2 pattern of School Education or equivalent examination. Air Force and Naval Wings require Physics, Chemistry & Mathematics.',
    eligibilityDescriptionHindi: 'सेना विंग: 10+2 पैटर्न के तहत 12वीं कक्षा उत्तीर्ण। वायु सेना और नौसेना विंग के लिए भौतिकी, रसायन और गणित आवश्यक है।',
    requiredDocuments: [
      'Class 10 Matriculation Certificate (for Date of Birth proof)',
      'Class 12 Passing Certificate / Marksheet or School Bonafide Certificate',
      'Government Photo ID (Aadhaar Card, Voter ID, or Passport)',
      'Recent Passport-sized Photographs (as per UPSC guidelines)'
    ],
    requiredDocumentsHindi: [
      'कक्षा 10वीं का प्रमाण पत्र (जन्म तिथि प्रमाण हेतु)',
      'कक्षा 12वीं उत्तीर्ण प्रमाण पत्र / अंकतालिका',
      'सरकारी फोटो पहचान पत्र (आधार कार्ड/पासपोर्ट)',
      'हालिया पासपोर्ट आकार की तस्वीरें'
    ],
    howToApplySteps: [
      'Visit the official UPSC One-Time Registration (OTR) portal (upsconline.nic.in)',
      'Complete your OTR profile and navigate to the active NDA & NA Examination link',
      'Fill in personal, educational preferences (Army/Navy/Air Force), and examination centre',
      'Pay the application fee (exempted for Female/SC/ST candidates) and submit the final application'
    ],
    howToApplyStepsHindi: [
      'यूपीएससी वन-टाइम रजिस्ट्रेशन (OTR) पोर्टल (upsconline.nic.in) पर जाएं',
      'अपनी OTR प्रोफ़ाइल पूरी करें और सक्रिय एनडीए परीक्षा लिंक पर जाएं',
      'व्यक्तिगत जानकारी, विंग वरीयता और परीक्षा केंद्र चुनें',
      'आवेदन शुल्क का भुगतान कर अंतिम आवेदन जमा करें (महिला/एससी/एसटी अभ्यर्थियों हेतु निशुल्क)'
    ],
    officialSource: {
      name: 'Union Public Service Commission (UPSC)',
      url: 'https://upsc.gov.in',
      department: 'Ministry of Personnel, Public Grievances and Pensions'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: '3 years at NDA Khadakwasla, Pune + 1 year at IMA Dehradun.',
    applicationDeadlineNotice: 'Conducted twice a year (NDA-I around April, NDA-II around September). Verify official notification.'
  },
  {
    id: 'exam-tes',
    name: '10+2 Technical Entry Scheme (TES)',
    nameHindi: '10+2 तकनीकी प्रवेश योजना (टीईएस)',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Unmarried candidates who passed 10+2 with Physics, Chemistry & Maths (min 60%) and appeared in JEE (Mains)',
    targetAudienceHindi: '10+2 में भौतिकी, रसायन और गणित (न्यूनतम 60%) के साथ उत्तीर्ण एवं जेईई मेन्स में उपस्थित अभ्यर्थी',
    potentialBenefit: 'Direct SSB interview call, 4-year Engineering Degree (B.Tech) sponsored by Indian Army & Permanent Commission as Lieutenant',
    potentialBenefitHindi: 'सीधे एसएसबी इंटरव्यू, सेना द्वारा प्रायोजित 4 वर्षीय बी.टेक इंजीनियरिंग एवं लेफ्टिनेंट पद पर स्थायी कमीशन',
    rules: {
      minAge: 16.5,
      maxAge: 19.5,
      beneficiaryTypes: ['candidate'],
      min12thPercentage: 60,
      requiredStream: ['PCM'],
      requiresJEE: true
    },
    eligibilityDescription: 'Passed 10+2 or its equivalent with a minimum aggregate of 60% marks in Physics, Chemistry and Mathematics from recognized education boards, and appeared in JEE (Mains) of the respective year.',
    eligibilityDescriptionHindi: 'मान्यता प्राप्त बोर्ड से भौतिकी, रसायन और गणित में कुल 60% अंकों के साथ 10+2 उत्तीर्ण तथा संबंधित वर्ष की जेईई (मेन्स) परीक्षा में उपस्थित हुए हों।',
    requiredDocuments: [
      'Class 10 Certificate for Date of Birth proof',
      'Class 12 Marksheet showing PCM aggregate of 60% or higher',
      'JEE (Mains) Scorecard / Admit Card',
      'Aadhaar Card / Valid Identity Document'
    ],
    requiredDocumentsHindi: [
      'जन्म तिथि प्रमाण के लिए 10वीं का प्रमाण पत्र',
      'पीसीएम में न्यूनतम 60% अंक दर्शाने वाली 12वीं की अंकतालिका',
      'जेईई (मेन्स) स्कोरकार्ड',
      'आधार कार्ड / पहचान प्रमाण'
    ],
    howToApplySteps: [
      'Register on Join Indian Army official website (joinindianarmy.nic.in)',
      'Click on Officers Selection and select 10+2 Technical Entry Scheme',
      'Enter Class 12 PCM marks and JEE (Mains) Application Number & Roll Number',
      'Submit the form and download the Application Confirmation for SSB call letter'
    ],
    howToApplyStepsHindi: [
      'ज्वाइन इंडियन आर्मी की आधिकारिक वेबसाइट (joinindianarmy.nic.in) पर पंजीकरण करें',
      'अधिकारी चयन में 10+2 टेक्निकल एंट्री स्कीम चुनें',
      '12वीं के पीसीएम अंक और जेईई मेन्स का रोल नंबर दर्ज करें',
      'फॉर्म जमा करें और एसएसबी कॉल लेटर हेतु पुष्टिकरण प्रति डाउनलोड करें'
    ],
    officialSource: {
      name: 'Directorate General of Recruiting, Indian Army',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: 'Total training: 4 years (1 year Basic Military Training at CME Pune / MCTE Mhow + 3 years Technical Training).',
    applicationDeadlineNotice: 'TES notifications are released biannually (typically May-June and October-November).'
  },
  {
    id: 'exam-cds',
    name: 'Combined Defence Services (CDS) Examination',
    nameHindi: 'संयुक्त रक्षा सेवा (सीडीएस) परीक्षा',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Graduates (or final year students) aged 19 to 25 years aiming for IMA, OTA, INA, or AFA',
    targetAudienceHindi: '19 से 25 वर्ष के स्नातक (या अंतिम वर्ष के छात्र) जो आईएमए, ओटीए, आईएनए या एएफए में शामिल होना चाहते हैं',
    potentialBenefit: 'Direct Entry to Indian Military Academy (IMA) or Officers Training Academy (OTA Chennai) as Commissioned Officer',
    potentialBenefitHindi: 'कमीशन अधिकारी के रूप में भारतीय सैन्य अकादमी (आईएमए) या अधिकारी प्रशिक्षण अकादमी (ओटीए चेन्नई) में सीधा प्रवेश',
    rules: {
      minAge: 19,
      maxAge: 25,
      beneficiaryTypes: ['candidate'],
      requiresGraduation: true
    },
    eligibilityDescription: 'IMA / OTA: Degree of a recognized University or equivalent. For INA: Degree in Engineering. For AFA: Degree with Physics & Maths at 10+2 or Bachelor of Engineering. Unmarried candidates (or issueless widows/divorcees for OTA).',
    eligibilityDescriptionHindi: 'आईएमए/ओटीए हेतु: मान्यता प्राप्त विश्वविद्यालय से स्नातक। आईएनए हेतु इंजीनियरिंग डिग्री। वायु सेना अकादमी हेतु 12वीं में भौतिकी-गणित या बी.ई.।',
    requiredDocuments: [
      'Graduation Degree or Final Year Bonafide Student Certificate',
      'Class 10 & 12 Passing Certificates',
      'Valid Government Photo ID',
      'UPSC OTR Registration Credentials'
    ],
    requiredDocumentsHindi: [
      'स्नातक डिग्री या अंतिम वर्ष का बोनाफाइड प्रमाण पत्र',
      '10वीं एवं 12वीं के उत्तीर्ण प्रमाण पत्र',
      'वैध सरकारी फोटो पहचान पत्र',
      'यूपीएससी ओटीआर पंजीकरण विवरण'
    ],
    howToApplySteps: [
      'Log in to UPSC online portal (upsconline.nic.in)',
      'Select Combined Defence Services Examination (CDS I or CDS II)',
      'Choose academy preferences: IMA, OTA (Men/Women), INA, AFA',
      'Submit exam fee and verify exam venue choice'
    ],
    howToApplyStepsHindi: [
      'यूपीएससी पोर्टल (upsconline.nic.in) पर लॉग इन करें',
      'सीडीएस परीक्षा चुनें और अपनी अकादमी वरीयता भरें',
      'आवेदन शुल्क का भुगतान कर परीक्षा केंद्र चुनें',
      'अंतिम आवेदन पत्र डाउनलोड करें'
    ],
    officialSource: {
      name: 'Union Public Service Commission (UPSC)',
      url: 'https://upsc.gov.in',
      department: 'Ministry of Personnel, Public Grievances and Pensions'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: 'IMA: 18 months training. OTA: 49 weeks Short Service Commission training.',
    applicationDeadlineNotice: 'Conducted twice a year (CDS-I around February, CDS-II around September).'
  },
  {
    id: 'exam-ncc-special',
    name: 'NCC Special Entry Scheme (Men & Women)',
    nameHindi: 'एनसीसी विशेष प्रवेश योजना (पुरुष एवं महिला)',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Graduates with aggregate 50% marks holding NCC Senior Division/Wing "C" Certificate with minimum "B" grade',
    targetAudienceHindi: 'न्यूनतम 50% अंकों के साथ स्नातक तथा न्यूनतम "B" ग्रेड सहित एनसीसी "C" प्रमाणपत्र धारक',
    potentialBenefit: 'Direct SSB Interview (No written UPSC exam required) for Short Service Commission (SSC) at Officers Training Academy (OTA) Chennai',
    potentialBenefitHindi: 'अधिकारी प्रशिक्षण अकादमी (ओटीए) चेन्नई में शार्ट सर्विस कमीशन हेतु बिना लिखित परीक्षा सीधा एसएसबी साक्षात्कार',
    rules: {
      minAge: 19,
      maxAge: 25,
      beneficiaryTypes: ['candidate'],
      requiresGraduation: true,
      requiresNCC_C: true
    },
    eligibilityDescription: 'Degree of a recognized University or equivalent with aggregate minimum 50% marks taking into account marks of all years. Should have served for minimum two academic years in the Senior Division/Wing of NCC with "C" Certificate ("B" grade or higher).',
    eligibilityDescriptionHindi: 'मान्यता प्राप्त विश्वविद्यालय से न्यूनतम 50% अंकों के साथ स्नातक। एनसीसी सीनियर डिवीजन में न्यूनतम 2 वर्ष की सेवा और कम से कम "B" ग्रेड के साथ "C" सर्टिफिकेट।',
    requiredDocuments: [
      'NCC "C" Certificate (stating grade A or B)',
      'Graduation Degree / All Semester Marksheets with >= 50% marks',
      'Class 10 Matriculation Certificate',
      'Certificate of Service from NCC Group Commander / Directorate'
    ],
    requiredDocumentsHindi: [
      'एनसीसी "C" प्रमाणपत्र (ग्रेड A या B दर्शाने वाला)',
      'स्नातक डिग्री / 50% से अधिक अंकों की अंकतालिका',
      '10वीं का प्रमाण पत्र',
      'एनसीसी ग्रुप कमांडर से सेवा प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Register on Join Indian Army portal (joinindianarmy.nic.in)',
      'Navigate to Officers Selection -> NCC Special Entry',
      'Upload NCC "C" Certificate and Degree marksheets',
      'Shortlisted candidates directly receive dates for SSB interview'
    ],
    howToApplyStepsHindi: [
      'ज्वाइन इंडियन आर्मी पोर्टल (joinindianarmy.nic.in) पर जाएं',
      'अधिकारी चयन में एनसीसी स्पेशल एंट्री चुनें',
      'एनसीसी "C" सर्टिफिकेट और डिग्री अंकतालिका अपलोड करें',
      'शॉर्टलिस्टेड अभ्यर्थियों को सीधे एसएसबी की तारीखें आवंटित होंगी'
    ],
    officialSource: {
      name: 'Directorate General of Recruiting, Indian Army',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: '49 weeks of rigorous officer training at OTA Chennai.',
    applicationDeadlineNotice: 'Notifications released in January/February and July/August every year.'
  },
  {
    id: 'exam-ssc-tech',
    name: 'Short Service Commission Technical (SSC Tech Men & Women)',
    nameHindi: 'शॉर्ट सर्विस कमीशन तकनीकी (एसएससी टेक पुरुष एवं महिला)',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Engineering Degree holders or final year students in relevant engineering streams aged 20 to 27 years',
    targetAudienceHindi: 'संबंधित इंजीनियरिंग शाखा में 20 से 27 वर्ष के डिग्री धारक या अंतिम वर्ष के इंजीनियरिंग छात्र',
    potentialBenefit: 'Direct SSB Interview based on engineering cutoff percentage, Pre-Commission training at OTA Chennai & Commission as Lieutenant',
    potentialBenefitHindi: 'इंजीनियरिंग कट-ऑफ के आधार पर सीधा एसएसबी साक्षात्कार, ओटीए चेन्नई में प्रशिक्षण व लेफ्टिनेंट पद',
    rules: {
      minAge: 20,
      maxAge: 27,
      beneficiaryTypes: ['candidate'],
      requiresGraduation: true,
      allowedDegrees: ['B.Tech/B.E.']
    },
    eligibilityDescription: 'Candidates who have passed the requisite Engineering Degree course or are in the final year of Engineering course are eligible to apply. Streams include Civil, Computer Science, Mechanical, Electrical, Electronics, etc.',
    eligibilityDescriptionHindi: 'आवश्यक इंजीनियरिंग डिग्री उत्तीर्ण या अंतिम वर्ष में अध्ययनरत अभ्यर्थी पात्र हैं। सिविल, कंप्यूटर, मैकेनिकल, इलेक्ट्रिकल आदि शाखाएं शामिल हैं।',
    requiredDocuments: [
      'Engineering Degree Certificate or Provisional Degree',
      'Cumulative Semester Marksheets up to the 6th / 8th semester',
      'Class 10 Certificate for Date of Birth verification',
      'Equivalence certificate if applicable'
    ],
    requiredDocumentsHindi: [
      'इंजीनियरिंग डिग्री या प्रोविजनल सर्टिफिकेट',
      'सभी सेमेस्टर की अंकतालिकाएं',
      '10वीं का प्रमाण पत्र',
      'समकक्षता प्रमाण पत्र (यदि लागू हो)'
    ],
    howToApplySteps: [
      'Visit joinindianarmy.nic.in and log in to your Officer profile',
      'Select SSC (Tech) Men or SSC (Tech) Women entry',
      'Fill in discipline details and cumulative engineering percentage',
      'SSB centres are allotted based on cutoff criteria published by Army HQ'
    ],
    howToApplyStepsHindi: [
      'joinindianarmy.nic.in पर जाकर अपने प्रोफाइल में जाएं',
      'एसएससी (टेक) प्रविष्टि चुनें और अपनी शाखा के अंक दर्ज करें',
      'कटऑफ के आधार पर एसएसबी साक्षात्कार का बुलावा प्राप्त होगा'
    ],
    officialSource: {
      name: 'Directorate General of Recruiting, Indian Army',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: '49 weeks of Pre-Commission military and technical tactical training at OTA Chennai.'
  },
  {
    id: 'exam-tgc',
    name: 'Technical Graduate Course (TGC)',
    nameHindi: 'तकनीकी स्नातक पाठ्यक्रम (टीजीसी)',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Unmarried Male Engineering Graduates aged 20 to 27 years seeking Permanent Commission in the Indian Army',
    targetAudienceHindi: 'भारतीय सेना में स्थायी कमीशन चाहने वाले 20 से 27 वर्ष के अविवाहित पुरुष इंजीनियरिंग स्नातक',
    potentialBenefit: 'Permanent Commission in the Indian Army with training at Indian Military Academy (IMA) Dehradun and ante-date seniority',
    potentialBenefitHindi: 'आईएमए देहरादून में प्रशिक्षण के साथ स्थायी कमीशन और वरीयता लाभ',
    rules: {
      minAge: 20,
      maxAge: 27,
      beneficiaryTypes: ['candidate'],
      genders: ['Male'],
      requiresGraduation: true,
      allowedDegrees: ['B.Tech/B.E.']
    },
    eligibilityDescription: 'Candidates must hold a recognized Engineering Degree or be in the final year of Engineering. Granted Permanent Commission into Corps of Engineers, Signals, EME, and other arms.',
    eligibilityDescriptionHindi: 'अभ्यर्थी के पास इंजीनियरिंग डिग्री होनी चाहिए या वह अंतिम वर्ष में होना चाहिए। सेना के इंजीनियर्स, सिग्नल्स, ईएमई आदि कोर में स्थायी कमीशन।',
    requiredDocuments: [
      'B.Tech / B.E. Degree & all semester marksheets',
      'Class 10 Matriculation Certificate',
      'Declaration of final year completion before IMA term commencement'
    ],
    requiredDocumentsHindi: [
      'बी.टेक/बी.ई. डिग्री और अंकतालिकाएं',
      '10वीं का प्रमाण पत्र',
      'अंतिम वर्ष पूर्णता घोषणा पत्र'
    ],
    howToApplySteps: [
      'Apply online on joinindianarmy.nic.in during open notification window',
      'Select TGC Course and enter engineering discipline with semester percentages',
      'Download application summary and prepare for SSB Interview upon cutoff clearance'
    ],
    howToApplyStepsHindi: [
      'joinindianarmy.nic.in पर टीजीसी कोर्स के लिए आवेदन करें',
      'इंजीनियरिंग शाखा और प्रतिशत भरें',
      'कटऑफ पास होने पर एसएसबी इंटरव्यू में शामिल हों'
    ],
    officialSource: {
      name: 'Indian Army Recruiting Directorate',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: '1 year of military training at IMA Dehradun.'
  },
  {
    id: 'exam-jag',
    name: 'Judge Advocate General (JAG) Entry Scheme',
    nameHindi: 'जज एडवोकेट जनरल (जेएजी) प्रवेश योजना',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Law Graduates (LLB with min 55% marks) aged 21 to 27 years eligible for Bar Council of India registration and qualified in CLAT PG',
    targetAudienceHindi: '21 से 27 वर्ष के विधि स्नातक (न्यूनतम 55% अंक सहित एलएलबी) जो बार काउंसिल में पंजीकरण योग्य हों और क्लैट पीजी अर्हक हों',
    potentialBenefit: 'Commission as legal officer (Captain equivalent on training completion) in the Judge Advocate General branch',
    potentialBenefitHindi: 'जेएजी शाखा में सैन्य कानूनी अधिकारी के रूप में कमीशन',
    rules: {
      minAge: 21,
      maxAge: 27,
      beneficiaryTypes: ['candidate'],
      requiresGraduation: true,
      allowedDegrees: ['Law (LLB)']
    },
    eligibilityDescription: 'Minimum 55% aggregate marks in LLB Degree (3 years professional after graduation or 5 years after 10+2). Candidates must be eligible for registration as an advocate with Bar Council of India and have appeared in CLAT PG.',
    eligibilityDescriptionHindi: 'एलएलबी में न्यूनतम 55% कुल अंक। बार काउंसिल में अधिवक्ता के रूप में पंजीकरण की पात्रता और क्लैट पीजी परीक्षा।',
    requiredDocuments: [
      'LLB Degree Certificate and marksheet of all years/semesters',
      'College recognition certificate by Bar Council of India',
      'CLAT PG Scorecard',
      'Class 10 Matriculation Certificate'
    ],
    requiredDocumentsHindi: [
      'एलएलबी डिग्री और सभी सेमेस्टर के अंक',
      'बार काउंसिल ऑफ इंडिया से कॉलेज मान्यता प्रमाण पत्र',
      'क्लैट पीजी स्कोरकार्ड',
      '10वीं का प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Register on joinindianarmy.nic.in for JAG Entry Scheme',
      'Input LLB marks, Bar Council eligibility, and CLAT PG Roll Number',
      'Shortlisted candidates proceed directly to 5-day SSB interview at Selection Centres'
    ],
    howToApplyStepsHindi: [
      'joinindianarmy.nic.in पर जेएजी प्रविष्टि हेतु ऑनलाइन आवेदन करें',
      'एलएलबी अंक और क्लैट पीजी विवरण भरें',
      'शॉर्टलिस्टेड अभ्यर्थी 5 दिवसीय एसएसबी साक्षात्कार में शामिल होंगे'
    ],
    officialSource: {
      name: 'Judge Advocate General Branch / Recruiting Directorate',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: '49 weeks of Pre-Commission training at OTA Chennai.'
  },
  {
    id: 'exam-amc',
    name: 'Army Medical Corps (AMC) - Medical Officer Entry',
    nameHindi: 'आर्मी मेडिकल कोर (एएमसी) - चिकित्सा अधिकारी प्रविष्टि',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'MBBS/PG Degree holders aged up to 30 years (35 for PG) holding permanent State/NMC medical registration',
    targetAudienceHindi: '30 वर्ष तक के एमबीबीएस/पीजी डिग्री धारक जिनके पास स्थायी राज्य/एनएमसी चिकित्सा पंजीकरण हो',
    potentialBenefit: 'Direct Commission as Captain in the Army Medical Corps with high non-practicing allowance (NPA) and specialist PG deputations',
    potentialBenefitHindi: 'आर्मी मेडिकल कोर में कैप्टन पद पर सीधा कमीशन, एनपीए एवं विशेषज्ञता अध्ययन अवसर',
    rules: {
      minAge: 21,
      maxAge: 35,
      beneficiaryTypes: ['candidate'],
      requiresGraduation: true,
      allowedDegrees: ['MBBS']
    },
    eligibilityDescription: 'Must possess an MBBS degree from a college recognized by National Medical Commission (NMC). Must have completed compulsory rotatory internship and hold valid permanent registration.',
    eligibilityDescriptionHindi: 'एनएमसी से मान्यता प्राप्त कॉलेज से एमबीबीएस डिग्री तथा अनिवार्य इंटर्नशिप पूर्ण होनी चाहिए।',
    requiredDocuments: [
      'MBBS Degree & Final Professional Marksheet',
      'Compulsory Rotatory Internship Completion Certificate',
      'Permanent State Medical Council / NMC Registration Certificate',
      'Post-Graduate Degree / Diploma (if applicable)'
    ],
    requiredDocumentsHindi: [
      'एमबीबीएस डिग्री और अंतिम वर्ष की अंकतालिका',
      'अनिवार्य इंटर्नशिप पूर्णता प्रमाण पत्र',
      'एनएमसी/राज्य मेडिकल काउंसिल पंजीकरण प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Apply online on the Armed Forces Medical Services portal (amcsscentry.gov.in)',
      'Upload internship, degree, and medical council credentials',
      'Appear for the DGAFMS interview in New Delhi and subsequent Medical Board'
    ],
    howToApplyStepsHindi: [
      'amcsscentry.gov.in पोर्टल पर आवेदन करें',
      'दस्तावेज़ और मेडिकल काउंसिल पंजीकरण अपलोड करें',
      'नई दिल्ली में डीजीएएफएमएस साक्षात्कार और मेडिकल बोर्ड में उपस्थित हों'
    ],
    officialSource: {
      name: 'Directorate General Armed Forces Medical Services (DGAFMS)',
      url: 'https://amcsscentry.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: 'Short orientation course at AMC Centre & College, Lucknow.'
  },
  {
    id: 'exam-agniveer-gd',
    name: 'Agniveer General Duty (GD) Recruitment Rally',
    nameHindi: 'अग्निवीर जनरल ड्यूटी (जीडी) भर्ती रैली',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Candidates aged 17.5 to 21 years who passed Class 10th with minimum 45% aggregate and 33% in each subject',
    targetAudienceHindi: '17.5 से 21 वर्ष के अभ्यर्थी जिन्होंने कक्षा 10वीं न्यूनतम 45% कुल और प्रत्येक विषय में 33% के साथ उत्तीर्ण की हो',
    potentialBenefit: '4 years of service under Agnipath scheme, Seva Nidhi package (~Rs 11.71 Lakh), Rs 48 Lakh non-contributory life insurance, and eligibility for 25% permanent cadre enrollment',
    potentialBenefitHindi: 'अग्निपथ योजना के तहत 4 वर्ष सेवा, सेवा निधि पैकेज (~11.71 लाख रु.), 48 लाख रु. का जीवन बीमा एवं 25% स्थायी कैडर का अवसर',
    rules: {
      minAge: 17.5,
      maxAge: 21,
      beneficiaryTypes: ['candidate'],
    },
    eligibilityDescription: 'Class 10th / Matric with 45% marks in aggregate and 33% in each subject. For boards following grading system, minimum D grade (33-40) in individual subjects and equivalent of 45% in aggregate. Physical and Common Entrance Examination (CEE) mandatory.',
    eligibilityDescriptionHindi: '10वीं/मैट्रिक न्यूनतम 45% कुल और प्रत्येक विषय में 33% अंकों के साथ। शारीरिक दक्षता और ऑनलाइन संयुक्त प्रवेश परीक्षा (सीईई) अनिवार्य।',
    requiredDocuments: [
      'Class 10 Marksheet and Board Certificate',
      'Domicile / Nativity Certificate with photograph issued by Tehsildar / District Magistrate',
      'Caste Certificate and Character Certificate (from School/Gram Pradhan)',
      'Aadhaar Card linked with active mobile number'
    ],
    requiredDocumentsHindi: [
      '10वीं की अंकतालिका एवं प्रमाण पत्र',
      'तहसीलदार/जिलाधिकारी द्वारा जारी मूल निवास प्रमाण पत्र',
      'जाति प्रमाण पत्र एवं चरित्र प्रमाण पत्र',
      'मोबाइल से लिंक आधार कार्ड'
    ],
    howToApplySteps: [
      'Register on Join Indian Army website (joinindianarmy.nic.in) under "Agnipath" tab',
      'Check eligibility against your Zonal Recruiting Office (ZRO) notification',
      'Appear for Phase 1: Computer Based Online Common Entrance Exam (CEE)',
      'Shortlisted candidates appear for Phase 2: Physical Fitness Test (PFT: 1.6 Km run, beam pull-ups) & Medical'
    ],
    howToApplyStepsHindi: [
      'joinindianarmy.nic.in पर "अग्निपथ" टैब के अंतर्गत पंजीकरण करें',
      'अपने भर्ती कार्यालय (ZRO/ARO) की अधिसूचना के अनुसार आवेदन करें',
      'प्रथम चरण: कंप्यूटर आधारित ऑनलाइन सीईई परीक्षा दें',
      'द्वितीय चरण: शारीरिक दक्षता परीक्षा (1.6 किमी दौड़, बीम) और मेडिकल जांच'
    ],
    officialSource: {
      name: 'Indian Army Recruiting Directorate (Agnipath Scheme)',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    trainingDetails: '6 months training at Regimental Centres followed by 3.5 years active soldier deployment.'
  },
  {
    id: 'exam-agniveer-tech-clerk',
    name: 'Agniveer Technical / Clerk / Store Keeper / Tradesmen',
    nameHindi: 'अग्निवीर टेक्निकल / क्लर्क / स्टोर कीपर / ट्रेड्समैन',
    category: 'Recruitment',
    beneficiaryType: 'candidate',
    isExam: true,
    targetAudience: 'Candidates aged 17.5 to 21 years with 10+2 in Science (PCM) for Tech or Arts/Commerce/Science for Clerk (min 60% aggregate)',
    targetAudienceHindi: '17.5 से 21 वर्ष के अभ्यर्थी (टेक्निकल हेतु पीसीएम या क्लर्क हेतु 60% अंकों के साथ 12वीं उत्तीर्ण)',
    potentialBenefit: 'Specialist military trade placement, monthly salary with risk allowances, Seva Nidhi corpus, and technical skill certificates',
    potentialBenefitHindi: 'विशेषज्ञ सैन्य ट्रेड पद, मासिक वेतन एवं भत्ते, सेवा निधि और कौशल प्रमाण पत्र',
    rules: {
      minAge: 17.5,
      maxAge: 21,
      beneficiaryTypes: ['candidate'],
    },
    eligibilityDescription: 'Agniveer Tech: 10+2 Intermediate in Science with Physics, Chemistry, Maths and English with min 50% marks in aggregate and 40% in each subject. Clerk/SKT: 10+2 in any stream with 60% aggregate and 50% in English and Maths/Accounts.',
    eligibilityDescriptionHindi: 'टेक्निकल: भौतिकी, रसायन, गणित और अंग्रेजी के साथ 10+2 (न्यूनतम 50% कुल और 40% प्रत्येक विषय)। क्लर्क: 10+2 (न्यूनतम 60% कुल और अंग्रेजी-गणित में 50%)।',
    requiredDocuments: [
      'Class 10 and 12 Passing Certificates & Marksheets',
      'Aadhaar Card, Domicile, Caste & Character Certificates',
      'NCC or Sports Certificates (if claiming bonus marks)'
    ],
    requiredDocumentsHindi: [
      '10वीं एवं 12वीं की अंकतालिकाएं और प्रमाण पत्र',
      'आधार कार्ड, निवास प्रमाण पत्र, जाति प्रमाण पत्र',
      'एनसीसी या खेल प्रमाण पत्र (बोनस अंकों हेतु)'
    ],
    howToApplySteps: [
      'Log into joinindianarmy.nic.in and select Agnipath Technical/Clerk vacancy for your district',
      'Submit online application and take Online CEE',
      'Appear for rally physical and typing tests (for Clerk) at designated rally ground'
    ],
    howToApplyStepsHindi: [
      'joinindianarmy.nic.in पर अपने जिले की टेक्निकल/क्लर्क भर्ती चुनें',
      'ऑनलाइन आवेदन कर सीईई परीक्षा दें',
      'रैली मैदान पर शारीरिक दक्षता एवं टाइपिंग टेस्ट (क्लर्क हेतु) में उपस्थित हों'
    ],
    officialSource: {
      name: 'Indian Army Recruiting Directorate',
      url: 'https://joinindianarmy.nic.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },

  // ==========================================
  // SECTION A — CURRENTLY SERVING PERSONNEL
  // ==========================================
  {
    id: 'serving-cea',
    name: 'Children Education Allowance (CEA) & Hostel Subsidy (7th CPC)',
    nameHindi: 'बच्चों का शिक्षा भत्ता (सीईए) एवं छात्रावास अनुदान (7वां वेतन आयोग)',
    category: 'Children & Scholarships',
    beneficiaryType: 'serving',
    isExam: false,
    targetAudience: 'Currently serving Army personnel with school-going children (up to 2 eldest surviving children, nursery to Class 12)',
    targetAudienceHindi: 'स्कूली बच्चों वाले सेवारत सैन्य कर्मी (अधिकतम 2 सबसे बड़े जीवित बच्चे, नर्सरी से 12वीं तक)',
    potentialBenefit: 'CEA of Rs 2,250/- per month (Rs 27,000/- per child/year) + Hostel Subsidy of Rs 6,750/- per month (Rs 81,000/- per year). Rates rise by 25% when Dearness Allowance crosses 50%.',
    potentialBenefitHindi: 'प्रति बच्चा 2,250 रु. प्रतिमाह (27,000 रु. वार्षिक) तथा छात्रावास अनुदान 6,750 रु. प्रतिमाह (81,000 रु. वार्षिक)।',
    rules: {
      beneficiaryTypes: ['serving'],
    },
    eligibilityDescription: 'Reimbursement admissible for two eldest surviving children studying in recognized schools from two classes before class one to class twelve. Also double rates for differently-abled children.',
    eligibilityDescriptionHindi: 'मान्यता प्राप्त विद्यालय में कक्षा 1 से 2 कक्षा पूर्व (नर्सरी) से 12वीं तक अध्ययनरत दो ज्येष्ठ बच्चों हेतु। दिव्यांग बच्चों हेतु दोगुनी दर।',
    requiredDocuments: [
      'Bonafide Certificate from Head of Educational Institution',
      'Fee Receipts showing tuition fee, text books, uniform expenses',
      'Children details published in Unit Part II Order'
    ],
    requiredDocumentsHindi: [
      'शैक्षणिक संस्थान के प्रमुख द्वारा बोनाफाइड प्रमाण पत्र',
      'स्कूल फीस की रसीदें',
      'यूनिट पार्ट II आर्डर में दर्ज बच्चों का विवरण'
    ],
    howToApplySteps: [
      'Obtain bonafide certificate from school at the end of the academic year',
      'Submit claim in prescribed Contingent Bill format through your Unit Orderly Room / Adjutant Branch',
      'Claim processed and credited directly into your salary account via PCDA/PAO'
    ],
    howToApplyStepsHindi: [
      'सत्र समाप्ति पर स्कूल से बोनाफाइड सर्टिफिकेट प्राप्त करें',
      'यूनिट ऑर्डरली रूम के माध्यम से निर्धारित प्रारूप में दावा प्रस्तुत करें',
      'पीसीडीए/पीएओ द्वारा वेतन खाते में राशि स्थानांतरित की जाती है'
    ],
    officialSource: {
      name: 'Department of Personnel and Training / PCDA(O) Pune',
      url: 'https://pcdaopune.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'serving-agif-cover',
    name: 'Army Group Insurance Fund (AGIF) Comprehensive Cover',
    nameHindi: 'आर्मी ग्रुप इंश्योरेंस फंड (एजीआईएफ) व्यापक सुरक्षा',
    category: 'Insurance',
    beneficiaryType: 'serving',
    isExam: false,
    targetAudience: 'All active Officers, JCOs and Other Ranks in the Indian Army',
    targetAudienceHindi: 'भारतीय सेना के सभी सक्रिय अधिकारी, जेसीओ और अन्य रैंक',
    potentialBenefit: 'Officers: Life cover of Rs 1 Crore + Disability cover up to Rs 50 Lakh. JCOs/OR: Life cover of Rs 50 Lakh + Disability cover up to Rs 25 Lakh + Terminal savings maturity on release.',
    potentialBenefitHindi: 'अधिकारी: 1 करोड़ रु. जीवन बीमा + 50 लाख तक दिव्यांगता। जेसीओ/ओआर: 50 लाख रु. जीवन बीमा + 25 लाख तक दिव्यांगता व परिपक्वता बचत।',
    rules: {
      beneficiaryTypes: ['serving'],
    },
    eligibilityDescription: 'Compulsory contributory group insurance scheme covering death in service and physical disability attributable/aggravated by military service.',
    eligibilityDescriptionHindi: 'सेवारत सैन्य कर्मियों के लिए अनिवार्य अंशदायी समूह बीमा जो सेवा के दौरान मृत्यु एवं दिव्यांगता को कवर करता है।',
    requiredDocuments: [
      'AGIF Membership Card / Number',
      'Nomination details in Part II Order',
      'Medical Board proceedings (Invaliding / Release Medical Board for disability)'
    ],
    requiredDocumentsHindi: [
      'एजीआईएफ सदस्यता विवरण',
      'पार्ट II ऑर्डर में दर्ज नामांकन',
      'मेडिकल बोर्ड रिपोर्ट (दिव्यांगता हेतु)'
    ],
    howToApplySteps: [
      'Automatic monthly subscription deducted from pay by PAO(OR) / PCDA(O)',
      'Check nomination in service records periodically',
      'Disability or survival claims forwarded through Unit Adjutant to AGIF Directorate, Vasant Kunj, New Delhi'
    ],
    howToApplyStepsHindi: [
      'वेतन से स्वतः मासिक कटौती',
      'सेवा रिकॉर्ड में नामांकित व्यक्ति का नाम जांचें',
      'दावे यूनिट के माध्यम से एजीआईएफ मुख्यालय को अग्रेषित किए जाते हैं'
    ],
    officialSource: {
      name: 'Army Group Insurance Fund (AGIF)',
      url: 'https://agif.nic.in',
      department: 'Adjutant General Branch, Army Headquarters'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'serving-awho',
    name: 'Army Welfare Housing Organisation (AWHO) Housing Schemes',
    nameHindi: 'आर्मी वेलफेयर हाउसिंग ऑर्गनाइजेशन (एडब्ल्यूएचओ) आवास योजना',
    category: 'Housing',
    beneficiaryType: 'serving',
    isExam: false,
    targetAudience: 'Serving Army Personnel (and priority for Veer Naris and battle casualties)',
    targetAudienceHindi: 'सेवारत सैन्य कर्मी (तथा वीर नारियों और युद्ध हताहतों हेतु विशेष प्राथमिकता)',
    potentialBenefit: 'No-profit no-loss basis high quality residential flats/plots across major cities in India with flexible defence home loans and subsidised rates',
    potentialBenefitHindi: 'देश भर के प्रमुख शहरों में लागत मूल्य पर उच्च गुणवत्ता वाले फ्लैट/आवास एवं रक्षा आवास ऋण सुविधा',
    rules: {
      beneficiaryTypes: ['serving', 'veteran', 'shaheed_family'],
    },
    eligibilityDescription: 'Open to Army personnel who do not already own an AWHO dwelling unit, with seniority based on length of service and special priority for widows and battle casualties.',
    eligibilityDescriptionHindi: 'ऐसे सैन्य कर्मियों के लिए जिनके पास पहले से एडब्ल्यूएचओ आवास न हो। सेवा अवधि के आधार पर वरीयता।',
    requiredDocuments: [
      'Serving Certificate signed by Commanding Officer',
      'Aadhaar & PAN Card',
      'Part II Order regarding family composition',
      'Non-ownership affidavit'
    ],
    requiredDocumentsHindi: [
      'कमांडिंग ऑफिसर द्वारा हस्ताक्षरित सेवारत प्रमाण पत्र',
      'आधार व पैन कार्ड',
      'पारिवारिक विवरण का पार्ट II ऑर्डर'
    ],
    howToApplySteps: [
      'Visit awhosena.in to browse active and upcoming housing projects',
      'Apply online with designated booking token amount',
      'Seniority allotment conducted via computerised draw according to rules'
    ],
    howToApplyStepsHindi: [
      'awhosena.in पर सक्रिय व आगामी आवास योजनाएं देखें',
      'ऑनलाइन आवेदन कर टोकन राशि जमा करें',
      'नियमों के अनुसार कम्प्यूटरीकृत आवंटन'
    ],
    officialSource: {
      name: 'Army Welfare Housing Organisation (AWHO)',
      url: 'https://awhosena.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'serving-csd',
    name: 'Canteen Stores Department (CSD) Smart Card & AFD Four-Wheeler Scheme',
    nameHindi: 'कैंटीन स्टोर्स विभाग (सीएसडी) स्मार्ट कार्ड एवं वाहन रियायत योजना',
    category: 'CSD / Concessions',
    beneficiaryType: 'serving',
    isExam: false,
    targetAudience: 'Serving Army Personnel across Officers, JCOs and Other Ranks',
    targetAudienceHindi: 'सेवारत अधिकारी, जेसीओ और अन्य रैंक के सैन्य कर्मी',
    potentialBenefit: 'Tax-exempted concessional grocery/liquor canteen shopping + GST concession on purchase of four-wheelers and two-wheelers through AFD online portal',
    potentialBenefitHindi: 'रियायती दरों पर राशन व सामान तथा एएफडी पोर्टल के माध्यम से कार/बाइक खरीद पर 50% जीएसटी छूट',
    rules: {
      beneficiaryTypes: ['serving', 'veteran'],
    },
    eligibilityDescription: 'All serving personnel are entitled to individual Grocery & Liquor Smart Cards. Vehicle entitlement varies by pay level and service length.',
    eligibilityDescriptionHindi: 'सभी सेवारत कर्मी स्मार्ट कार्ड के पात्र हैं। वाहन खरीद की पात्रता पे-लेवल और सेवा अवधि पर निर्भर करती है।',
    requiredDocuments: [
      'CSD Smart Card / Service Identity Card',
      'Pay Slip of current month',
      'Sanction letter for car purchase from Commanding Officer (for AFD I items)',
      'Dealer Availability Certificate'
    ],
    requiredDocumentsHindi: [
      'सीएसडी स्मार्ट कार्ड / सेना पहचान पत्र',
      'वर्तमान माह की वेतन पर्ची',
      'कमांडिंग ऑफिसर का अनुमोदन पत्र',
      'डीलर उपलब्धता प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Register on the official CSD AFD online portal (afd.csdindia.gov.in)',
      'Select desired vehicle model and dealership',
      'Upload CO recommendation and pay slip for verification',
      'Pay through payment gateway and receive purchase order for dealer delivery'
    ],
    howToApplyStepsHindi: [
      'सीएसडी के आधिकारिक एएफडी पोर्टल (afd.csdindia.gov.in) पर पंजीकरण करें',
      'वाहन मॉडल और डीलर चुनें',
      'वेतन पर्ची और अनुमोदन पत्र अपलोड करें',
      'भुगतान कर परचेज ऑर्डर प्राप्त करें'
    ],
    officialSource: {
      name: 'Canteen Stores Department (CSD India)',
      url: 'https://afd.csdindia.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'serving-medical-mh',
    name: 'Military Hospitals (MH) & Base Hospitals Comprehensive Healthcare',
    nameHindi: 'मिलिट्री अस्पताल (एमएच) एवं बेस अस्पताल व्यापक चिकित्सा सुविधा',
    category: 'Medical',
    beneficiaryType: 'serving',
    isExam: false,
    targetAudience: 'Serving soldiers, officers and their officially enrolled dependent family members',
    targetAudienceHindi: 'सेवारत सैनिक, अधिकारी और उनके आधिकारिक रूप से दर्ज आश्रित परिजन',
    potentialBenefit: '100% free OPD, super-specialty surgeries, advanced diagnostics, free medicines, and emergency aero-medical evacuation if needed',
    potentialBenefitHindi: 'शत-प्रतिशत निशुल्क ओपीडी, सुपर-स्पेशियलिटी सर्जरी, परीक्षण, दवाएं एवं आपातकालीन हवाई चिकित्सा निकासी',
    rules: {
      beneficiaryTypes: ['serving'],
    },
    eligibilityDescription: 'Available at all Military Hospitals, Command Hospitals, and Army Hospital (R&R) New Delhi for serving personnel and dependent parents/spouse/unmarried children.',
    eligibilityDescriptionHindi: 'सभी मिलिट्री और कमान अस्पतालों में सेवारत कर्मियों और उनके आश्रित माता-पिता, पति/पत्नी और बच्चों हेतु उपलब्ध।',
    requiredDocuments: [
      'Defence Service Identity Card',
      'Family Dependent Identity Card / Part II Order sheet',
      'Unit Medical Prescription Book'
    ],
    requiredDocumentsHindi: [
      'सैन्य सेवा पहचान पत्र',
      'आश्रित पहचान पत्र / पार्ट II आर्डर',
      'यूनिट मेडिकल बुक'
    ],
    howToApplySteps: [
      'Report to your Station Regimental Medical Officer (RMO) or MI Room',
      'Receive referral to Military Hospital / Base Hospital if specialist care is needed',
      'Direct admissions and specialist consultations processed through hospital reception'
    ],
    howToApplyStepsHindi: [
      'यूनिट आरएमओ या एमआई रूम में रिपोर्ट करें',
      'आवश्यकतानुसार मिलिट्री अस्पताल हेतु रेफरल प्राप्त करें',
      'अस्पताल रिसेप्शन पर पहचान पत्र दिखाकर निशुल्क इलाज'
    ],
    officialSource: {
      name: 'Directorate General Armed Forces Medical Services',
      url: 'https://mod.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },

  // ==========================================
  // SECTION B — VETERAN / EX-SERVICEMEN
  // ==========================================
  {
    id: 'veteran-echs',
    name: 'Ex-Servicemen Contributory Health Scheme (ECHS)',
    nameHindi: 'पूर्व सैनिक अंशदायी स्वास्थ्य योजना (ईसीएचएस)',
    category: 'Medical',
    beneficiaryType: 'veteran',
    isExam: false,
    targetAudience: 'All Ex-Servicemen pensioners and their eligible dependents (spouse, dependent children & dependent parents)',
    targetAudienceHindi: 'सभी भूतपूर्व सैनिक पेंशनभोगी और उनके पात्र आश्रित (पति/पत्नी, आश्रित बच्चे और आश्रित माता-पिता)',
    potentialBenefit: 'Cashless, comprehensive outpatient and inpatient medical treatment across 427 ECHS Polyclinics and over 3,000 top empanelled private super-specialty hospitals across India',
    potentialBenefitHindi: 'देश भर के 427 ईसीएचएस पॉलीक्लीनिक और 3,000+ निजी सुपर-स्पेशियलिटी अस्पतालों में कैशलेस और संपूर्ण उपचार',
    rules: {
      beneficiaryTypes: ['veteran', 'shaheed_family'],
      requiresPensioner: true
    },
    eligibilityDescription: 'Ex-Servicemen pensioners drawing pension through SPARSH/DPDO/Bank. War widows, battle casualties, and disability pensioners are exempted from paying one-time contribution.',
    eligibilityDescriptionHindi: 'पेंशन प्राप्त करने वाले पूर्व सैनिक। युद्ध विधवाओं और दिव्यांग पूर्व सैनिकों को अंशदान से पूर्ण छूट।',
    requiredDocuments: [
      'Pension Payment Order (PPO) copy',
      'Discharge Book / Service Certificate',
      'Aadhaar card of veteran and all dependents',
      'Bank Account details and PAN Card',
      'Passport size photographs'
    ],
    requiredDocumentsHindi: [
      'पेंशन भुगतान आदेश (पीपीओ) प्रति',
      'डिस्चार्ज बुक / सेवा प्रमाण पत्र',
      'पूर्व सैनिक और आश्रितों का आधार कार्ड',
      'बैंक खाता एवं पैन कार्ड'
    ],
    howToApplySteps: [
      'Visit echs.sourceinfo.ca.gov.in for the 64KB ECHS Smart Card online application',
      'Fill in Ex-servicemen details, upload PPO, discharge book and dependent documents',
      'Pay one-time contribution online (if not exempted)',
      'Collect physical 64KB Smart Card from designated Station HQ Polyclinic'
    ],
    howToApplyStepsHindi: [
      '64केबी स्मार्ट कार्ड हेतु आधिकारिक ईसीएचएस पोर्टल पर जाएं',
      'पीपीओ, डिस्चार्ज बुक और आश्रितों के विवरण अपलोड करें',
      'अंशदान का भुगतान करें (यदि छूट प्राप्त नहीं है)',
      'स्टेशन मुख्यालय पॉलीक्लीनिक से स्मार्ट कार्ड प्राप्त करें'
    ],
    officialSource: {
      name: 'Central Organisation ECHS, New Delhi',
      url: 'https://echs.gov.in',
      department: 'Department of Ex-Servicemen Welfare, MoD'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'veteran-pmss',
    name: 'Prime Minister’s Scholarship Scheme (PMSS) - KSB',
    nameHindi: 'प्रधानमंत्री छात्रवृत्ति योजना (पीएमएसएस) - केएसबी',
    category: 'Scholarship',
    beneficiaryType: 'veteran',
    isExam: false,
    targetAudience: 'Dependent wards and widows of Ex-Servicemen / Ex-Coast Guard personnel pursuing professional degree courses',
    targetAudienceHindi: 'व्यावसायिक डिग्री कोर्स कर रहे पूर्व सैनिकों/तटरक्षकों के आश्रित बच्चे और विधवाएं',
    potentialBenefit: 'Rs 30,000/- per year for Boys (Rs 2,500/month) and Rs 36,000/- per year for Girls (Rs 3,000/month) credited annually into student’s bank account for duration of course',
    potentialBenefitHindi: 'छात्रों हेतु 30,000 रु. वार्षिक (2,500 रु./माह) एवं छात्राओं हेतु 36,000 रु. वार्षिक (3,000 रु./माह)।',
    rules: {
      beneficiaryTypes: ['veteran', 'shaheed_family'],
      min12thPercentage: 60
    },
    eligibilityDescription: 'Students admitted to 1st year of professional technical degree courses (B.Tech, MBBS, BDS, B.Pharm, BBA, BCA, MBA, MCA etc.) recognized by AICTE/UGC/MCI with minimum 60% in 10+2 / Diploma / Graduation.',
    eligibilityDescriptionHindi: 'एआईसीटीई/यूजीसी से मान्यता प्राप्त व्यावसायिक डिग्री (बी.टेक, एमबीबीएस, बीबीए, बीसीए आदि) के प्रथम वर्ष में 10+2 में 60% अंकों के साथ प्रवेश लेने वाले छात्र।',
    requiredDocuments: [
      'Ex-Servicemen Discharge Book / PPO / ESM Identity Card',
      'Class 10 and 12 Marksheets (showing >= 60% aggregate)',
      'College Bonafide Certificate and Admission Fee Receipt',
      'Bank Account passbook copy of student linked with Aadhaar',
      'Annexure 1 (Declaration by ESM) & Annexure 2 (College Certificate)'
    ],
    requiredDocumentsHindi: [
      'डिस्चार्ज बुक / पीपीओ / पूर्व सैनिक पहचान पत्र',
      '10वीं एवं 12वीं की अंकतालिकाएं (न्यूनतम 60% अंक)',
      'कॉलेज का बोनाफाइड प्रमाण पत्र व शुल्क रसीद',
      'छात्र का आधार से जुड़ा बैंक खाता'
    ],
    howToApplySteps: [
      'Register on the Kendriya Sainik Board portal (ksb.gov.in)',
      'Select Prime Minister Scholarship Scheme (PMSS) application link during open window',
      'Upload Bonafide certificate, 10+2 marksheet and ESM relationship proof',
      'Application verified online by Zila Sainik Board (ZSB), then Rajya Sainik Board (RSB), then KSB New Delhi'
    ],
    howToApplyStepsHindi: [
      'केंद्रीय सैनिक बोर्ड के पोर्टल (ksb.gov.in) पर पंजीकरण करें',
      'पीएमएसएस आवेदन लिंक चुनें और आवश्यक दस्तावेज अपलोड करें',
      'जिला सैनिक कल्याण बोर्ड (ZSB) और राज्य सैनिक बोर्ड (RSB) द्वारा ऑनलाइन सत्यापन'
    ],
    officialSource: {
      name: 'Kendriya Sainik Board Secretariat (KSB)',
      url: 'https://ksb.gov.in',
      department: 'Department of Ex-Servicemen Welfare, MoD'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active',
    applicationDeadlineNotice: 'Portal opens annually from August to November. Check ksb.gov.in for exact academic year dates.'
  },
  {
    id: 'veteran-ksb-penury',
    name: 'KSB Financial Assistance for Penury / Non-Pensioner ESM (Raksha Mantri Ex-Servicemen Welfare Fund)',
    nameHindi: 'केएसबी निर्धनता सहायता / गैर-पेंशनभोगी पूर्व सैनिक योजना (आरएमईडब्ल्यूएफ)',
    category: 'Pension',
    beneficiaryType: 'veteran',
    isExam: false,
    targetAudience: 'Elderly non-pensioner Ex-Servicemen or their widows aged 65 years and above in indigent financial conditions',
    targetAudienceHindi: '65 वर्ष या उससे अधिक आयु के निर्धन गैर-पेंशनभोगी पूर्व सैनिक या उनकी विधवाएं',
    potentialBenefit: 'Monthly financial grant of Rs 4,000/- per month (revised from Rs 1,000/-) for life, paid directly to the beneficiary’s bank account',
    potentialBenefitHindi: 'जीवन भर के लिए 4,000 रु. प्रतिमाह की वित्तीय सहायता, सीधे बैंक खाते में भुगतान',
    rules: {
      minAge: 65,
      beneficiaryTypes: ['veteran', 'shaheed_family'],
    },
    eligibilityDescription: 'Non-pensioner Ex-Servicemen or widows of non-pensioner ESM of the rank of Havildar/equivalent and below, who have attained 65 years of age and do not have substantial income.',
    eligibilityDescriptionHindi: 'हवलदार या उससे नीचे के गैर-पेंशनभोगी पूर्व सैनिक या उनकी विधवाएं जिनकी आयु 65 वर्ष पूरी हो चुकी हो और कोई निश्चित आय न हो।',
    requiredDocuments: [
      'Discharge Certificate / Service Book',
      'Age proof verifying 65 years or above',
      'Income Certificate issued by Tehsildar / District Revenue Authority',
      'Affidavit stating non-receipt of pension from any source',
      'Zila Sainik Welfare Officer (ZSWO) recommendation'
    ],
    requiredDocumentsHindi: [
      'डिस्चार्ज सर्टिफिकेट / सर्विस बुक',
      '65 वर्ष या अधिक का आयु प्रमाण',
      'तहसीलदार द्वारा जारी आय प्रमाण पत्र',
      'पेंशन न मिलने का शपथ पत्र',
      'जिला सैनिक कल्याण अधिकारी की अनुशंसा'
    ],
    howToApplySteps: [
      'Log into ksb.gov.in and apply under "Financial Assistance for Penury"',
      'Submit physical verification copies to your Zila Sainik Welfare Office (ZSWB)',
      'ZSWO conducts field verification and forwards approval to KSB New Delhi'
    ],
    howToApplyStepsHindi: [
      'ksb.gov.in पर निर्धनता सहायता (Penury Grant) के तहत आवेदन करें',
      'जिला सैनिक बोर्ड में दस्तावेज सत्यापन कराएं',
      'सत्यापन उपरांत केएसबी द्वारा सीधे खाते में राशि जारी'
    ],
    officialSource: {
      name: 'Kendriya Sainik Board (KSB)',
      url: 'https://ksb.gov.in',
      department: 'Department of Ex-Servicemen Welfare, MoD'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'veteran-dgr-resettlement',
    name: 'Directorate General Resettlement (DGR) Training & Self-Employment Schemes',
    nameHindi: 'पुनर्वास महानिदेशालय (डीजीआर) प्रशिक्षण एवं स्वरोजगार योजनाएं',
    category: 'Employment',
    beneficiaryType: 'veteran',
    isExam: false,
    targetAudience: 'Retiring and retired Armed Forces personnel seeking second career, self-employment, or government quota jobs',
    targetAudienceHindi: 'दूसरी पारी का रोजगार या व्यवसाय चाहने वाले सेवानिवृत्त सैन्य कर्मी',
    potentialBenefit: 'Fully sponsored certified resettlement courses at top institutes (IIMs, XLRI, MSME centres), DGR Security Agency sponsorships, Coal Transportation companies, and Mother Dairy / CNG booth allotments',
    potentialBenefitHindi: 'शीर्ष संस्थानों (आईआईएम, आदि) में प्रायोजित प्रशिक्षण, डीजीआर सुरक्षा एजेंसी लाइसेंस, कोल ट्रांसपोर्ट व बूथ आवंटन',
    rules: {
      beneficiaryTypes: ['veteran'],
    },
    eligibilityDescription: 'All Ex-Servicemen possessing valid ESM identity card issued by Zila Sainik Board, with priority based on retirement date and age.',
    eligibilityDescriptionHindi: 'जिला सैनिक बोर्ड द्वारा जारी वैध पूर्व सैनिक पहचान पत्र धारक सभी भूतपूर्व सैनिक।',
    requiredDocuments: [
      'ESM Identity Card issued by ZSB',
      'Discharge Book showing exemplary/good character',
      'PPO (Pension Payment Order)',
      'PAN, Aadhaar and Educational qualification certificates'
    ],
    requiredDocumentsHindi: [
      'जिला सैनिक बोर्ड द्वारा जारी पूर्व सैनिक पहचान पत्र',
      'डिस्चार्ज बुक',
      'पीपीओ प्रति',
      'शैक्षणिक एवं पहचान प्रमाण'
    ],
    howToApplySteps: [
      'Visit the official DGR India portal (dgrindia.gov.in)',
      'Browse through Resettlement Training Courses or Self-Employment Schemes',
      'Register with your Service Number and ZSB registration details',
      'Submit training application through your Zila Sainik Welfare Officer'
    ],
    howToApplyStepsHindi: [
      'डीजीआर इंडिया पोर्टल (dgrindia.gov.in) पर जाएं',
      'प्रशिक्षण पाठ्यक्रम या स्वरोजगार योजनाओं की सूची देखें',
      'सर्विस नंबर एवं जिला सैनिक बोर्ड विवरण के साथ आवेदन करें'
    ],
    officialSource: {
      name: 'Directorate General Resettlement (DGR)',
      url: 'https://dgrindia.gov.in',
      department: 'Department of Ex-Servicemen Welfare, MoD'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'veteran-serious-disease',
    name: 'KSB Financial Assistance for Serious Diseases (Cancer, Renal, Heart Surgery)',
    nameHindi: 'केएसबी गंभीर बीमारी वित्तीय सहायता (कैंसर, किडनी, हृदय रोग)',
    category: 'Medical',
    beneficiaryType: 'veteran',
    isExam: false,
    targetAudience: 'Non-pensioner Ex-Servicemen and widows not covered under ECHS facing critical illness expenses',
    targetAudienceHindi: 'ईसीएचएस से गैर-आच्छादित निर्धन पूर्व सैनिक एवं विधवाएं जो गंभीर बीमारी से जूझ रहे हैं',
    potentialBenefit: 'Financial grant up to Rs 1,25,000/- for Officers/JCOs/OR for serious surgeries and medical procedures',
    potentialBenefitHindi: 'गंभीर ऑपरेशन एवं उपचार हेतु 1,25,000 रु. तक की एकमुश्त वित्तीय सहायता',
    rules: {
      beneficiaryTypes: ['veteran', 'shaheed_family'],
    },
    eligibilityDescription: 'Applicable for treatments of cancer, renal failure, coronary artery surgery, hip/knee joint replacement, and other life-threatening ailments in government/recognized hospitals.',
    eligibilityDescriptionHindi: 'सरकारी/मान्यता प्राप्त अस्पताल में कैंसर, डायलिसिस, बाईपास सर्जरी आदि गंभीर बीमारियों के इलाज हेतु।',
    requiredDocuments: [
      'Discharge book & ESM Identity Card',
      'Original medical bills and hospital discharge summary',
      'Certificate from Medical Specialist / Civil Surgeon',
      'Non-pensioner affidavit / ECHS non-membership verification'
    ],
    requiredDocumentsHindi: [
      'डिस्चार्ज बुक एवं पूर्व सैनिक पहचान पत्र',
      'मूल मेडिकल बिल एवं डिस्चार्ज समरी',
      'सिविल सर्जन/विशेषज्ञ का प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Apply online on ksb.gov.in under Serious Diseases Grant',
      'Submit original hospital invoices to Zila Sainik Welfare Office within 180 days of hospital discharge',
      'ZSB endorses and forwards for grant release'
    ],
    howToApplyStepsHindi: [
      'ksb.gov.in पर गंभीर बीमारी सहायता हेतु ऑनलाइन आवेदन करें',
      'अस्पताल से छुट्टी के 180 दिनों के भीतर जिला सैनिक बोर्ड में बिल जमा करें'
    ],
    officialSource: {
      name: 'Kendriya Sainik Board (KSB)',
      url: 'https://ksb.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'veteran-daughter-marriage',
    name: 'KSB Financial Assistance for Marriage of Daughters of ESM',
    nameHindi: 'पूर्व सैनिकों की पुत्रियों के विवाह हेतु केएसबी वित्तीय सहायता',
    category: 'Marriage & Family Support',
    beneficiaryType: 'veteran',
    isExam: false,
    targetAudience: 'Widows of ESM and indigent Ex-Servicemen (ranks up to Havildar) for marriage of their daughters (up to 2 daughters)',
    targetAudienceHindi: 'हवलदार रैंक तक के निर्धन पूर्व सैनिक या उनकी विधवाएं (अधिकतम 2 बेटियों के विवाह हेतु)',
    potentialBenefit: 'One-time grant of Rs 50,000/- per daughter (credited directly into the applicant’s bank account)',
    potentialBenefitHindi: 'प्रति पुत्री 50,000 रु. की एकमुश्त आर्थिक सहायता (अधिकतम 2 बेटियां)',
    rules: {
      beneficiaryTypes: ['veteran', 'shaheed_family'],
    },
    eligibilityDescription: 'Applicable for daughters aged 18 years and above. Application must be submitted within 180 days of the marriage solemnization date or prior.',
    eligibilityDescriptionHindi: '18 वर्ष या उससे अधिक आयु की बेटियों के लिए। विवाह की तिथि से 180 दिनों के भीतर आवेदन आवश्यक।',
    requiredDocuments: [
      'Official Marriage Certificate issued by Registrar / Municipal authority / Panchayat',
      'Daughter’s Date of Birth proof (Class 10 certificate or Birth certificate)',
      'Discharge Book showing daughter as dependent family member',
      'Bank passbook copy & Income Certificate'
    ],
    requiredDocumentsHindi: [
      'विवाह पंजीकरण प्रमाण पत्र (रजिस्ट्रार/पंचायत द्वारा)',
      'पुत्री का जन्म प्रमाण पत्र (18+ वर्ष)',
      'डिस्चार्ज बुक में दर्ज पुत्री का नाम',
      'आय प्रमाण पत्र एवं बैंक पासबुक'
    ],
    howToApplySteps: [
      'Apply on ksb.gov.in under "Daughter Marriage Grant"',
      'Upload Marriage certificate and daughter DOB proof',
      'Submit hard copies to local Zila Sainik Welfare Office for physical verification'
    ],
    howToApplyStepsHindi: [
      'ksb.gov.in पर "पुत्री विवाह अनुदान" के अंतर्गत आवेदन करें',
      'विवाह प्रमाण पत्र और दस्तावेज अपलोड करें',
      'सत्यापन हेतु जिला सैनिक बोर्ड में प्रति जमा करें'
    ],
    officialSource: {
      name: 'Kendriya Sainik Board Secretariat',
      url: 'https://ksb.gov.in',
      department: 'Department of Ex-Servicemen Welfare, MoD'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },

  // ==========================================
  // SECTION D — FAMILY OF SHAHEED PERSONNEL
  // ==========================================
  {
    id: 'shaheed-ex-gratia',
    name: 'Central Government Ex-Gratia Lumpsum Compensation for Martyrs',
    nameHindi: 'शहीद सैनिकों के आश्रितों हेतु केंद्र सरकार एकमुश्त अनुग्रह अनुदान',
    category: 'Financial',
    beneficiaryType: 'shaheed_family',
    isExam: false,
    targetAudience: 'Next of Kin (NOK / Veer Nari / Parents) of soldiers who made the supreme sacrifice in line of duty',
    targetAudienceHindi: 'कर्तव्य पथ पर सर्वोच्च बलिदान देने वाले सैनिकों के निकटतम आश्रित (वीर नारी / माता-पिता)',
    potentialBenefit: 'Government ex-gratia amount varies between Rs 25 Lakh to Rs 45 Lakh depending on the casualty category (e.g. enemy action in war/border skirmishes, counter-insurgency operations, or high altitude / difficult terrain conditions), supplemented by respective State Government ex-gratia grants.',
    potentialBenefitHindi: 'कैजुअल्टी श्रेणी (युद्ध/सीमा संघर्ष/आतंकवाद विरोधी अभियान) के अनुसार 25 लाख से 45 लाख रु. तक की अनुग्रह राशि, साथ ही संबंधित राज्य सरकार का अतिरिक्त अनुदान।',
    rules: {
      beneficiaryTypes: ['shaheed_family'],
    },
    eligibilityDescription: 'Granted to the declared Next of Kin (NOK) in service records. Amount depends on casualty category and current government/service orders.',
    eligibilityDescriptionHindi: 'सेवा रिकॉर्ड में दर्ज निकटतम वारिस (एनओके) को देय। राशि कैजुअल्टी श्रेणी और मौजूदा सरकारी आदेशों पर निर्भर करती है।',
    requiredDocuments: [
      'Battle Casualty / Operational Casualty Certificate issued by Army HQ / Record Office',
      'Part II Order of Death / Casualty Notification',
      'Next of Kin (NOK) verification certificate from Unit / District Magistrate',
      'Aadhaar, PAN and Joint Bank Account details of NOK'
    ],
    requiredDocumentsHindi: [
      'सेना मुख्यालय/रिकॉर्ड कार्यालय द्वारा जारी बैटल कैजुअल्टी प्रमाण पत्र',
      'पार्ट II ऑर्डर (मृत्यु/शहादत विवरण)',
      'जिलाधिकारी/यूनिट द्वारा वारिस (एनओके) प्रमाण पत्र',
      'बैंक खाता एवं आधार कार्ड'
    ],
    howToApplySteps: [
      'Unit and Record Office immediately initiate the terminal entitlement papers',
      'Zila Sainik Welfare Office and Army AG Branch facilitate document processing with PCDA(P) Prayagraj',
      'Funds disbursed directly via electronic transfer to the NOK account'
    ],
    howToApplyStepsHindi: [
      'यूनिट और संबंधित सेना रिकॉर्ड ऑफिस द्वारा प्रक्रिया स्वतः शुरू की जाती है',
      'जिला सैनिक कल्याण कार्यालय दस्तावेजों के सत्यापन में पूर्ण सहायता करता है',
      'पीसीडीए(पी) प्रयागराज द्वारा सीधे बैंक खाते में भुगतान'
    ],
    officialSource: {
      name: 'Department of Ex-Servicemen Welfare (DESW)',
      url: 'https://desw.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'shaheed-afbcwf',
    name: 'Armed Forces Battle Casualties Welfare Fund (AFBCWF - Maa Bharati Ke Sapoot)',
    nameHindi: 'सशस्त्र बल युद्ध हताहत कल्याण कोष (मां भारती के सपूत)',
    category: 'Financial',
    beneficiaryType: 'shaheed_family',
    isExam: false,
    targetAudience: 'Families of Battle Casualties (Fatal and Disability cases 60% and above)',
    targetAudienceHindi: 'युद्ध हताहतों (शहीद परिवारों एवं 60% या अधिक दिव्यांगता वाले सैनिकों) के परिजन',
    potentialBenefit: 'Financial assistance of Rs 8 Lakh to Next of Kin of Battle Casualties (Fatal), in addition to all other government entitlements and ex-gratia',
    potentialBenefitHindi: 'अन्य सभी सरकारी लाभों व अनुग्रह राशि के अतिरिक्त 8 लाख रु. की सीधी आर्थिक सहायता',
    rules: {
      beneficiaryTypes: ['shaheed_family'],
      allowedCasualtyCategories: ['Battle Casualty (Operations)']
    },
    eligibilityDescription: 'Administered by Adjutant General’s Branch, Army HQ for personnel declared as Battle Casualties by Military Operations Directorate.',
    eligibilityDescriptionHindi: 'सैन्य संचालन महानिदेशालय द्वारा बैटल कैजुअल्टी घोषित कर्मियों के निकटतम वारिस हेतु।',
    requiredDocuments: [
      'Battle Casualty Certificate issued by AG Branch (CW Directorate)',
      'Service Record Part II Order',
      'Family Certificate verified by Zila Sainik Board'
    ],
    requiredDocumentsHindi: [
      'एजी ब्रांच द्वारा जारी बैटल कैजुअल्टी प्रमाण पत्र',
      'पार्ट II ऑर्डर प्रति',
      'जिला सैनिक बोर्ड द्वारा सत्यापित पारिवारिक प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Ceremonial and Welfare Directorate (Army HQ) processes claims based on battle casualty declaration',
      'Monies disbursed directly to the NOK account through the Maa Bharati Ke Sapoot fund',
      'Status can be tracked via maabharatikesapoot.mod.gov.in'
    ],
    howToApplyStepsHindi: [
      'सेना मुख्यालय द्वारा स्वतः दावा प्रक्रिया शुरू की जाती है',
      'सीधे मां भारती के सपूत कोष से बैंक खाते में अंतरण',
      'maabharatikesapoot.mod.gov.in पर स्थिति की जांच की जा सकती है'
    ],
    officialSource: {
      name: 'Maa Bharati Ke Sapoot Portal (AFBCWF)',
      url: 'https://maabharatikesapoot.mod.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'shaheed-liberalised-pension',
    name: 'Liberalised Family Pension (LFP) for War & Counter-Insurgency Casualties',
    nameHindi: 'युद्ध एवं आतंकवाद विरोधी अभियानों हेतु उदारीकृत पारिवारिक पेंशन (एलएफपी)',
    category: 'Pension',
    beneficiaryType: 'shaheed_family',
    isExam: false,
    targetAudience: 'Widows (Veer Naris) or nominated parents of soldiers martyred in war, cross-border firing, or counter-terrorist operations',
    targetAudienceHindi: 'युद्ध, सीमा पार गोलीबारी या आतंकवाद विरोधी अभियानों में शहीद हुए सैनिकों की वीर नारियां या माता-पिता',
    potentialBenefit: 'Equal to 100% of the last reckonable emoluments (Pay + Military Service Pay + Class Pay) drawn by the deceased soldier for life, along with full Dearness Relief',
    potentialBenefitHindi: 'सैनिक द्वारा प्राप्त अंतिम वेतन (वेतन + एमएसपी) के 100% के बराबर आजीवन पेंशन तथा पूर्ण महंगाई राहत',
    rules: {
      beneficiaryTypes: ['shaheed_family'],
      allowedCasualtyCategories: ['Battle Casualty (Operations)']
    },
    eligibilityDescription: 'Granted for life to the widow even after remarriage if she continues to support the dependent children, or to parents if soldier was unmarried.',
    eligibilityDescriptionHindi: 'वीर नारी को आजीवन देय। अविवाहित शहीद के मामले में आश्रित माता-पिता को देय।',
    requiredDocuments: [
      'Casualty Report (Battle Casualty Order)',
      'PPO (Pension Payment Order) issued by PCDA(P) Prayagraj',
      'Life Certificate (submitted annually on SPARSH / Jeevan Pramaan)',
      'Bank Account details linked with SPARSH'
    ],
    requiredDocumentsHindi: [
      'बैटल कैजुअल्टी रिपोर्ट',
      'पीसीडीए(पी) प्रयागराज द्वारा जारी पीपीओ',
      'स्पर्श/जीवन प्रमाण पत्र'
    ],
    howToApplySteps: [
      'Record Office prepares and submits the pension claim directly to PCDA(P) / SPARSH',
      'SPARSH portal generates PPO with designated Liberalised Family Pension code',
      'PPO copy sent to Veer Nari and pension credited directly monthly'
    ],
    howToApplyStepsHindi: [
      'सेना रिकॉर्ड ऑफिस सीधे स्पर्श पोर्टल पर दावा प्रस्तुत करता है',
      'स्पर्श द्वारा उदारीकृत पेंशन पीपीओ जारी',
      'मासिक पेंशन सीधे बैंक खाते में जमा'
    ],
    officialSource: {
      name: 'Principal Controller of Defence Accounts (Pensions) / SPARSH',
      url: 'https://sparsh.defencepension.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'shaheed-pmss-priority1',
    name: 'Prime Minister’s Scholarship Scheme (PMSS) - Priority 1 (Martyrs’ Children & Widows)',
    nameHindi: 'प्रधानमंत्री छात्रवृत्ति योजना - प्राथमिकता 1 (शहीदों के बच्चों एवं विधवाओं हेतु)',
    category: 'Scholarship',
    beneficiaryType: 'shaheed_family',
    isExam: false,
    targetAudience: 'Wards and widows of Armed Forces personnel killed in action (Priority Category 1 of KSB)',
    targetAudienceHindi: 'कर्तव्य के दौरान वीरगति प्राप्त सैनिकों के बच्चे और विधवाएं (केएसबी की प्रथम प्राथमिकता श्रेणी)',
    potentialBenefit: 'Highest priority allocation: Rs 36,000/- per year for girls and Rs 30,000/- per year for boys for professional undergraduate and postgraduate courses',
    potentialBenefitHindi: 'सर्वोच्च प्राथमिकता: छात्राओं हेतु 36,000 रु. वार्षिक एवं छात्रों हेतु 30,000 रु. वार्षिक व्यावसायिक पाठ्यक्रमों के लिए',
    rules: {
      beneficiaryTypes: ['shaheed_family'],
      min12thPercentage: 60
    },
    eligibilityDescription: 'Children/widows of Armed Forces personnel killed in action are classified under Category 1, ensuring 100% confirmed quota subject to passing Class 12 with 60% marks and getting admission into an approved professional course.',
    eligibilityDescriptionHindi: 'वीरगति प्राप्त सैनिकों के आश्रितों को प्राथमिकता श्रेणी 1 के तहत 100% सुनिश्चित कोटा (12वीं में 60% अंकों के साथ व्यावसायिक कोर्स में प्रवेश पर)।',
    requiredDocuments: [
      'Battle Casualty Certificate issued by Military Authority',
      'Relationship Certificate & Part II Order of the martyr',
      'Class 12 Marksheet & College Bonafide Certificate',
      'Student’s Bank Passbook copy'
    ],
    requiredDocumentsHindi: [
      'बैटल कैजुअल्टी प्रमाण पत्र',
      'शहीद के साथ संबंध प्रमाण पत्र',
      '12वीं की अंकतालिका एवं कॉलेज बोनाफाइड'
    ],
    howToApplySteps: [
      'Apply online on ksb.gov.in under PMSS Priority 1',
      'Mark applicant status as Ward of Battle Casualty (Killed in Action)',
      'Zila Sainik Board verifies within 7 days and forwards directly to KSB Secretariat'
    ],
    howToApplyStepsHindi: [
      'ksb.gov.in पर पीएमएसएस प्राथमिकता 1 के अंतर्गत आवेदन करें',
      'बैटल कैजुअल्टी प्रमाण पत्र संलग्न करें',
      'जिला सैनिक बोर्ड द्वारा त्वरित प्राथमिकता सत्यापन'
    ],
    officialSource: {
      name: 'Kendriya Sainik Board Secretariat',
      url: 'https://ksb.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'shaheed-echs-exempted',
    name: 'ECHS Free Comprehensive Healthcare for War Widows & Dependents',
    nameHindi: 'वीर नारियों एवं आश्रितों हेतु ईसीएचएस निशुल्क संपूर्ण स्वास्थ्य सेवा',
    category: 'Medical',
    beneficiaryType: 'shaheed_family',
    isExam: false,
    targetAudience: 'War Widows (Veer Naris) and eligible dependent children of martyred defence personnel',
    targetAudienceHindi: 'युद्ध विधवाएं (वीर नारियां) और शहीद रक्षा कर्मियों के पात्र आश्रित बच्चे',
    potentialBenefit: '100% Exemption from ECHS one-time contribution fee. Priority treatment and consultation at all polyclinics, free white card, and cashless super-specialty hospital care for life.',
    potentialBenefitHindi: 'ईसीएचएस अंशदान शुल्क से 100% छूट। सभी पॉलीक्लीनिक में प्राथमिकता और निजी सुपर-स्पेशियलिटी अस्पतालों में जीवन भर निशुल्क इलाज।',
    rules: {
      beneficiaryTypes: ['shaheed_family'],
    },
    eligibilityDescription: 'War widows and NOKs of personnel who died in harness/operational duties are entitled to free ECHS Smart Cards without any financial deduction.',
    eligibilityDescriptionHindi: 'शहीद सैनिकों के परिजनों को बिना किसी शुल्क के ईसीएचएस का पूर्ण लाभ प्राप्त होता है।',
    requiredDocuments: [
      'PPO indicating Battle Casualty / Liberalised Family Pension',
      'Battle Casualty Certificate',
      'Aadhaar card of Veer Nari and dependent children',
      'Photographs'
    ],
    requiredDocumentsHindi: [
      'उदारीकृत पेंशन दर्शाने वाला पीपीओ',
      'बैटल कैजुअल्टी प्रमाण पत्र',
      'आधार कार्ड और फोटो'
    ],
    howToApplySteps: [
      'Apply online at echs.sourceinfo.ca.gov.in selecting War Widow category',
      'System automatically applies 100% fee waiver (Zero Contribution)',
      'Smart Card issued with "War Widow" endorsement for instant priority admission'
    ],
    howToApplyStepsHindi: [
      'ईसीएचएस पोर्टल पर वार विडो श्रेणी चुनकर आवेदन करें',
      'शुल्क स्वतः शून्य (फ्री) हो जाएगा',
      'प्राथमिकता कार्ड पॉलीक्लीनिक से प्राप्त करें'
    ],
    officialSource: {
      name: 'Central Organisation ECHS',
      url: 'https://echs.gov.in',
      department: 'Department of Ex-Servicemen Welfare, MoD'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  },
  {
    id: 'shaheed-compassionate-job',
    name: 'Compassionate Appointment in Ministry of Defence & Central Govt',
    nameHindi: 'रक्षा मंत्रालय एवं केंद्र सरकार में अनुकंपा नियुक्ति',
    category: 'Employment',
    beneficiaryType: 'shaheed_family',
    isExam: false,
    targetAudience: 'Eligible dependent family member (Spouse, Son, or Unmarried Daughter) of Armed Forces personnel who died in service',
    targetAudienceHindi: 'सेवा के दौरान दिवंगत/शहीद सैनिक का पात्र आश्रित परिजन (पति/पत्नी, पुत्र या अविवाहित पुत्री)',
    potentialBenefit: 'Direct employment placement in Group ‘C’ defence civilian posts (e.g. Lower Division Clerk, Store Keeper, Civilian Motor Driver, Multi-Tasking Staff) without competitive examination',
    potentialBenefitHindi: 'बिना किसी प्रतियोगी परीक्षा के रक्षा नागरिक पदों (एलडीसी, स्टोर कीपर, एमटीएस आदि) पर सीधी सरकारी नौकरी',
    rules: {
      beneficiaryTypes: ['shaheed_family'],
      minAge: 18,
      maxAge: 45
    },
    eligibilityDescription: 'Exempt from normal recruitment age and exam rules. Candidate must possess minimum educational qualifications for the post (10th/12th/Graduate). Relaxable in case of widows.',
    eligibilityDescriptionHindi: 'सामान्य भर्ती परीक्षा से छूट। पद के अनुसार 10वीं/12वीं या स्नातक उत्तीर्ण होना चाहिए। विधवाओं हेतु शैक्षणिक योग्यता में छूट।',
    requiredDocuments: [
      'Casualty / Death in service certificate',
      'Family Certificate indicating no other family member is in regular government employment',
      'Educational Marksheets & Proof of Date of Birth',
      'Affidavit of dependency from Zila Sainik Board'
    ],
    requiredDocumentsHindi: [
      'शहादत/सेवाकाल मृत्यु प्रमाण पत्र',
      'परिवार में अन्य किसी के सरकारी सेवा में न होने का प्रमाण पत्र',
      'शैक्षणिक योग्यता प्रमाण पत्र एवं आयु प्रमाण'
    ],
    howToApplySteps: [
      'Submit formal application to the deceased personnel’s Regimental Record Office',
      'Record Office screens eligibility and places application before the Compassionate Appointment Board',
      'Appointment order issued as vacancies arise in Defence civilian establishments'
    ],
    howToApplyStepsHindi: [
      'संबंधित रेजिमेंटल रिकॉर्ड ऑफिस में आवेदन पत्र जमा करें',
      'अनुकंपा नियुक्ति बोर्ड द्वारा समीक्षा',
      'रिक्तियों के अनुसार रक्षा नागरिक प्रतिष्ठान में नियुक्ति पत्र जारी'
    ],
    officialSource: {
      name: 'Department of Personnel and Training / MoD Civilian Personnel',
      url: 'https://mod.gov.in',
      department: 'Ministry of Defence'
    },
    lastVerifiedDate: '30 October 2026',
    status: 'Active'
  }
];

export const OFFICIAL_NOTICES: OfficialNotification[] = [
  {
    id: 'notice-1',
    title: 'UPSC NDA & NA (I) 2026 Official Examination Notification Released',
    titleHindi: 'यूपीएससी एनडीए एवं एनए (I) 2026 आधिकारिक परीक्षा अधिसूचना जारी',
    date: '2026-10-15',
    deadline: 'Check official UPSC calendar',
    category: 'Recruitment',
    targetCategory: 'candidate',
    sourceName: 'UPSC Official Portal',
    sourceUrl: 'https://upsc.gov.in',
    isVerified: true
  },
  {
    id: 'notice-2',
    title: 'Kendriya Sainik Board: Prime Minister’s Scholarship Scheme (PMSS) Application Window',
    titleHindi: 'केंद्रीय सैनिक बोर्ड: प्रधानमंत्री छात्रवृत्ति योजना (पीएमएसएस) आवेदन खिड़की खुली',
    date: '2026-09-01',
    deadline: '30 November 2026',
    category: 'Scholarship',
    targetCategory: 'veteran',
    sourceName: 'Kendriya Sainik Board Secretariat',
    sourceUrl: 'https://ksb.gov.in',
    isVerified: true
  },
  {
    id: 'notice-3',
    title: 'Indian Army 10+2 Technical Entry Scheme (TES) Application Notification',
    titleHindi: 'भारतीय सेना 10+2 टेक्निकल एंट्री स्कीम (टीईएस) आवेदन अधिसूचना',
    date: '2026-10-01',
    deadline: 'As per Join Indian Army portal',
    category: 'Recruitment',
    targetCategory: 'candidate',
    sourceName: 'Join Indian Army Official Portal',
    sourceUrl: 'https://joinindianarmy.nic.in',
    isVerified: true
  },
  {
    id: 'notice-4',
    title: 'SPARSH Annual Life Certificate (Digital Jeevan Pramaan) Submission Drive',
    titleHindi: 'स्पर्श वार्षिक जीवन प्रमाण पत्र (डिजिटल जीवन प्रमाण) जमा करने का अभियान',
    date: '2026-10-20',
    deadline: '30 November 2026',
    category: 'Pension Alert',
    targetCategory: 'veteran',
    sourceName: 'SPARSH Defence Pension Portal',
    sourceUrl: 'https://sparsh.defencepension.gov.in',
    isVerified: true
  },
  {
    id: 'notice-5',
    title: 'Maa Bharati Ke Sapoot: Armed Forces Battle Casualties Welfare Fund Disbursement',
    titleHindi: 'मां भारती के सपूत: सशस्त्र बल युद्ध हताहत कल्याण कोष संवितरण अद्यतन',
    date: '2026-10-10',
    category: 'Welfare Update',
    targetCategory: 'shaheed_family',
    sourceName: 'Ministry of Defence',
    sourceUrl: 'https://maabharatikesapoot.mod.gov.in',
    isVerified: true
  }
];
