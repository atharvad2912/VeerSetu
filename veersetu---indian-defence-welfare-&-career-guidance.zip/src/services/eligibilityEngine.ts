import { SchemeOrExam, UserProfile, EligibilityEvaluation, EligibilityCriterionCheck, EligibilityStatus } from '../types';

export function calculateAge(dobString: string): number {
  if (!dobString) return 0;
  const dob = new Date(dobString);
  const now = new Date('2026-10-30'); // System reference date
  let age = now.getFullYear() - dob.getFullYear();
  const m = now.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < dob.getDate())) {
    age--;
  }
  return age;
}

export function evaluateEligibility(scheme: SchemeOrExam, user: UserProfile | null): EligibilityEvaluation {
  // If no user profile or category mismatch (unless scheme is for all)
  if (!user) {
    return {
      status: 'more_info_needed',
      summary: 'Please complete or log in to your profile to evaluate your eligibility.',
      summaryHindi: 'अपनी पात्रता जांचने के लिए कृपया अपनी प्रोफ़ाइल में जानकारी भरें या लॉगिन करें।',
      checklist: []
    };
  }

  // HARD RULE: Aspiring Candidates CANNOT see or be eligible for veteran or welfare schemes!
  if (user.category === 'candidate' && !scheme.isExam) {
    return {
      status: 'not_eligible',
      summary: 'This welfare scheme is reserved exclusively for serving soldiers, veterans or martyr families. As an aspiring candidate, please view Army Entry Exams.',
      summaryHindi: 'यह योजना केवल सेवारत सैनिकों, पूर्व सैनिकों अथवा शहीद परिवारों के लिए है।',
      checklist: []
    };
  }

  // HARD RULE: Serving/Veteran/Shaheed families browsing candidate entries
  if (user.category !== 'candidate' && scheme.isExam) {
    return {
      status: 'not_eligible',
      summary: 'This recruitment entry is for direct civilian/aspiring candidates. Please refer to in-service or veteran routes.',
      summaryHindi: 'यह भर्ती परीक्षा नागरिक/इच्छुक अभ्यर्थियों के लिए है।',
      checklist: []
    };
  }

  const checklist: EligibilityCriterionCheck[] = [];
  let failCount = 0;
  let partialCount = 0;
  let missingInfoCount = 0;

  const rules = scheme.rules;

  // 1. Beneficiary Category Check
  if (scheme.beneficiaryType !== 'all' && scheme.beneficiaryType !== user.category) {
    checklist.push({
      label: 'Target Group',
      labelHindi: 'लक्षित समूह',
      isMet: false,
      detail: `Designed for ${scheme.beneficiaryType.replace('_', ' ')}. Your active profile is ${user.category.replace('_', ' ')}.`,
      detailHindi: `यह योजना ${scheme.beneficiaryType} वर्ग के लिए है। आपकी प्रोफ़ाइल ${user.category} है।`
    });
    failCount++;
  } else {
    checklist.push({
      label: 'Target Group',
      labelHindi: 'लक्षित समूह',
      isMet: true,
      detail: `Matches your profile category (${user.category.replace('_', ' ')}).`,
      detailHindi: `आपकी श्रेणी से मेल खाती है।`
    });
  }

  // 2. Age Criteria Check
  const userAge = user.dob ? calculateAge(user.dob) : 0;
  if (rules.minAge !== undefined || rules.maxAge !== undefined) {
    if (!user.dob || userAge === 0) {
      checklist.push({
        label: 'Age Requirement',
        labelHindi: 'आयु सीमा',
        isMet: null,
        detail: `Requires age between ${rules.minAge || 'any'} and ${rules.maxAge || 'any'} years. (DOB not entered)`,
        detailHindi: `आयु ${rules.minAge || 'कोई भी'} से ${rules.maxAge || 'कोई भी'} वर्ष के बीच होनी चाहिए।`
      });
      missingInfoCount++;
    } else {
      const minOk = rules.minAge === undefined || userAge >= rules.minAge;
      const maxOk = rules.maxAge === undefined || userAge <= rules.maxAge;
      const isMet = minOk && maxOk;
      if (!isMet) {
        if (!minOk) {
          checklist.push({
            label: 'Age Requirement',
            labelHindi: 'आयु सीमा',
            isMet: false,
            detail: `Currently ${userAge} years. Minimum required age is ${rules.minAge} years.`,
            detailHindi: `आपकी आयु ${userAge} वर्ष है। न्यूनतम आवश्यक आयु ${rules.minAge} वर्ष है।`
          });
          partialCount++; // May become eligible when they reach the min age
        } else {
          checklist.push({
            label: 'Age Requirement',
            labelHindi: 'आयु सीमा',
            isMet: false,
            detail: `Currently ${userAge} years. Maximum permissible age is ${rules.maxAge} years.`,
            detailHindi: `आपकी आयु ${userAge} वर्ष है। अधिकतम अनुमत आयु ${rules.maxAge} वर्ष है।`
          });
          failCount++;
        }
      } else {
        checklist.push({
          label: 'Age Requirement',
          labelHindi: 'आयु सीमा',
          isMet: true,
          detail: `Your age (${userAge} years) falls within the permissible range (${rules.minAge || 'any'} - ${rules.maxAge || 'any'} years).`,
          detailHindi: `आपकी आयु (${userAge} वर्ष) मान्य सीमा में है।`
        });
      }
    }
  }

  // 3. Gender Criteria Check
  if (rules.genders && rules.genders.length > 0) {
    if (!user.gender) {
      checklist.push({
        label: 'Gender Eligibility',
        labelHindi: 'लिंग पात्रता',
        isMet: null,
        detail: `Open to: ${rules.genders.join(', ')}. Please update gender in profile.`,
        detailHindi: `पात्र: ${rules.genders.join(', ')}।`
      });
      missingInfoCount++;
    } else if (rules.genders.includes(user.gender)) {
      checklist.push({
        label: 'Gender Eligibility',
        labelHindi: 'लिंग पात्रता',
        isMet: true,
        detail: `Matches entry criteria (${user.gender}).`,
        detailHindi: `मानदंड से मेल खाता है (${user.gender})।`
      });
    } else {
      checklist.push({
        label: 'Gender Eligibility',
        labelHindi: 'लिंग पात्रता',
        isMet: false,
        detail: `This entry is currently open for ${rules.genders.join(', ')} only.`,
        detailHindi: `यह केवल ${rules.genders.join(', ')} के लिए उपलब्ध है।`
      });
      failCount++;
    }
  }

  // 4. Candidate specific checks:
  if (user.category === 'candidate') {
    const cand = user.candidateDetails;

    // Minimum 12th percentage
    if (rules.min12thPercentage !== undefined) {
      if (!cand?.class12Percentage) {
        checklist.push({
          label: 'Class 12 Percentage',
          labelHindi: '12वीं कक्षा प्रतिशत',
          isMet: null,
          detail: `Requires min ${rules.min12thPercentage}% aggregate. (Update in profile)`,
          detailHindi: `न्यूनतम ${rules.min12thPercentage}% आवश्यक।`
        });
        missingInfoCount++;
      } else if (cand.class12Percentage >= rules.min12thPercentage) {
        checklist.push({
          label: 'Class 12 Percentage',
          labelHindi: '12वीं कक्षा प्रतिशत',
          isMet: true,
          detail: `Your score (${cand.class12Percentage}%) meets the minimum threshold (${rules.min12thPercentage}%).`,
          detailHindi: `आपके अंक (${cand.class12Percentage}%) न्यूनतम सीमा (${rules.min12thPercentage}%) से अधिक हैं।`
        });
      } else {
        checklist.push({
          label: 'Class 12 Percentage',
          labelHindi: '12वीं कक्षा प्रतिशत',
          isMet: false,
          detail: `Your score (${cand.class12Percentage}%) is below the required ${rules.min12thPercentage}%.`,
          detailHindi: `आपके अंक (${cand.class12Percentage}%) आवश्यक ${rules.min12thPercentage}% से कम हैं।`
        });
        failCount++;
      }
    }

    // Required Stream
    if (rules.requiredStream && rules.requiredStream.length > 0) {
      if (!cand?.class12Stream) {
        checklist.push({
          label: 'Subject Stream',
          labelHindi: 'विषय संकाय',
          isMet: null,
          detail: `Stream needed: ${rules.requiredStream.join(' or ')}.`,
          detailHindi: `संकाय: ${rules.requiredStream.join(' या ')} आवश्यक।`
        });
        missingInfoCount++;
      } else if (rules.requiredStream.includes(cand.class12Stream)) {
        checklist.push({
          label: 'Subject Stream',
          labelHindi: 'विषय संकाय',
          isMet: true,
          detail: `Matches stream requirement (${cand.class12Stream}).`,
          detailHindi: `विषय संकाय मान्य है (${cand.class12Stream})।`
        });
      } else {
        checklist.push({
          label: 'Subject Stream',
          labelHindi: 'विषय संकाय',
          isMet: false,
          detail: `Your stream is ${cand.class12Stream}. Scheme requires ${rules.requiredStream.join(' or ')}.`,
          detailHindi: `आपका संकाय ${cand.class12Stream} है। आवश्यक: ${rules.requiredStream.join(' या ')}।`
        });
        failCount++;
      }
    }

    // Graduation requirement
    if (rules.requiresGraduation) {
      if (!cand?.isGraduate && cand?.educationLevel !== 'Graduate Pass' && cand?.educationLevel !== 'Post Graduate') {
        checklist.push({
          label: 'Graduation Degree',
          labelHindi: 'स्नातक डिग्री',
          isMet: false,
          detail: 'Requires graduation degree of recognized university.',
          detailHindi: 'मान्यता प्राप्त विश्वविद्यालय से स्नातक डिग्री आवश्यक।'
        });
        partialCount++; // May become eligible once graduated
      } else {
        // Allowed degrees check
        if (rules.allowedDegrees && rules.allowedDegrees.length > 0) {
          if (!cand.graduationDegree) {
            checklist.push({
              label: 'Degree Discipline',
              labelHindi: 'डिग्री शाखा',
              isMet: null,
              detail: `Requires: ${rules.allowedDegrees.join(', ')}.`,
              detailHindi: `आवश्यक: ${rules.allowedDegrees.join(', ')}।`
            });
            missingInfoCount++;
          } else if (rules.allowedDegrees.includes(cand.graduationDegree)) {
            checklist.push({
              label: 'Degree Discipline',
              labelHindi: 'डिग्री शाखा',
              isMet: true,
              detail: `Matches degree requirement (${cand.graduationDegree}).`,
              detailHindi: `डिग्री मान्य है (${cand.graduationDegree})।`
            });
          } else {
            checklist.push({
              label: 'Degree Discipline',
              labelHindi: 'डिग्री शाखा',
              isMet: false,
              detail: `Degree held: ${cand.graduationDegree}. Required: ${rules.allowedDegrees.join(', ')}.`,
              detailHindi: `आपकी डिग्री: ${cand.graduationDegree}। आवश्यक: ${rules.allowedDegrees.join(', ')}।`
            });
            failCount++;
          }
        } else {
          checklist.push({
            label: 'Graduation Degree',
            labelHindi: 'स्नातक डिग्री',
            isMet: true,
            detail: 'Graduation completed / final year eligible.',
            detailHindi: 'स्नातक उत्तीर्ण अथवा अंतिम वर्ष में।'
          });
        }
      }
    }

    // NCC 'C' Certificate
    if (rules.requiresNCC_C) {
      if (cand?.nccCertificate === 'C') {
        checklist.push({
          label: 'NCC "C" Certificate',
          labelHindi: 'एनसीसी "C" प्रमाणपत्र',
          isMet: true,
          detail: `Possesses NCC 'C' Certificate (Grade: ${cand.nccGrading || 'Valid'}).`,
          detailHindi: `एनसीसी "C" प्रमाणपत्र धारक।`
        });
      } else if (cand?.nccCertificate === 'B' || cand?.nccCertificate === 'A') {
        checklist.push({
          label: 'NCC "C" Certificate',
          labelHindi: 'एनसीसी "C" प्रमाणपत्र',
          isMet: false,
          detail: `Currently holds NCC ${cand.nccCertificate} Certificate. Will become eligible after acquiring 'C' certificate with min 'B' grade.`,
          detailHindi: `वर्तमान में एनसीसी ${cand.nccCertificate} है। "C" सर्टिफिकेट मिलने पर पात्र होंगे।`
        });
        partialCount++;
      } else {
        checklist.push({
          label: 'NCC "C" Certificate',
          labelHindi: 'एनसीसी "C" प्रमाणपत्र',
          isMet: false,
          detail: `Requires Senior Wing NCC 'C' Certificate.`,
          detailHindi: `सीनियर विंग एनसीसी "C" प्रमाणपत्र अनिवार्य है।`
        });
        failCount++;
      }
    }

    // JEE Main requirement
    if (rules.requiresJEE) {
      if (cand?.jeeMainAppeared) {
        checklist.push({
          label: 'JEE (Mains) Appearance',
          labelHindi: 'जेईई (मेन्स) उपस्थिति',
          isMet: true,
          detail: 'Appeared in JEE Mains as per notification guidelines.',
          detailHindi: 'अधिसूचना के अनुसार जेईई मेन्स में उपस्थित।'
        });
      } else {
        checklist.push({
          label: 'JEE (Mains) Appearance',
          labelHindi: 'जेईई (मेन्स) उपस्थिति',
          isMet: false,
          detail: 'Requires having appeared in JEE (Mains) of the respective year.',
          detailHindi: 'संबंधित वर्ष की जेईई मेन्स परीक्षा में उपस्थिति आवश्यक।'
        });
        failCount++;
      }
    }
  }

  // 5. Veteran specific checks:
  if (user.category === 'veteran') {
    const vet = user.veteranDetails;
    if (rules.requiresPensioner && vet && !vet.isPensioner) {
      checklist.push({
        label: 'Pensioner Status',
        labelHindi: 'पेंशनभोगी स्थिति',
        isMet: false,
        detail: 'Scheme requires receipt of defence pension via SPARSH/DPDO/Bank.',
        detailHindi: 'स्पर्श अथवा बैंक के माध्यम से पेंशन आवश्यक।'
      });
      failCount++;
    }
  }

  // 6. Shaheed Family specific checks:
  if (user.category === 'shaheed_family') {
    const fam = user.shaheedFamilyDetails;
    if (rules.allowedCasualtyCategories && rules.allowedCasualtyCategories.length > 0) {
      if (!fam?.casualtyCategory) {
        checklist.push({
          label: 'Casualty Classification',
          labelHindi: 'कैजुअल्टी वर्गीकरण',
          isMet: null,
          detail: 'Requires classification verified by service records.',
          detailHindi: 'सेवा रिकॉर्ड अनुसार कैजुअल्टी वर्गीकरण आवश्यक।'
        });
        missingInfoCount++;
      } else if (rules.allowedCasualtyCategories.includes(fam.casualtyCategory)) {
        checklist.push({
          label: 'Casualty Classification',
          labelHindi: 'कैजुअल्टी वर्गीकरण',
          isMet: true,
          detail: `Matches scheme scope (${fam.casualtyCategory}).`,
          detailHindi: `योजना के दायरे में (${fam.casualtyCategory})।`
        });
      } else {
        checklist.push({
          label: 'Casualty Classification',
          labelHindi: 'कैजुअल्टी वर्गीकरण',
          isMet: false,
          detail: `Scope: ${rules.allowedCasualtyCategories.join(', ')}. Profile: ${fam.casualtyCategory}.`,
          detailHindi: `मान्यता: ${rules.allowedCasualtyCategories.join(', ')}।`
        });
        failCount++;
      }
    }
  }

  // Calculate overall status
  let finalStatus: EligibilityStatus = 'potentially_eligible';
  let summary = 'Based on the information provided, you appear potentially eligible. Final eligibility is determined by the competent authority.';
  let summaryHindi = 'प्रदान की गई जानकारी के आधार पर, आप संभावित रूप से पात्र प्रतीत होते हैं। अंतिम पात्रता सक्षम प्राधिकारी द्वारा तय की जाती है।';

  if (failCount > 0) {
    finalStatus = 'not_eligible';
    summary = 'Based on current rules, you do not meet one or more primary criteria. Review checklist below.';
    summaryHindi = 'वर्तमान नियमों के आधार पर, आप एक या अधिक प्राथमिक मानदंड पूरे नहीं करते हैं। नीचे चेकलिस्ट देखें।';
  } else if (partialCount > 0) {
    finalStatus = 'may_become_eligible';
    summary = 'You may become eligible once specific conditions (e.g., reaching minimum age, completing qualification or certificate) are met.';
    summaryHindi = 'विशिष्ट शर्तें (जैसे आयु सीमा, डिग्री या प्रमाण पत्र) पूरी होने पर आप पात्र हो सकते हैं।';
  } else if (missingInfoCount > 0) {
    finalStatus = 'more_info_needed';
    summary = 'Additional details needed in your profile to accurately assess eligibility for this entry.';
    summaryHindi = 'सटीक मूल्यांकन हेतु आपकी प्रोफ़ाइल में कुछ और विवरण आवश्यक हैं।';
  }

  return {
    status: finalStatus,
    summary,
    summaryHindi,
    checklist
  };
}
