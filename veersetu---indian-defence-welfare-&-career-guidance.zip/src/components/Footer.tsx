import React from 'react';
import { VeerEmblem } from './VeerEmblem';
import { translations } from '../data/translations';
import { Shield, ExternalLink, Heart, Lock } from 'lucide-react';

interface FooterProps {
  lang: 'en' | 'hi' | 'mr';
  onSelectCategory: (cat: any) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onSelectCategory, onOpenAdmin }) => {
  const t = translations[lang] || translations.en;

  const officialLinks = [
    { name: 'Ministry of Defence (MoD)', url: 'https://mod.gov.in' },
    { name: 'Department of Ex-Servicemen Welfare (DESW)', url: 'https://desw.gov.in' },
    { name: 'Join Indian Army Recruitment', url: 'https://joinindianarmy.nic.in' },
    { name: 'Kendriya Sainik Board (KSB)', url: 'https://ksb.gov.in' },
    { name: 'ECHS Central Organisation', url: 'https://echs.gov.in' },
    { name: 'Directorate General Resettlement (DGR)', url: 'https://dgrindia.gov.in' },
    { name: 'Union Public Service Commission (UPSC)', url: 'https://upsc.gov.in' },
    { name: 'SPARSH Defence Pension', url: 'https://sparsh.defencepension.gov.in' }
  ];

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand & Identity */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <VeerEmblem size={34} />
              <div>
                <span className="text-lg font-black tracking-wider text-white">
                  VEER<span className="text-amber-500">SETU</span>
                </span>
                <span className="text-[10px] font-semibold text-slate-400 block -mt-1 uppercase">
                  {t.shortTagline}
                </span>
              </div>
            </div>

            <p className="text-slate-400 leading-relaxed max-w-md">
              {t.fullTagline}
            </p>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-300 flex items-start gap-2">
              <Shield className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <span>{t.officialDisclaimer}</span>
            </div>
          </div>

          {/* Col 2: Services / Journeys */}
          <div className="space-y-2.5">
            <span className="font-bold text-white uppercase tracking-wider text-[11px] block">
              {lang === 'hi' ? 'सेवा वर्ग' : 'VeerSetu Portals'}
            </span>
            <ul className="space-y-1.5 text-slate-300">
              <li>
                <button
                  onClick={() => onSelectCategory('serving')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  🇮🇳 {lang === 'hi' ? 'सेवारत सैन्य कर्मी' : 'Serving Army Personnel'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('veteran')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  🎖️ {lang === 'hi' ? 'पूर्व सैनिक कल्याण' : 'Veteran / Ex-Servicemen'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('candidate')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  📚 {lang === 'hi' ? 'सेना भर्ती परीक्षाएं' : 'Aspiring Army Candidate'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('shaheed_family')}
                  className="hover:text-amber-400 transition-colors cursor-pointer text-left"
                >
                  🕊️ {lang === 'hi' ? 'शहीद परिवार सहायता' : 'Shaheed Family Support'}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Verified Portals */}
          <div className="space-y-2.5">
            <span className="font-bold text-white uppercase tracking-wider text-[11px] block">
              {lang === 'hi' ? 'आधिकारिक सरकारी पोर्टल' : 'Official Portals'}
            </span>
            <ul className="space-y-1.5">
              {officialLinks.slice(0, 5).map((l, idx) => (
                <li key={idx}>
                  <a
                    href={l.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-amber-400 transition-colors flex items-center gap-1 truncate text-slate-300"
                  >
                    <span className="truncate">{l.name}</span>
                    <ExternalLink className="w-3 h-3 text-slate-500 shrink-0" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Security & Non-Affiliation Declaration Banner */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400 space-y-1">
          <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
            <Lock className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'गैर-संबद्धता एवं विश्वास नीति:' : 'Non-Affiliation & Security Commitment:'}</span>
          </div>
          <p className="leading-relaxed">
            {t.trustSafetyNotice}
          </p>
        </div>

        {/* Bottom Line */}
        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            © 2026 VeerSetu. Dedicated in service to the Bravehearts of the Indian Armed Forces.
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenAdmin}
              className="text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              CMS Administration
            </button>
            <span aria-hidden="true">·</span>
            <span>Made with Respect for the Indian Army</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
