import React, { useState } from 'react';
import { SchemeOrExam, SchemeCategory, UserCategory } from '../types';
import { X, Plus, CheckCircle, RefreshCw, AlertTriangle, Building, Search, Edit3, Trash2 } from 'lucide-react';

interface AdminCmsModalProps {
  isOpen: boolean;
  onClose: () => void;
  schemes: SchemeOrExam[];
  onUpdateSchemes: (updatedList: SchemeOrExam[]) => void;
  lang: 'en' | 'hi' | 'mr';
}

export const AdminCmsModal: React.FC<AdminCmsModalProps> = ({
  isOpen,
  onClose,
  schemes,
  onUpdateSchemes,
  lang
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedScheme, setSelectedScheme] = useState<SchemeOrExam | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState('');

  // Form states for create/edit
  const [name, setName] = useState('');
  const [nameHindi, setNameHindi] = useState('');
  const [category, setCategory] = useState<SchemeCategory>('Financial');
  const [beneficiaryType, setBeneficiaryType] = useState<UserCategory | 'all'>('serving');
  const [isExam, setIsExam] = useState(false);
  const [targetAudience, setTargetAudience] = useState('');
  const [potentialBenefit, setPotentialBenefit] = useState('');
  const [eligibilityDescription, setEligibilityDescription] = useState('');
  const [officialUrl, setOfficialUrl] = useState('');
  const [officialName, setOfficialName] = useState('');
  const [department, setDepartment] = useState('Ministry of Defence');
  const [status, setStatus] = useState<'Active' | 'Updated' | 'Under Review' | 'Closed' | 'Archived'>('Active');
  const [lastVerifiedDate, setLastVerifiedDate] = useState('30 October 2026');

  if (!isOpen) return null;

  const filteredSchemes = schemes.filter((s) => {
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.officialSource.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleEditClick = (s: SchemeOrExam) => {
    setSelectedScheme(s);
    setIsCreatingNew(false);
    setName(s.name);
    setNameHindi(s.nameHindi || s.name);
    setCategory(s.category);
    setBeneficiaryType(s.beneficiaryType);
    setIsExam(s.isExam);
    setTargetAudience(s.targetAudience);
    setPotentialBenefit(s.potentialBenefit);
    setEligibilityDescription(s.eligibilityDescription);
    setOfficialUrl(s.officialSource.url);
    setOfficialName(s.officialSource.name);
    setDepartment(s.officialSource.department);
    setStatus(s.status);
    setLastVerifiedDate(s.lastVerifiedDate);
  };

  const handleStartCreate = () => {
    setSelectedScheme(null);
    setIsCreatingNew(true);
    setName('');
    setNameHindi('');
    setCategory('Financial');
    setBeneficiaryType('serving');
    setIsExam(false);
    setTargetAudience('');
    setPotentialBenefit('');
    setEligibilityDescription('');
    setOfficialUrl('https://mod.gov.in');
    setOfficialName('Ministry of Defence');
    setDepartment('Government of India');
    setStatus('Active');
    setLastVerifiedDate('30 October 2026');
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (isCreatingNew) {
      const newRecord: SchemeOrExam = {
        id: 'scheme_custom_' + Date.now(),
        name,
        nameHindi: nameHindi || name,
        category,
        beneficiaryType,
        isExam,
        targetAudience,
        targetAudienceHindi: targetAudience,
        potentialBenefit,
        potentialBenefitHindi: potentialBenefit,
        rules: {
          beneficiaryTypes: beneficiaryType === 'all' ? ['serving', 'veteran', 'shaheed_family'] : [beneficiaryType as UserCategory]
        },
        eligibilityDescription,
        eligibilityDescriptionHindi: eligibilityDescription,
        requiredDocuments: ['Aadhaar Card', 'Service / Discharge Documents', 'Bank Passbook'],
        requiredDocumentsHindi: ['आधार कार्ड', 'सेवा / डिस्चार्ज दस्तावेज', 'बैंक पासबुक'],
        howToApplySteps: [
          'Visit official government portal',
          'Fill details and upload verification documents',
          'Submit application to Zila Sainik Board or online'
        ],
        howToApplyStepsHindi: [
          'आधिकारिक सरकारी पोर्टल पर जाएं',
          'विवरण भरें और दस्तावेज अपलोड करें',
          'आवेदन जमा करें'
        ],
        officialSource: {
          name: officialName,
          url: officialUrl,
          department
        },
        lastVerifiedDate,
        status
      };
      const updated = [newRecord, ...schemes];
      onUpdateSchemes(updated);
      setFeedbackMsg('New record added and published!');
    } else if (selectedScheme) {
      const updated = schemes.map((s) => {
        if (s.id === selectedScheme.id) {
          return {
            ...s,
            name,
            nameHindi: nameHindi || s.nameHindi,
            category,
            beneficiaryType,
            isExam,
            targetAudience,
            potentialBenefit,
            eligibilityDescription,
            officialSource: {
              name: officialName,
              url: officialUrl,
              department
            },
            status,
            lastVerifiedDate
          };
        }
        return s;
      });
      onUpdateSchemes(updated);
      setFeedbackMsg('Record updated and verification timestamp synced!');
    }

    setIsCreatingNew(false);
    setSelectedScheme(null);
    setTimeout(() => setFeedbackMsg(''), 3000);
  };

  const handleQuickStatusChange = (id: string, newStatus: any) => {
    const updated = schemes.map((s) =>
      s.id === id ? { ...s, status: newStatus, lastVerifiedDate: '30 October 2026' } : s
    );
    onUpdateSchemes(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 pb-4 flex items-center justify-between border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold tracking-tight flex items-center gap-2">
              <Building className="w-5 h-5 text-amber-400" />
              <span>VeerSetu Government Scheme & Exam CMS</span>
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Admin Content Management System & Official Verification Workflow
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {feedbackMsg && (
          <div className="p-3 bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2 px-6">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>{feedbackMsg}</span>
          </div>
        )}

        {/* CMS Body Split: List on Left, Edit Form on Right (or full view) */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {!isCreatingNew && !selectedScheme ? (
            <div>
              {/* Controls bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div className="relative flex-1 min-w-[240px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search schemes by name or department..."
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="py-2 px-3 border border-slate-300 rounded-xl text-xs bg-white"
                  >
                    <option value="all">All Statuses ({schemes.length})</option>
                    <option value="Active">Active</option>
                    <option value="Updated">Updated</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Closed">Closed</option>
                    <option value="Archived">Archived</option>
                  </select>

                  <button
                    onClick={handleStartCreate}
                    className="py-2 px-4 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Scheme/Exam</span>
                  </button>
                </div>
              </div>

              {/* Data Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="p-3.5 pl-4">Name & Department</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Beneficiary</th>
                      <th className="p-3.5">Last Verified</th>
                      <th className="p-3.5">Status</th>
                      <th className="p-3.5 pr-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredSchemes.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="p-3.5 pl-4">
                          <span className="font-bold text-slate-900 block truncate max-w-xs">
                            {s.name}
                          </span>
                          <span className="text-slate-500 text-[11px]">
                            {s.officialSource.name}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-700 font-medium">
                          {s.category}
                        </td>
                        <td className="p-3.5">
                          <span className="font-semibold text-blue-900 capitalize">
                            {s.beneficiaryType.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-600 font-mono text-[11px]">
                          {s.lastVerifiedDate}
                        </td>
                        <td className="p-3.5">
                          <select
                            value={s.status}
                            onChange={(e) => handleQuickStatusChange(s.id, e.target.value)}
                            className={`py-1 px-2 rounded-lg text-[11px] font-bold border cursor-pointer ${
                              s.status === 'Active'
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : s.status === 'Updated'
                                ? 'bg-blue-50 text-blue-800 border-blue-200'
                                : s.status === 'Under Review'
                                ? 'bg-amber-50 text-amber-800 border-amber-200'
                                : 'bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                          >
                            <option value="Active">Active</option>
                            <option value="Updated">Updated</option>
                            <option value="Under Review">Under Review</option>
                            <option value="Closed">Closed</option>
                            <option value="Archived">Archived</option>
                          </select>
                        </td>
                        <td className="p-3.5 pr-4 text-right">
                          <button
                            onClick={() => handleEditClick(s)}
                            className="py-1 px-2.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-white hover:text-blue-900 transition-colors font-semibold text-[11px] cursor-pointer"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* CREATE OR EDIT FORM */
            <form onSubmit={handleSaveForm} className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b">
                <h3 className="text-base font-bold text-slate-900">
                  {isCreatingNew ? 'Create New Scheme / Examination Record' : `Edit: ${name}`}
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingNew(false);
                    setSelectedScheme(null);
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 font-semibold cursor-pointer"
                >
                  Cancel & Back to Table
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Scheme/Exam Name (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Scheme/Exam Name (Hindi)
                  </label>
                  <input
                    type="text"
                    value={nameHindi}
                    onChange={(e) => setNameHindi(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white"
                  >
                    <option value="Financial">Financial</option>
                    <option value="Medical">Medical</option>
                    <option value="Education">Education</option>
                    <option value="Employment">Employment</option>
                    <option value="Housing">Housing</option>
                    <option value="Pension">Pension</option>
                    <option value="Scholarship">Scholarship</option>
                    <option value="Recruitment">Recruitment</option>
                    <option value="CSD / Concessions">CSD / Concessions</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Beneficiary Type
                  </label>
                  <select
                    value={beneficiaryType}
                    onChange={(e) => setBeneficiaryType(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white"
                  >
                    <option value="serving">Serving</option>
                    <option value="veteran">Veteran</option>
                    <option value="candidate">Candidate</option>
                    <option value="shaheed_family">Shaheed Family</option>
                    <option value="all">All Groups</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Record Type
                  </label>
                  <select
                    value={isExam ? 'exam' : 'scheme'}
                    onChange={(e) => setIsExam(e.target.value === 'exam')}
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white"
                  >
                    <option value="scheme">Welfare Scheme</option>
                    <option value="exam">Recruitment Examination</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 border rounded-xl text-xs bg-white"
                  >
                    <option value="Active">Active</option>
                    <option value="Updated">Updated</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Closed">Closed</option>
                    <option value="Archived">Archived</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Beneficiary Group / Who can benefit
                </label>
                <input
                  type="text"
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Potential Benefit (Verified description/amount)
                </label>
                <textarea
                  rows={2}
                  value={potentialBenefit}
                  onChange={(e) => setPotentialBenefit(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Eligibility Rules & Criteria Explanation
                </label>
                <textarea
                  rows={2}
                  value={eligibilityDescription}
                  onChange={(e) => setEligibilityDescription(e.target.value)}
                  className="w-full px-3 py-2 border rounded-xl text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Official Portal Name
                  </label>
                  <input
                    type="text"
                    value={officialName}
                    onChange={(e) => setOfficialName(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Official Portal URL
                  </label>
                  <input
                    type="url"
                    value={officialUrl}
                    onChange={(e) => setOfficialUrl(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Last Verified Date
                  </label>
                  <input
                    type="text"
                    value={lastVerifiedDate}
                    onChange={(e) => setLastVerifiedDate(e.target.value)}
                    className="w-full px-3 py-2 border rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="pt-4 border-t flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingNew(false);
                    setSelectedScheme(null);
                  }}
                  className="py-2.5 px-4 rounded-xl border border-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-6 rounded-xl bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold shadow"
                >
                  Save Record
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
