import React, { useState } from 'react';
import { ShieldCheck, Compass, Award, ArrowRight, ArrowLeft } from 'lucide-react';

interface OnboardingModalProps {
  onComplete: () => void;
  lang: 'en' | 'hi' | 'mr';
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete, lang }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const screens = [
    {
      icon: ShieldCheck,
      iconColor: 'text-blue-700 bg-blue-50 border-blue-200',
      title: lang === 'hi' ? 'वीरसेतु में आपका स्वागत है' : 'Welcome to VeerSetu',
      subtitle:
        lang === 'hi'
          ? 'सेना कल्याण योजनाओं, पूर्व सैनिक लाभों, शहीद परिवार सहायता और सेना करियर अवसरों के लिए आपका एकल मंच।'
          : 'Your single platform for Army welfare schemes, veteran benefits, Shaheed family support and Army career opportunities.',
      kicker: lang === 'hi' ? 'एक सेतु · हर वीर' : 'Centralized Defence Portal'
    },
    {
      icon: Award,
      iconColor: 'text-amber-700 bg-amber-50 border-amber-200',
      title: lang === 'hi' ? 'अपने संभावित लाभ खोजें' : 'Find Benefits You May Be Eligible For',
      subtitle:
        lang === 'hi'
          ? 'अपनी पात्रता जानकारी दर्ज करें और उपयुक्त सरकारी एवं रक्षा कल्याण योजनाओं की खोज करें।'
          : 'Enter your details and discover relevant government and defence welfare schemes.',
      kicker: lang === 'hi' ? 'सटीक पात्रता जांच' : 'Intelligent Eligibility Matching'
    },
    {
      icon: Compass,
      iconColor: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      title: lang === 'hi' ? 'अपना सेना करियर मार्ग चुनें' : 'Find Your Army Career Path',
      subtitle:
        lang === 'hi'
          ? 'इच्छुक अभ्यर्थियों के लिए: आयु, शिक्षा और योग्यता के अनुसार सेना भर्ती परीक्षाएं और प्रवेश मार्ग खोजें।'
          : 'For aspiring candidates, discover Army examinations and entry routes according to age, education and gender.',
      kicker: lang === 'hi' ? 'एनडीए, सीडीएस, टीईएस एवं अग्निवीर' : 'Army Entry Routes Only'
    }
  ];

  const current = screens[currentStep];
  const IconComponent = current.icon;

  const handleNext = () => {
    if (currentStep < screens.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Top Progress Tracker */}
        <div className="p-6 pb-2 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            {screens.map((_, idx) => (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all duration-300 ${
                  idx === currentStep
                    ? 'w-8 bg-blue-900'
                    : idx < currentStep
                    ? 'w-3 bg-blue-300'
                    : 'w-3 bg-slate-200'
                }`}
              />
            ))}
          </div>
          <button
            onClick={onComplete}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer py-1 px-2.5 rounded-lg hover:bg-slate-100"
          >
            {lang === 'hi' ? 'छोड़ें (Skip)' : 'Skip'}
          </button>
        </div>

        {/* Content Body */}
        <div className="p-8 flex flex-col items-center text-center">
          <div className={`w-20 h-20 rounded-2xl border flex items-center justify-center mb-6 shadow-sm ${current.iconColor}`}>
            <IconComponent className="w-10 h-10" />
          </div>

          <span className="text-xs font-bold uppercase tracking-wider text-amber-700 mb-2">
            {current.kicker}
          </span>

          <h2 className="text-2xl font-bold text-slate-900 mb-4 leading-snug">
            {current.title}
          </h2>

          <p className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-md">
            {current.subtitle}
          </p>
        </div>

        {/* Bottom Actions */}
        <div className="p-6 pt-2 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-4">
          {currentStep > 0 ? (
            <button
              onClick={handleBack}
              className="flex items-center gap-1.5 py-2.5 px-4 rounded-xl text-slate-700 font-medium text-sm hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{lang === 'hi' ? 'पीछे' : 'Back'}</span>
            </button>
          ) : (
            <div />
          )}

          <button
            onClick={handleNext}
            className="ml-auto flex items-center gap-2 py-3 px-6 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-sm shadow-md transition-all cursor-pointer active:scale-95"
          >
            <span>
              {currentStep === screens.length - 1
                ? (lang === 'hi' ? 'शुरू करें (Get Started)' : 'Get Started')
                : (lang === 'hi' ? 'आगे बढ़ें' : 'Continue')}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
