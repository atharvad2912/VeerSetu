import React, { useState } from 'react';
import { UserProfile, UserCategory } from '../types';
import { INDIAN_STATES } from '../data/translations';
import { CategorySelector } from './CategorySelector';
import { ShieldCheck, Phone, Lock, User, Calendar, MapPin, CheckCircle, ArrowRight, X } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
  lang: 'en' | 'hi' | 'mr';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  lang
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'otp' | 'category'>('login');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [dob, setDob] = useState('2002-05-15');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [state, setState] = useState('Rajasthan');
  const [district, setDistrict] = useState('Jaipur');
  const [otpCode, setOtpCode] = useState('');
  const [simulatedOtp, setSimulatedOtp] = useState('789012');
  const [selectedCategory, setSelectedCategory] = useState<UserCategory>('candidate');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleStartRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!fullName.trim()) {
      setErrorMsg(lang === 'hi' ? 'कृपया अपना पूरा नाम दर्ज करें' : 'Please enter your full name');
      return;
    }
    if (mobile.length < 10) {
      setErrorMsg(lang === 'hi' ? 'कृपया वैध 10-अंकीय मोबाइल नंबर दर्ज करें' : 'Please enter a valid 10-digit mobile number');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg(lang === 'hi' ? 'पासवर्ड मेल नहीं खाते हैं' : 'Passwords do not match');
      return;
    }
    // Generate simulated OTP
    const genOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setSimulatedOtp(genOtp);
    setOtpCode(genOtp); // prefill for testing convenience
    setAuthMode('otp');
  };

  const handleVerifyOtp = () => {
    if (otpCode !== simulatedOtp && otpCode !== '123456') {
      setErrorMsg(lang === 'hi' ? 'अमान्य ओटीपी कोड' : 'Invalid OTP code. Please enter the simulated code.');
      return;
    }
    setErrorMsg('');
    setAuthMode('category');
  };

  const handleFinishCategory = (category: UserCategory) => {
    setSelectedCategory(category);
    const newUser: UserProfile = {
      id: 'user_' + Date.now(),
      fullName,
      mobile,
      email: email || undefined,
      dob,
      gender,
      state,
      district,
      category,
      savedSchemeIds: [],
      savedExamIds: [],
      notificationPreferences: {
        recruitment: true,
        scholarships: true,
        schemeUpdates: true
      },
      candidateDetails: category === 'candidate' ? {
        dateOfBirth: dob,
        gender,
        educationLevel: '12th Pass',
        class10Percentage: 82,
        class12Percentage: 78,
        class12Stream: 'PCM',
        isGraduate: false,
        nccCertificate: 'None',
        jeeMainAppeared: true,
        medicalFitnessStatus: 'Fit'
      } : undefined,
      servingDetails: category === 'serving' ? {
        rank: 'Havildar',
        serviceCategory: 'Other Ranks / Agniveer',
        dateOfJoining: '2016-04-10',
        dateOfBirth: dob,
        postingState: state,
        maritalStatus: 'Married',
        spouseName: 'Anita',
        childrenCount: 2,
        childrenAges: [7, 5],
        educationLevel: 'Senior Secondary (12th)',
        hasDisability: false,
        isBattleCasualty: false
      } : undefined,
      veteranDetails: category === 'veteran' ? {
        rankAtRetirement: 'Subedar Major',
        serviceCategory: 'JCO',
        dateOfRetirement: '2023-01-31',
        dateOfBirth: dob,
        isPensioner: true,
        pensionType: 'Service',
        hasDisability: false,
        maritalStatus: 'Married',
        childrenCount: 2,
        dependentsCount: 3,
        state,
        district
      } : undefined,
      shaheedFamilyDetails: category === 'shaheed_family' ? {
        relationshipToShaheed: 'Widow (Veer Nari)',
        state,
        district,
        yearOfCasualty: 2021,
        deceasedRank: 'Naik',
        deceasedServiceCategory: 'Other Ranks',
        casualtyCategory: 'Battle Casualty (Operations)',
        isWidowRemarried: false,
        childrenCount: 2,
        childrenAges: [12, 9],
        hasDisabledDependents: false,
        existingPensionStatus: 'Liberalised Family Pension'
      } : undefined
    };

    onLoginSuccess(newUser);
    onClose();
  };

  const handleSimpleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobile.length < 10) {
      setErrorMsg(lang === 'hi' ? 'कृपया 10-अंकीय मोबाइल नंबर दर्ज करें' : 'Please enter valid 10-digit mobile number');
      return;
    }
    // Load mock user profile
    const existingUser: UserProfile = {
      id: 'demo_user',
      fullName: 'Sapper Ramesh Singh',
      mobile,
      dob: '1998-03-12',
      gender: 'Male',
      state: 'Punjab',
      district: 'Jalandhar',
      category: 'serving',
      savedSchemeIds: ['serving-cea', 'serving-csd'],
      savedExamIds: [],
      notificationPreferences: { recruitment: true, scholarships: true, schemeUpdates: true },
      servingDetails: {
        rank: 'Naik',
        serviceCategory: 'Other Ranks / Agniveer',
        dateOfJoining: '2017-08-15',
        dateOfBirth: '1998-03-12',
        postingState: 'Punjab',
        maritalStatus: 'Married',
        childrenCount: 2,
        childrenAges: [6, 4],
        educationLevel: '12th Pass',
        hasDisability: false,
        isBattleCasualty: false
      }
    };
    onLoginSuccess(existingUser);
    onClose();
  };

  const loadDemoPreset = (presetCategory: UserCategory) => {
    let preset: UserProfile;

    if (presetCategory === 'candidate') {
      preset = {
        id: 'candidate_demo',
        fullName: 'Aman Sharma',
        mobile: '9876543210',
        email: 'aman.defence@example.com',
        dob: '2008-01-15', // ~18.8 years old in Oct 2026
        gender: 'Male',
        state: 'Haryana',
        district: 'Rohtak',
        category: 'candidate',
        savedSchemeIds: [],
        savedExamIds: ['exam-nda', 'exam-tes'],
        notificationPreferences: { recruitment: true, scholarships: true, schemeUpdates: true },
        candidateDetails: {
          dateOfBirth: '2008-01-15',
          gender: 'Male',
          educationLevel: '12th Pass',
          class10Percentage: 86,
          class12Percentage: 82,
          class12Stream: 'PCM',
          isGraduate: false,
          nccCertificate: 'B',
          jeeMainAppeared: true,
          medicalFitnessStatus: 'Fit'
        }
      };
    } else if (presetCategory === 'veteran') {
      preset = {
        id: 'veteran_demo',
        fullName: 'Subedar Major (Retd) Balwinder Singh',
        mobile: '9812345678',
        email: 'balwinder.veteran@example.com',
        dob: '1968-07-20',
        gender: 'Male',
        state: 'Punjab',
        district: 'Gurdaspur',
        category: 'veteran',
        savedSchemeIds: ['veteran-echs', 'veteran-pmss'],
        savedExamIds: [],
        notificationPreferences: { recruitment: false, scholarships: true, schemeUpdates: true },
        veteranDetails: {
          rankAtRetirement: 'Subedar Major',
          serviceCategory: 'JCO',
          dateOfRetirement: '2021-08-31',
          dateOfBirth: '1968-07-20',
          isPensioner: true,
          pensionType: 'Service',
          hasDisability: false,
          maritalStatus: 'Married',
          spouseName: 'Kuldeep Kaur',
          childrenCount: 2,
          dependentsCount: 2,
          state: 'Punjab',
          district: 'Gurdaspur'
        }
      };
    } else if (presetCategory === 'shaheed_family') {
      preset = {
        id: 'shaheed_demo',
        fullName: 'Smt. Sunita Devi (Veer Nari)',
        mobile: '9456781234',
        email: 'sunita.veernari@example.com',
        dob: '1989-11-04',
        gender: 'Female',
        state: 'Rajasthan',
        district: 'Jhunjhunu',
        category: 'shaheed_family',
        savedSchemeIds: ['shaheed-ex-gratia', 'shaheed-liberalised-pension', 'shaheed-echs-exempted'],
        savedExamIds: [],
        notificationPreferences: { recruitment: false, scholarships: true, schemeUpdates: true },
        shaheedFamilyDetails: {
          relationshipToShaheed: 'Widow (Veer Nari)',
          state: 'Rajasthan',
          district: 'Jhunjhunu',
          yearOfCasualty: 2020,
          deceasedRank: 'Havildar',
          deceasedServiceCategory: 'Other Ranks',
          casualtyCategory: 'Battle Casualty (Operations)',
          isWidowRemarried: false,
          childrenCount: 2,
          childrenAges: [14, 11],
          hasDisabledDependents: false,
          existingPensionStatus: 'Liberalised Family Pension'
        }
      };
    } else {
      preset = {
        id: 'serving_demo',
        fullName: 'Havildar Virender Singh',
        mobile: '9123456780',
        email: 'virender.serving@example.com',
        dob: '1995-04-18',
        gender: 'Male',
        state: 'Himachal Pradesh',
        district: 'Kangra',
        category: 'serving',
        savedSchemeIds: ['serving-cea', 'serving-agif-cover', 'serving-csd'],
        savedExamIds: [],
        notificationPreferences: { recruitment: true, scholarships: true, schemeUpdates: true },
        servingDetails: {
          rank: 'Havildar',
          serviceCategory: 'Other Ranks / Agniveer',
          dateOfJoining: '2014-06-12',
          dateOfBirth: '1995-04-18',
          postingState: 'Himachal Pradesh',
          maritalStatus: 'Married',
          spouseName: 'Pooja',
          childrenCount: 2,
          childrenAges: [8, 5],
          educationLevel: 'Graduate Pass',
          hasDisability: false,
          isBattleCasualty: false
        }
      };
    }

    onLoginSuccess(preset);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Top Header */}
        <div className="bg-slate-900 text-white p-6 pb-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-800 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">
                {authMode === 'category'
                  ? (lang === 'hi' ? 'अपनी सेवा श्रेणी चुनें' : 'Select Service Category')
                  : authMode === 'otp'
                  ? (lang === 'hi' ? 'मोबाइल नंबर सत्यापन' : 'Mobile OTP Verification')
                  : authMode === 'register'
                  ? (lang === 'hi' ? 'वीरसेतु प्रोफ़ाइल बनाएं' : 'Create Your VeerSetu Profile')
                  : (lang === 'hi' ? 'वीरसेतु में लॉग इन करें' : 'Sign In to VeerSetu')}
              </h2>
              <p className="text-xs text-slate-300">
                {lang === 'hi' ? 'सत्यापित एवं सुरक्षित रक्षा कल्याण मंच' : 'Secure & Confidential Defence Welfare Portal'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Demo Persona Switcher Strip */}
        <div className="bg-amber-50 border-b border-amber-200/80 p-3 px-6 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="font-semibold text-amber-900">
            {lang === 'hi' ? 'त्वरित डेमो परीक्षण (एक क्लिक में लॉगिन):' : 'Quick Demo Presets:'}
          </span>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => loadDemoPreset('serving')}
              className="py-1 px-2.5 rounded-md bg-white border border-amber-300 text-slate-800 hover:bg-amber-100 font-medium transition-colors cursor-pointer"
            >
              🇮🇳 Serving
            </button>
            <button
              onClick={() => loadDemoPreset('veteran')}
              className="py-1 px-2.5 rounded-md bg-white border border-amber-300 text-slate-800 hover:bg-amber-100 font-medium transition-colors cursor-pointer"
            >
              🎖️ Veteran
            </button>
            <button
              onClick={() => loadDemoPreset('candidate')}
              className="py-1 px-2.5 rounded-md bg-white border border-amber-300 text-slate-800 hover:bg-amber-100 font-medium transition-colors cursor-pointer"
            >
              📚 Candidate
            </button>
            <button
              onClick={() => loadDemoPreset('shaheed_family')}
              className="py-1 px-2.5 rounded-md bg-white border border-amber-300 text-slate-800 hover:bg-amber-100 font-medium transition-colors cursor-pointer"
            >
              🕊️ Shaheed Family
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
            <span>⚠️</span>
            <span>{errorMsg}</span>
          </div>
        )}

        {/* STEP 1: LOGIN */}
        {authMode === 'login' && (
          <form onSubmit={handleSimpleLogin} className="p-6 sm:p-8 space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'hi' ? 'मोबाइल नंबर' : 'Mobile Number'}
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm font-semibold">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  required
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-900 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'hi' ? 'पासवर्ड' : 'Password'}
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-900 text-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-sm transition-all shadow-md active:scale-98 cursor-pointer"
            >
              {lang === 'hi' ? 'लॉग इन करें' : 'Sign In'}
            </button>

            <div className="pt-4 text-center border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500">
                {lang === 'hi' ? 'खाता नहीं है?' : "Don't have a profile yet?"}
              </span>
              <button
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setAuthMode('register');
                }}
                className="font-bold text-blue-900 hover:underline cursor-pointer"
              >
                {lang === 'hi' ? 'नया प्रोफ़ाइल बनाएं (Register)' : 'Create Your Profile'}
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: REGISTRATION */}
        {authMode === 'register' && (
          <form onSubmit={handleStartRegister} className="p-6 sm:p-8 space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'पूरा नाम *' : 'Full Name *'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Ramesh Kumar"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'मोबाइल नंबर *' : 'Mobile Number *'}
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    maxLength={10}
                    required
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="9876543210"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'ईमेल (वैकल्पिक)' : 'Email Address (Optional)'}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'जन्म तिथि *' : 'Date of Birth *'}
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'लिंग *' : 'Gender *'}
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-900 focus:outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'राज्य *' : 'State *'}
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white focus:ring-2 focus:ring-blue-900 focus:outline-none"
                  >
                    {INDIAN_STATES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'जिला *' : 'District *'}
                </label>
                <input
                  type="text"
                  required
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  placeholder="e.g. Kangra, Pune, Jaipur"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'पासवर्ड बनाएं *' : 'Password *'}
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'hi' ? 'पासवर्ड की पुष्टि करें *' : 'Confirm Password *'}
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-sm transition-all shadow-md active:scale-98 cursor-pointer flex items-center justify-center gap-2 mt-4"
            >
              <span>{lang === 'hi' ? 'ओटीपी प्राप्त करें' : 'Proceed to Mobile OTP'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="pt-2 text-center text-xs">
              <button
                type="button"
                onClick={() => setAuthMode('login')}
                className="text-slate-500 hover:text-slate-800"
              >
                {lang === 'hi' ? 'पहले से खाता है? लॉगिन करें' : 'Already registered? Sign in'}
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: OTP VERIFICATION */}
        {authMode === 'otp' && (
          <div className="p-6 sm:p-8 space-y-6 text-center">
            <div className="w-16 h-16 bg-blue-50 text-blue-900 border border-blue-200 rounded-full flex items-center justify-center mx-auto">
              <Phone className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-900">
                {lang === 'hi' ? 'ओटीपी सत्यापित करें' : 'Verify Mobile OTP'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {lang === 'hi'
                  ? `6-अंकीय कोड +91 ${mobile} पर भेजा गया है`
                  : `A 6-digit code has been sent to +91 ${mobile}`}
              </p>
            </div>

            {/* Test helper banner */}
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
              <span className="font-semibold">
                {lang === 'hi' ? 'सिम्युलेटेड टेस्ट कोड: ' : 'Simulated Test OTP: '}
              </span>
              <span className="font-mono font-bold tracking-widest text-amber-950 ml-1">
                {simulatedOtp}
              </span>
            </div>

            <div className="max-w-xs mx-auto">
              <input
                type="text"
                maxLength={6}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                placeholder="123456"
                className="w-full py-3 text-center font-mono text-2xl tracking-[0.5em] font-bold border-2 border-slate-300 rounded-xl focus:border-blue-900 focus:outline-none"
              />
            </div>

            <button
              onClick={handleVerifyOtp}
              className="w-full max-w-xs py-3.5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-sm transition-all shadow-md active:scale-98 cursor-pointer mx-auto flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{lang === 'hi' ? 'ओटीपी सत्यापित करें' : 'Verify & Continue'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
                setSimulatedOtp(newOtp);
                setOtpCode(newOtp);
              }}
              className="text-xs font-semibold text-blue-900 hover:underline block mx-auto cursor-pointer"
            >
              {lang === 'hi' ? 'नया ओटीपी कोड पुनः भेजें' : 'Resend OTP Code'}
            </button>
          </div>
        )}

        {/* STEP 4: CATEGORY SELECTION */}
        {authMode === 'category' && (
          <div className="p-6 max-h-[75vh] overflow-y-auto">
            <CategorySelector
              selectedCategory={selectedCategory}
              onSelect={handleFinishCategory}
              lang={lang}
              isEmbedded={true}
            />
          </div>
        )}
      </div>
    </div>
  );
};
