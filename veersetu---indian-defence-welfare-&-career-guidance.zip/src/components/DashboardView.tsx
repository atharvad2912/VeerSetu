import React, { useState } from 'react';
import { UserProfile, SchemeOrExam, UserCategory, SchemeCategory } from '../types';
import { SchemeCard } from './SchemeCard';
import { VeerEmblem } from './VeerEmblem';
import { translations } from '../data/translations';
import { Shield, Award, GraduationCap, Heart, Search, CheckCircle, FileText, ExternalLink, HelpCircle, AlertCircle, Sparkles, Filter, ChevronRight, UserCheck } from 'lucide-react';

interface DashboardViewProps {
  user: UserProfile | null;
  schemes: SchemeOrExam[];
  onOpenDetails: (scheme: SchemeOrExam) => void;
  onToggleSave: (id: string, isExam: boolean) => void;
  onSelectCategory: (cat: UserCategory) => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onQuickSearch: (query: string) => void;
  lang: 'en' | 'hi' | 'mr';
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  schemes,
  onOpenDetails,
  onToggleSave,
  onSelectCategory,
  onOpenAuth,
  onOpenProfile,
  onQuickSearch,
  lang
}) => {
  const t = translations[lang] || translations.en;
  const [searchInput, setSearchInput] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('all');

  const activeCategory: UserCategory = user ? user.category : 'serving';

  // Subcategories mapping according to Section 7, 8, 9, 11 of the brief
  const getSubcategories = (cat: UserCategory) => {
    switch (cat) {
      case 'serving':
        return [
          { id: 'all', label: lang === 'hi' ? 'सभी सेवारत लाभ' : 'All Serving Benefits' },
          { id: 'Insurance', label: lang === 'hi' ? 'बीमा व सुरक्षा' : 'Insurance (AGIF)' },
          { id: 'Children & Scholarships', label: lang === 'hi' ? 'बच्चे एवं छात्रवृत्ति' : 'Education & CEA' },
          { id: 'Medical', label: lang === 'hi' ? 'चिकित्सा लाभ' : 'Medical (MH/Base)' },
          { id: 'Housing', label: lang === 'hi' ? 'आवास (AWHO)' : 'Housing (AWHO)' },
          { id: 'CSD / Concessions', label: lang === 'hi' ? 'सीएसडी कैंटीन' : 'CSD & Concessions' },
          { id: 'Financial', label: lang === 'hi' ? 'वित्तीय सहायता' : 'Financial & Welfare' }
        ];
      case 'veteran':
        return [
          { id: 'all', label: lang === 'hi' ? 'सभी पूर्व सैनिक योजनाएं' : 'All Veteran Schemes' },
          { id: 'Medical', label: lang === 'hi' ? 'स्वास्थ्य (ECHS)' : 'Healthcare (ECHS)' },
          { id: 'Scholarship', label: lang === 'hi' ? 'पीएमएसएस छात्रवृत्ति' : 'PMSS Scholarship' },
          { id: 'Pension', label: lang === 'hi' ? 'पेंशन व निर्धनता' : 'Pension & Penury' },
          { id: 'Employment', label: lang === 'hi' ? 'पुनर्वास व रोजगार' : 'Employment & DGR' },
          { id: 'Marriage & Family Support', label: lang === 'hi' ? 'पुत्री विवाह अनुदान' : 'Family & Marriage' }
        ];
      case 'candidate':
        return [
          { id: 'all', label: lang === 'hi' ? 'सभी सेना प्रवेश मार्ग' : 'All Entry Routes' },
          { id: '10+2', label: lang === 'hi' ? '12वीं उत्तीर्ण (NDA & TES)' : '10+2 Entries (NDA, TES)' },
          { id: 'Graduates', label: lang === 'hi' ? 'स्नातक (CDS, NCC, TGC)' : 'Graduate (CDS, TGC, NCC)' },
          { id: 'Specialist', label: lang === 'hi' ? 'विशेषज्ञ (Law, Tech, Medical)' : 'Specialist (JAG, AMC, SSC)' },
          { id: 'Agniveer', label: lang === 'hi' ? 'अग्निवीर रैलियां' : 'Agniveer Recruitment' }
        ];
      case 'shaheed_family':
        return [
          { id: 'all', label: lang === 'hi' ? 'सभी शहीद परिवार योजनाएं' : 'All Shaheed Support' },
          { id: 'Financial', label: lang === 'hi' ? 'अनुग्रह व कल्याण कोष' : 'Ex-Gratia & AFBCWF' },
          { id: 'Pension', label: lang === 'hi' ? 'उदारीकृत पेंशन (LFP)' : 'Liberalised Pension' },
          { id: 'Medical', label: lang === 'hi' ? 'निशुल्क ईसीएचएस' : 'Free ECHS Healthcare' },
          { id: 'Scholarship', label: lang === 'hi' ? 'प्राथमिकता 1 छात्रवृत्ति' : 'Priority 1 Scholarships' },
          { id: 'Employment', label: lang === 'hi' ? 'अनुकंपा नियुक्ति' : 'Compassionate Jobs' }
        ];
    }
  };

  const subCategories = getSubcategories(activeCategory);

  // Filter schemes based on active category
  const categorySchemes = schemes.filter((s) => {
    // HARD RULE: Aspiring Candidates ONLY see exams. Never show welfare schemes to candidates!
    if (activeCategory === 'candidate') {
      return s.isExam === true;
    }
    // For other categories, do not show civilian recruitment exams
    if (s.isExam) return false;

    // Filter by beneficiary type
    const matchesBeneficiary = s.beneficiaryType === activeCategory || s.beneficiaryType === 'all';

    // Subcategory filter
    if (selectedSubCategory !== 'all') {
      if (s.category !== selectedSubCategory) return false;
    }

    return matchesBeneficiary;
  });

  // Candidate subcategory specific filter logic
  const candidateFilteredSchemes = schemes.filter((s) => {
    if (!s.isExam) return false;
    if (selectedSubCategory === 'all') return true;
    if (selectedSubCategory === '10+2') {
      return s.id === 'exam-nda' || s.id === 'exam-tes';
    }
    if (selectedSubCategory === 'Graduates') {
      return s.id === 'exam-cds' || s.id === 'exam-ncc-special' || s.id === 'exam-tgc';
    }
    if (selectedSubCategory === 'Specialist') {
      return s.id === 'exam-ssc-tech' || s.id === 'exam-jag' || s.id === 'exam-amc';
    }
    if (selectedSubCategory === 'Agniveer') {
      return s.id.includes('agniveer');
    }
    return true;
  });

  const displayedSchemes = activeCategory === 'candidate' ? candidateFilteredSchemes : categorySchemes;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onQuickSearch(searchInput.trim());
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* HERO BANNER SECTION */}
      <section className="relative overflow-hidden rounded-3xl bg-slate-900 text-white p-6 sm:p-10 border border-slate-800 shadow-xl">
        {/* Subtle decorative light mesh */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700 text-xs font-semibold text-amber-400 mb-4">
              <span>🇮🇳</span>
              <span>{t.shortTagline}</span>
            </div>

            <div className="flex items-center gap-3 mb-3">
              <VeerEmblem size={44} className="md:hidden" />
              <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white">
                VEER<span className="text-amber-500">SETU</span>
              </h1>
            </div>

            <p className="text-base sm:text-xl text-slate-300 font-medium leading-relaxed mb-6">
              {t.fullTagline}
            </p>

          {/* Prominent Universal Search Bar */}
          <form onSubmit={handleSearchSubmit} className="relative max-w-2xl mb-4">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-12 pr-28 py-4 rounded-2xl bg-white text-slate-900 placeholder-slate-400 font-medium text-sm sm:text-base shadow-lg focus:outline-none focus:ring-4 focus:ring-amber-500/30"
            />
            <button
              type="submit"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 py-2.5 px-5 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-xs sm:text-sm transition-all cursor-pointer shadow"
            >
              {lang === 'hi' ? 'खोजें' : 'Search'}
            </button>
          </form>

          {/* User Welcome / Status strip */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-1">
            {user ? (
              <div className="flex items-center gap-2">
                <span className="text-white font-semibold">
                  {lang === 'hi' ? 'स्वागत है,' : 'Welcome,'} {user.fullName}
                </span>
                <span aria-hidden="true">·</span>
                <span className="text-amber-400 font-medium">
                  {user.category === 'serving'
                    ? (lang === 'hi' ? 'सेवारत सैन्य कर्मी' : 'Serving Personnel')
                    : user.category === 'veteran'
                    ? (lang === 'hi' ? 'पूर्व सैनिक' : 'Veteran')
                    : user.category === 'candidate'
                    ? (lang === 'hi' ? 'अभ्यर्थी' : 'Aspiring Candidate')
                    : (lang === 'hi' ? 'शहीद परिवार' : 'Shaheed Family')}
                </span>
                <button
                  onClick={onOpenProfile}
                  className="underline text-slate-300 hover:text-white cursor-pointer ml-1"
                >
                  {lang === 'hi' ? 'प्रोफ़ाइल संपादित करें' : 'Edit Profile'}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span>{lang === 'hi' ? 'सटीक पात्रता जांच हेतु लॉगिन करें:' : 'For personalized eligibility matching:'}</span>
                <button
                  onClick={onOpenAuth}
                  className="text-amber-400 font-bold hover:underline cursor-pointer"
                >
                  {lang === 'hi' ? 'प्रोफ़ाइल बनाएं / लॉगिन' : 'Sign In / Register'}
                </button>
              </div>
            )}
          </div>
          </div>

          {/* Desktop Official Logo Card */}
          <div className="hidden md:flex flex-col items-center shrink-0 w-64 rounded-2xl overflow-hidden border border-slate-700/60 shadow-2xl bg-[#081325] p-2">
            <VeerEmblem variant="full" />
          </div>
        </div>
      </section>

      {/* STATUTORY DISCLAIMER (Required by section 6 & 19) */}
      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200/90 text-xs text-amber-950 flex items-start gap-3">
        <Shield className="w-5 h-5 text-amber-800 shrink-0 mt-0.5" />
        <div className="space-y-0.5 leading-relaxed">
          <p className="font-bold">
            {t.officialDisclaimer}
          </p>
          <p className="text-amber-900 text-[11px]">
            {t.trustSafetyNotice}
          </p>
        </div>
      </div>

      {/* CHOOSE YOUR JOURNEY - 4 MAIN CATEGORY CARDS */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
              {lang === 'hi' ? 'अपनी सेवा यात्रा चुनें' : 'Choose Your Journey'}
            </h2>
            <p className="text-xs text-slate-500">
              {lang === 'hi'
                ? 'अपनी श्रेणी पर क्लिक कर संपूर्ण पोर्टल को तुरंत अनुकूलित करें'
                : 'Click any category to personalize the guidance feed and eligibility calculations'}
            </p>
          </div>
          {user && (
            <button
              onClick={onOpenProfile}
              className="text-xs font-semibold text-blue-900 hover:underline cursor-pointer"
            >
              {lang === 'hi' ? 'मेरी प्रोफ़ाइल' : 'My Settings'}
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Serving */}
          <div
            onClick={() => onSelectCategory('serving')}
            className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              activeCategory === 'serving'
                ? 'border-blue-900 bg-blue-50/40 shadow-md ring-2 ring-blue-900/10'
                : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">🇮🇳</span>
                {activeCategory === 'serving' && (
                  <span className="text-[10px] bg-blue-900 text-white font-bold px-2 py-0.5 rounded-full">
                    Active
                  </span>
                )}
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">
                {t.servingCategory}
              </h3>
              <p className="text-xs text-slate-600 line-clamp-2">
                {t.servingCategoryDesc}
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold text-blue-900">
              <span>{lang === 'hi' ? 'योजनाएं देखें' : 'View Schemes'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 2: Veteran */}
          <div
            onClick={() => onSelectCategory('veteran')}
            className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              activeCategory === 'veteran'
                ? 'border-amber-600 bg-amber-50/40 shadow-md ring-2 ring-amber-600/10'
                : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">🎖️</span>
                {activeCategory === 'veteran' && (
                  <span className="text-[10px] bg-amber-600 text-white font-bold px-2 py-0.5 rounded-full">
                    Active
                  </span>
                )}
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">
                {t.veteranCategory}
              </h3>
              <p className="text-xs text-slate-600 line-clamp-2">
                {t.veteranCategoryDesc}
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold text-amber-700">
              <span>{lang === 'hi' ? 'पूर्व सैनिक लाभ' : 'Veteran Welfare'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 3: Candidate */}
          <div
            onClick={() => onSelectCategory('candidate')}
            className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              activeCategory === 'candidate'
                ? 'border-emerald-700 bg-emerald-50/40 shadow-md ring-2 ring-emerald-700/10'
                : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">📚</span>
                {activeCategory === 'candidate' && (
                  <span className="text-[10px] bg-emerald-700 text-white font-bold px-2 py-0.5 rounded-full">
                    Active
                  </span>
                )}
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">
                {t.candidateCategory}
              </h3>
              <p className="text-xs text-slate-600 line-clamp-2">
                {t.candidateCategoryDesc}
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold text-emerald-800">
              <span>{lang === 'hi' ? 'भर्ती परीक्षाएं' : 'Recruitment Exams'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 4: Shaheed Family */}
          <div
            onClick={() => onSelectCategory('shaheed_family')}
            className={`p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
              activeCategory === 'shaheed_family'
                ? 'border-purple-700 bg-purple-50/40 shadow-md ring-2 ring-purple-700/10'
                : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-sm'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">🕊️</span>
                {activeCategory === 'shaheed_family' && (
                  <span className="text-[10px] bg-purple-700 text-white font-bold px-2 py-0.5 rounded-full">
                    Active
                  </span>
                )}
              </div>
              <h3 className="font-bold text-slate-900 text-sm mb-1">
                {t.shaheedCategory}
              </h3>
              <p className="text-xs text-slate-600 line-clamp-2">
                {t.shaheedCategoryDesc}
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold text-purple-800">
              <span>{lang === 'hi' ? 'सम्मानजनक सहायता' : 'Family Support'}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </section>

      {/* QUICK FILTER PILLS / TABS */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-900">
              {activeCategory === 'candidate' ? t.recommendedExams : t.recommendedSchemes}
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              ({displayedSchemes.length} {activeCategory === 'candidate' ? 'Exams' : 'Schemes'})
            </span>
          </div>

          {/* Subcategory buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            {subCategories.map((sub) => (
              <button
                key={sub.id}
                onClick={() => setSelectedSubCategory(sub.id)}
                className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  selectedSubCategory === sub.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>
        </div>

        {/* CANDIDATE EXCLUSIVE RECRUITMENT BANNER */}
        {activeCategory === 'candidate' && (
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-3">
            <GraduationCap className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">
                {lang === 'hi'
                  ? 'इच्छुक अभ्यर्थियों हेतु केवल सेना भर्ती मार्ग'
                  : 'Official Army Recruitment & Examination Routes Only'}
              </p>
              <p className="text-emerald-900 mt-0.5">
                {t.checkLatestNotification}
              </p>
            </div>
          </div>
        )}

        {/* SCHEME CARDS GRID */}
        {displayedSchemes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayedSchemes.map((scheme) => (
              <SchemeCard
                key={scheme.id}
                scheme={scheme}
                user={user}
                onOpenDetails={onOpenDetails}
                onToggleSave={onToggleSave}
                isSaved={user ? (scheme.isExam ? user.savedExamIds.includes(scheme.id) : user.savedSchemeIds.includes(scheme.id)) : false}
                lang={lang}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8">
            <p className="text-slate-600 text-sm mb-3">{t.noSchemesFound}</p>
            <button
              onClick={() => setSelectedSubCategory('all')}
              className="py-2 px-4 rounded-xl bg-slate-900 text-white text-xs font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </section>

      {/* QUICK ACCESS ACTIONS BAR */}
      <section className="bg-slate-100 rounded-3xl p-6 sm:p-8 space-y-4">
        <h3 className="text-base font-bold text-slate-900">
          {t.quickAccess}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-semibold">
          <button
            onClick={() => onSelectCategory('candidate')}
            className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-800 flex items-center justify-between text-left cursor-pointer transition-all hover:shadow-xs"
          >
            <span>Army Entry Exams</span>
            <span className="text-slate-400">→</span>
          </button>
          <button
            onClick={() => onSelectCategory('veteran')}
            className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-800 flex items-center justify-between text-left cursor-pointer transition-all hover:shadow-xs"
          >
            <span>ECHS & Healthcare</span>
            <span className="text-slate-400">→</span>
          </button>
          <button
            onClick={() => onSelectCategory('shaheed_family')}
            className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-800 flex items-center justify-between text-left cursor-pointer transition-all hover:shadow-xs"
          >
            <span>Shaheed Family Support</span>
            <span className="text-slate-400">→</span>
          </button>
          <button
            onClick={() => onSelectCategory('serving')}
            className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-800 flex items-center justify-between text-left cursor-pointer transition-all hover:shadow-xs"
          >
            <span>Children Education (CEA)</span>
            <span className="text-slate-400">→</span>
          </button>
        </div>
      </section>
    </div>
  );
};
