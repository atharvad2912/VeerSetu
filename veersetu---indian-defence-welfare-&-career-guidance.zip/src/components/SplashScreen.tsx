import React, { useEffect } from 'react';
import { VeerEmblem } from './VeerEmblem';
import { ArrowRight } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
  lang: 'en' | 'hi' | 'mr';
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete, lang }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2800);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-slate-900 text-white p-6 select-none overflow-hidden">
      {/* Subtle background ambient light */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top subtle badge */}
      <div className="pt-8 text-center z-10">
        <span className="text-xs uppercase tracking-widest text-slate-400 font-semibold px-3 py-1 rounded-full border border-slate-800 bg-slate-800/40">
          Indian Defence Welfare & Career Platform
        </span>
      </div>

      {/* Center Official Logo Display */}
      <div className="flex flex-col items-center text-center max-w-md z-10 w-full px-4">
        <div className="relative w-72 sm:w-80 max-w-full rounded-2xl overflow-hidden shadow-2xl border border-slate-700/50 bg-[#081325]">
          <VeerEmblem variant="full" />
        </div>

        <p className="text-xs text-amber-400 font-semibold uppercase tracking-wider mt-4">
          {lang === 'hi' ? 'एक सेतु। हर वीर के लिए।' : 'One Bridge. Every Veer.'}
        </p>
      </div>

      {/* Bottom Skip / Enter action */}
      <div className="pb-8 w-full max-w-xs flex flex-col items-center gap-3 z-10">
        <button
          onClick={onComplete}
          className="w-full flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-sm shadow-lg shadow-amber-600/30 transition-all cursor-pointer active:scale-95"
        >
          <span>{lang === 'hi' ? 'वीरसेतु में प्रवेश करें' : 'Enter VeerSetu'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <span className="text-[11px] text-slate-400">
          {lang === 'hi'
            ? 'सूचनात्मक मार्गदर्शन मंच · सत्यापित सरकारी स्रोत'
            : 'Informational Guidance Platform · Verified Official Portals'}
        </span>
      </div>
    </div>
  );
};
