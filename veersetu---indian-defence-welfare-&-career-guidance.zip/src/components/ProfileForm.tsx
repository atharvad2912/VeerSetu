import React, { useState } from 'react';
import { UserProfile, ServingDetails, VeteranDetails, CandidateDetails, ShaheedFamilyDetails } from '../types';
import { INDIAN_STATES } from '../data/translations';
import { Shield, Award, GraduationCap, Heart, CheckCircle, Save, Info, AlertCircle } from 'lucide-react';

interface ProfileFormProps {
  user: UserProfile;
  onSave: (updatedUser: UserProfile) => void;
  lang: 'en' | 'hi' | 'mr';
}

export const ProfileForm: React.FC<ProfileFormProps> = ({ user, onSave, lang }) => {
  const [activeTab, setActiveTab] = useState<'category_details' | 'general_info'>('category_details');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // General fields
  const [fullName, setFullName] = useState(user.fullName);
  const [dob, setDob] = useState(user.dob);
  const [gender, setGender] = useState(user.gender);
  const [state, setState] = useState(user.state);
  const [district, setDistrict] = useState(user.district);
  const [email, setEmail] = useState(user.email || '');

  // Serving details
  const [servingRank, setServingRank] = useState(user.servingDetails?.rank || 'Havildar');
  const [servingCategory, setServingCategory] = useState<'Officer' | 'JCO' | 'Other Ranks / Agniveer'>(
    user.servingDetails?.serviceCategory || 'Other Ranks / Agniveer'
  );
  const [servingJoinDate, setServingJoinDate] = useState(user.servingDetails?.dateOfJoining || '2016-01-01');
  const [servingMarital, setServingMarital] = useState<'Single' | 'Married' | 'Widowed'>(
    user.servingDetails?.maritalStatus || 'Married'
  );
  const [servingSpouse, setServingSpouse] = useState(user.servingDetails?.spouseName || '');
  const [servingChildrenCount, setServingChildrenCount] = useState(user.servingDetails?.childrenCount || 1);
  const [servingChildrenAges, setServingChildrenAges] = useState<string>(
    user.servingDetails?.childrenAges?.join(', ') || '8'
  );
  const [servingEducation, setServingEducation] = useState(user.servingDetails?.educationLevel || '12th Pass');
  const [servingHasDisability, setServingHasDisability] = useState(user.servingDetails?.hasDisability || false);
  const [servingIsBattleCasualty, setServingIsBattleCasualty] = useState(user.servingDetails?.isBattleCasualty || false);

  // Veteran details
  const [vetRank, setVetRank] = useState(user.veteranDetails?.rankAtRetirement || 'Subedar Major');
  const [vetServiceCat, setVetServiceCat] = useState<'Officer' | 'JCO' | 'Other Ranks'>(
    user.veteranDetails?.serviceCategory || 'JCO'
  );
  const [vetRetireDate, setVetRetireDate] = useState(user.veteranDetails?.dateOfRetirement || '2022-04-30');
  const [vetIsPensioner, setVetIsPensioner] = useState(user.veteranDetails?.isPensioner ?? true);
  const [vetPensionType, setVetPensionType] = useState<'Service' | 'Disability' | 'Family' | 'None'>(
    user.veteranDetails?.pensionType || 'Service'
  );
  const [vetHasDisability, setVetHasDisability] = useState(user.veteranDetails?.hasDisability || false);
  const [vetDisabilityPercent, setVetDisabilityPercent] = useState(user.veteranDetails?.disabilityPercentage || 20);
  const [vetDependents, setVetDependents] = useState(user.veteranDetails?.dependentsCount || 2);

  // Candidate details
  const [candEduLevel, setCandEduLevel] = useState(user.candidateDetails?.educationLevel || '12th Pass');
  const [cand10th, setCand10th] = useState(user.candidateDetails?.class10Percentage || 80);
  const [cand12th, setCand12th] = useState(user.candidateDetails?.class12Percentage || 75);
  const [candStream, setCandStream] = useState<'PCM' | 'PCB' | 'Commerce' | 'Arts'>(
    user.candidateDetails?.class12Stream || 'PCM'
  );
  const [candIsGraduate, setCandIsGraduate] = useState(user.candidateDetails?.isGraduate || false);
  const [candDegree, setCandDegree] = useState<'B.Tech/B.E.' | 'Law (LLB)' | 'MBBS' | 'B.Sc' | 'B.A.' | 'B.Com' | 'Other'>(
    user.candidateDetails?.graduationDegree || 'B.Tech/B.E.'
  );
  const [candEngBranch, setCandEngBranch] = useState(user.candidateDetails?.engineeringBranch || 'Computer Science');
  const [candNcc, setCandNcc] = useState<'None' | 'A' | 'B' | 'C'>(user.candidateDetails?.nccCertificate || 'None');
  const [candNccGrading, setCandNccGrading] = useState<'A' | 'B' | 'C'>(user.candidateDetails?.nccGrading || 'B');
  const [candJee, setCandJee] = useState<boolean>(user.candidateDetails?.jeeMainAppeared ?? true);
  const [candMedFit, setCandMedFit] = useState<'Fit' | 'Under Review' | 'Temporary Unfit'>(
    user.candidateDetails?.medicalFitnessStatus || 'Fit'
  );

  // Shaheed Family details
  const [shaheedRelation, setShaheedRelation] = useState(
    user.shaheedFamilyDetails?.relationshipToShaheed || 'Widow (Veer Nari)'
  );
  const [shaheedYear, setShaheedYear] = useState(user.shaheedFamilyDetails?.yearOfCasualty || 2020);
  const [shaheedRank, setShaheedRank] = useState(user.shaheedFamilyDetails?.deceasedRank || 'Havildar');
  const [shaheedServiceCat, setShaheedServiceCat] = useState<'Officer' | 'JCO' | 'Other Ranks'>(
    user.shaheedFamilyDetails?.deceasedServiceCategory || 'Other Ranks'
  );
  const [shaheedCasualtyCat, setShaheedCasualtyCat] = useState<
    'Battle Casualty (Operations)' | 'Physical Casualty' | 'Attributable Military Service'
  >(user.shaheedFamilyDetails?.casualtyCategory || 'Battle Casualty (Operations)');
  const [shaheedRemarried, setShaheedRemarried] = useState(user.shaheedFamilyDetails?.isWidowRemarried || false);
  const [shaheedChildrenCount, setShaheedChildrenCount] = useState(user.shaheedFamilyDetails?.childrenCount || 2);
  const [shaheedChildrenAges, setShaheedChildrenAges] = useState(
    user.shaheedFamilyDetails?.childrenAges?.join(', ') || '12, 9'
  );
  const [shaheedDisabledDep, setShaheedDisabledDep] = useState(
    user.shaheedFamilyDetails?.hasDisabledDependents || false
  );
  const [shaheedPensionStatus, setShaheedPensionStatus] = useState<
    'Liberalised Family Pension' | 'Ordinary Family Pension' | 'Special Family Pension' | 'None'
  >(user.shaheedFamilyDetails?.existingPensionStatus || 'Liberalised Family Pension');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const parseAges = (str: string) =>
      str
        .split(',')
        .map((s) => parseInt(s.trim()))
        .filter((n) => !isNaN(n));

    const updated: UserProfile = {
      ...user,
      fullName,
      dob,
      gender,
      state,
      district,
      email: email || undefined,
      servingDetails:
        user.category === 'serving'
          ? {
              rank: servingRank,
              serviceCategory: servingCategory,
              dateOfJoining: servingJoinDate,
              dateOfBirth: dob,
              postingState: state,
              maritalStatus: servingMarital,
              spouseName: servingSpouse || undefined,
              childrenCount: servingChildrenCount,
              childrenAges: parseAges(servingChildrenAges),
              educationLevel: servingEducation,
              hasDisability: servingHasDisability,
              isBattleCasualty: servingIsBattleCasualty
            }
          : user.servingDetails,
      veteranDetails:
        user.category === 'veteran'
          ? {
              rankAtRetirement: vetRank,
              serviceCategory: vetServiceCat,
              dateOfRetirement: vetRetireDate,
              dateOfBirth: dob,
              isPensioner: vetIsPensioner,
              pensionType: vetPensionType,
              hasDisability: vetHasDisability,
              disabilityPercentage: vetHasDisability ? vetDisabilityPercent : undefined,
              maritalStatus: 'Married',
              childrenCount: 2,
              dependentsCount: vetDependents,
              state,
              district
            }
          : user.veteranDetails,
      candidateDetails:
        user.category === 'candidate'
          ? {
              dateOfBirth: dob,
              gender,
              educationLevel: candEduLevel,
              class10Percentage: cand10th,
              class12Percentage: cand12th,
              class12Stream: candStream,
              isGraduate: candIsGraduate,
              graduationDegree: candIsGraduate ? candDegree : undefined,
              engineeringBranch: candIsGraduate && candDegree === 'B.Tech/B.E.' ? candEngBranch : undefined,
              nccCertificate: candNcc,
              nccGrading: candNcc !== 'None' ? candNccGrading : undefined,
              jeeMainAppeared: candJee,
              medicalFitnessStatus: candMedFit
            }
          : user.candidateDetails,
      shaheedFamilyDetails:
        user.category === 'shaheed_family'
          ? {
              relationshipToShaheed: shaheedRelation as any,
              state,
              district,
              yearOfCasualty: shaheedYear,
              deceasedRank: shaheedRank,
              deceasedServiceCategory: shaheedServiceCat,
              casualtyCategory: shaheedCasualtyCat,
              isWidowRemarried: shaheedRemarried,
              childrenCount: shaheedChildrenCount,
              childrenAges: parseAges(shaheedChildrenAges),
              hasDisabledDependents: shaheedDisabledDep,
              existingPensionStatus: shaheedPensionStatus
            }
          : user.shaheedFamilyDetails
    };

    onSave(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto py-4 px-2 sm:px-4">
      {/* Privacy Notice Banner */}
      <div className="mb-6 p-4 rounded-2xl bg-blue-50 border border-blue-200 flex items-start gap-3">
        <Shield className="w-5 h-5 text-blue-900 shrink-0 mt-0.5" />
        <div className="text-xs text-blue-950 leading-relaxed">
          <p className="font-bold">
            {lang === 'hi' ? 'गोपनीयता एवं सुरक्षा प्रतिज्ञा' : 'Defence Privacy & Zero-Classified-Data Guarantee'}
          </p>
          <p className="text-blue-900 mt-0.5">
            {lang === 'hi'
              ? 'वीरसेतु केवल पात्रता मिलान हेतु सामान्य गैर-गोपनीय जानकारी मांगता है। हम कभी भी आपके पोस्टिंग यूनिट, हथियार, ऑपरेशनल तैनाती अथवा गोपनीय सैन्य विवरण नहीं मांगते।'
              : 'VeerSetu only collects non-sensitive criteria needed for scheme eligibility. We never request operational unit numbers, deployment locations, weapon profiles, or classified military information.'}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Profile Card Header */}
        <div className="p-6 bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold text-xl">
              {user.category === 'serving' ? '🇮🇳' : user.category === 'veteran' ? '🎖️' : user.category === 'candidate' ? '📚' : '🕊️'}
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">
                {fullName}
              </h2>
              <p className="text-xs text-slate-300">
                {user.category === 'serving'
                  ? (lang === 'hi' ? 'सेवारत सैन्य कर्मी प्रोफ़ाइल' : 'Serving Personnel Profile')
                  : user.category === 'veteran'
                  ? (lang === 'hi' ? 'पूर्व सैनिक कल्याण प्रोफ़ाइल' : 'Ex-Servicemen Profile')
                  : user.category === 'candidate'
                  ? (lang === 'hi' ? 'सेना भर्ती अभ्यर्थी प्रोफ़ाइल' : 'Aspiring Army Candidate Profile')
                  : (lang === 'hi' ? 'शहीद परिवार सहायता प्रोफ़ाइल' : 'Shaheed Family Profile')}
                {' · '}
                <span className="text-amber-400 font-semibold">{district}, {state}</span>
              </p>
            </div>
          </div>

          {/* Tab buttons */}
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl self-start sm:self-auto">
            <button
              onClick={() => setActiveTab('category_details')}
              className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'category_details'
                  ? 'bg-blue-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'hi' ? 'पात्रता विवरण' : 'Eligibility Criteria'}
            </button>
            <button
              onClick={() => setActiveTab('general_info')}
              className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'general_info'
                  ? 'bg-blue-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang === 'hi' ? 'व्यक्तिगत जानकारी' : 'Personal Details'}
            </button>
          </div>
        </div>

        {savedSuccess && (
          <div className="m-6 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center gap-2 text-xs font-semibold">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              {lang === 'hi'
                ? 'आपकी प्रोफ़ाइल सफलतापूर्वक अपडेट हो गई है! नई पात्रता गणना तुरंत लागू हो गई है।'
                : 'Your profile has been updated! Fresh eligibility matches are now reflected on your dashboard.'}
            </span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
          {/* GENERAL INFO TAB */}
          {activeTab === 'general_info' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900 border-b pb-2">
                {lang === 'hi' ? 'बुनियादी संपर्क व पहचान विवरण' : 'Basic Contact & Identity'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'पूरा नाम' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'मोबाइल नंबर (लॉगिन)' : 'Mobile Number (Primary ID)'}
                  </label>
                  <input
                    type="tel"
                    disabled
                    value={user.mobile}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-100 text-slate-500 text-sm cursor-not-allowed"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'जन्म तिथि' : 'Date of Birth'}
                  </label>
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'लिंग' : 'Gender'}
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'ईमेल (वैकल्पिक)' : 'Email (Optional)'}
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'गृह राज्य / यूटी' : 'Home State / UT'}
                  </label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                  >
                    {INDIAN_STATES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'hi' ? 'गृह जिला' : 'Home District'}
                  </label>
                  <input
                    type="text"
                    required
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                  />
                </div>
              </div>
            </div>
          )}

          {/* CATEGORY SPECIFIC ELIGIBILITY FIELDS */}
          {activeTab === 'category_details' && (
            <div className="space-y-6">
              {/* SECTION A: SERVING */}
              {user.category === 'serving' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <Shield className="w-5 h-5 text-blue-900" />
                    <h3 className="text-sm font-bold text-slate-900">
                      {lang === 'hi' ? 'सेवारत सैन्य सेवा विवरण (Serving Information)' : 'Serving Personnel Service Information'}
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'सैन्य पद / रैंक' : 'Rank'}
                      </label>
                      <input
                        type="text"
                        value={servingRank}
                        onChange={(e) => setServingRank(e.target.value)}
                        placeholder="e.g. Havildar, Subedar, Major"
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'सेवा संवर्ग' : 'Service Category'}
                      </label>
                      <select
                        value={servingCategory}
                        onChange={(e) => setServingCategory(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="Officer">Officer</option>
                        <option value="JCO">JCO (Junior Commissioned Officer)</option>
                        <option value="Other Ranks / Agniveer">Other Ranks / Agniveer</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'सेना में भर्ती की तिथि' : 'Date of Joining Service'}
                      </label>
                      <input
                        type="date"
                        value={servingJoinDate}
                        onChange={(e) => setServingJoinDate(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'वैवाहिक स्थिति' : 'Marital Status'}
                      </label>
                      <select
                        value={servingMarital}
                        onChange={(e) => setServingMarital(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="Married">Married</option>
                        <option value="Single">Single</option>
                        <option value="Widowed">Widowed</option>
                      </select>
                    </div>

                    {servingMarital === 'Married' && (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {lang === 'hi' ? 'पति/पत्नी का नाम' : 'Spouse Name'}
                        </label>
                        <input
                          type="text"
                          value={servingSpouse}
                          onChange={(e) => setServingSpouse(e.target.value)}
                          placeholder="Spouse Name"
                          className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'बच्चों की संख्या' : 'Number of Children'}
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={6}
                        value={servingChildrenCount}
                        onChange={(e) => setServingChildrenCount(parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>

                  {servingChildrenCount > 0 && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'बच्चों की आयु (अल्पविराम से अलग करें)' : "Children's Ages (comma separated)"}
                      </label>
                      <input
                        type="text"
                        value={servingChildrenAges}
                        onChange={(e) => setServingChildrenAges(e.target.value)}
                        placeholder="e.g. 7, 5"
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                      <p className="text-[11px] text-slate-500 mt-1">
                        {lang === 'hi'
                          ? 'सीईए एवं पीएमएसएस छात्रवृत्ति पात्रता जांच के लिए आवश्यक'
                          : 'Needed to calculate CEA and higher education grant entitlements'}
                      </p>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={servingHasDisability}
                        onChange={(e) => setServingHasDisability(e.target.checked)}
                        className="w-4 h-4 text-blue-900 rounded focus:ring-blue-900"
                      />
                      <div className="text-xs">
                        <span className="font-bold text-slate-800 block">
                          {lang === 'hi' ? 'सैन्य सेवा दिव्यांगता' : 'Service Disability'}
                        </span>
                        <span className="text-slate-500">
                          {lang === 'hi' ? 'सैन्य सेवा के दौरान शारीरिक दिव्यांगता' : 'Physical disability attributable to military service'}
                        </span>
                      </div>
                    </label>

                    <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={servingIsBattleCasualty}
                        onChange={(e) => setServingIsBattleCasualty(e.target.checked)}
                        className="w-4 h-4 text-blue-900 rounded focus:ring-blue-900"
                      />
                      <div className="text-xs">
                        <span className="font-bold text-slate-800 block">
                          {lang === 'hi' ? 'बैटल कैजुअल्टी स्थिति' : 'Battle Casualty Status'}
                        </span>
                        <span className="text-slate-500">
                          {lang === 'hi' ? 'ऑपरेशनल ड्यूटी के दौरान हताहत' : 'Declared as operational/battle casualty'}
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* SECTION B: VETERAN */}
              {user.category === 'veteran' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <Award className="w-5 h-5 text-amber-700" />
                    <h3 className="text-sm font-bold text-slate-900">
                      {lang === 'hi' ? 'भूतपूर्व सैनिक सेवानिवृत्ति विवरण' : 'Ex-Servicemen Retirement Information'}
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'सेवानिवृत्ति पर रैंक' : 'Rank at Retirement'}
                      </label>
                      <input
                        type="text"
                        value={vetRank}
                        onChange={(e) => setVetRank(e.target.value)}
                        placeholder="e.g. Subedar Major, Havildar"
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'सेवा संवर्ग' : 'Service Category'}
                      </label>
                      <select
                        value={vetServiceCat}
                        onChange={(e) => setVetServiceCat(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="Officer">Officer</option>
                        <option value="JCO">JCO</option>
                        <option value="Other Ranks">Other Ranks (OR)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'सेवानिवृत्ति की तिथि' : 'Date of Retirement'}
                      </label>
                      <input
                        type="date"
                        value={vetRetireDate}
                        onChange={(e) => setVetRetireDate(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'पेंशनभोगी स्थिति' : 'Pensioner Status'}
                      </label>
                      <select
                        value={vetIsPensioner ? 'yes' : 'no'}
                        onChange={(e) => setVetIsPensioner(e.target.value === 'yes')}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="yes">Pensioner (Receiving Pension)</option>
                        <option value="no">Non-Pensioner (Indigent / Penury eligible)</option>
                      </select>
                    </div>

                    {vetIsPensioner && (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {lang === 'hi' ? 'पेंशन का प्रकार' : 'Pension Type'}
                        </label>
                        <select
                          value={vetPensionType}
                          onChange={(e) => setVetPensionType(e.target.value as any)}
                          className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                        >
                          <option value="Service">Service Pension</option>
                          <option value="Disability">Disability Pension</option>
                          <option value="Family">Family Pension</option>
                        </select>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'कुल आश्रित परिजन' : 'Total Dependents (for ECHS)'}
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={8}
                        value={vetDependents}
                        onChange={(e) => setVetDependents(parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={vetHasDisability}
                        onChange={(e) => setVetHasDisability(e.target.checked)}
                        className="w-4 h-4 text-amber-700 rounded focus:ring-amber-700"
                      />
                      <div className="text-xs">
                        <span className="font-bold text-slate-800 block">
                          {lang === 'hi' ? 'दिव्यांगता पेंशनभोगी' : 'Disability Pensioner / Medical Invalidation'}
                        </span>
                        <span className="text-slate-500">
                          {lang === 'hi' ? 'सेना सेवा के दौरान हुई शारीरिक क्षति' : 'Hold disability percentage approved by Medical Board'}
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* SECTION C: ASPIRING CANDIDATE */}
              {user.category === 'candidate' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <GraduationCap className="w-5 h-5 text-emerald-700" />
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">
                        {lang === 'hi' ? 'अभ्यर्थी शैक्षणिक एवं शारीरिक विवरण' : 'Candidate Academic & Defence Eligibility'}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        {lang === 'hi'
                          ? 'केवल सेना भर्ती और परीक्षाओं के सटीक मिलान हेतु उपयोग किया जाएगा।'
                          : 'Used exclusively for matching Army recruitment routes and exams.'}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'वर्तमान शिक्षा स्तर' : 'Education Level'}
                      </label>
                      <select
                        value={candEduLevel}
                        onChange={(e) => {
                          const val = e.target.value as any;
                          setCandEduLevel(val);
                          setCandIsGraduate(val === 'Graduate Pass' || val === 'Post Graduate');
                        }}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="10th">10th Pass (Matric)</option>
                        <option value="12th Appearing">12th Appearing</option>
                        <option value="12th Pass">12th Pass (10+2)</option>
                        <option value="Graduate Appearing">Graduate (Final Year)</option>
                        <option value="Graduate Pass">Graduate Pass</option>
                        <option value="Post Graduate">Post Graduate</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? '12वीं कक्षा संकाय (Stream)' : '10+2 Stream'}
                      </label>
                      <select
                        value={candStream}
                        onChange={(e) => setCandStream(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="PCM">Physics, Chemistry, Maths (PCM)</option>
                        <option value="PCB">Physics, Chemistry, Biology (PCB)</option>
                        <option value="Commerce">Commerce</option>
                        <option value="Arts">Arts / Humanities</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? '12वीं में कुल प्रतिशत (%)' : '10+2 Aggregate %'}
                      </label>
                      <input
                        type="number"
                        min={30}
                        max={100}
                        value={cand12th}
                        onChange={(e) => setCand12th(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? '10वीं (मैट्रिक) प्रतिशत (%)' : 'Class 10th Aggregate %'}
                      </label>
                      <input
                        type="number"
                        min={30}
                        max={100}
                        value={cand10th}
                        onChange={(e) => setCand10th(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'स्नातक स्थिति' : 'Graduation Status'}
                      </label>
                      <select
                        value={candIsGraduate ? 'yes' : 'no'}
                        onChange={(e) => setCandIsGraduate(e.target.value === 'yes')}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="no">Undergraduate / Pursuing</option>
                        <option value="yes">Graduated (Completed Degree)</option>
                      </select>
                    </div>

                    {candIsGraduate && (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {lang === 'hi' ? 'डिग्री का प्रकार' : 'Degree Discipline'}
                        </label>
                        <select
                          value={candDegree}
                          onChange={(e) => setCandDegree(e.target.value as any)}
                          className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                        >
                          <option value="B.Tech/B.E.">B.Tech / B.E. (Engineering)</option>
                          <option value="Law (LLB)">Law (LLB 3yr/5yr)</option>
                          <option value="MBBS">MBBS (Medical)</option>
                          <option value="B.Sc">B.Sc</option>
                          <option value="B.A.">B.A.</option>
                          <option value="B.Com">B.Com</option>
                          <option value="Other">Other Degree</option>
                        </select>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'एनसीसी प्रमाणपत्र' : 'NCC Certificate'}
                      </label>
                      <select
                        value={candNcc}
                        onChange={(e) => setCandNcc(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="None">None</option>
                        <option value="A">NCC 'A' Certificate</option>
                        <option value="B">NCC 'B' Certificate</option>
                        <option value="C">NCC 'C' Certificate (Senior Wing)</option>
                      </select>
                    </div>

                    {candNcc === 'C' && (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          {lang === 'hi' ? 'एनसीसी C ग्रेडिंग' : "NCC 'C' Grade"}
                        </label>
                        <select
                          value={candNccGrading}
                          onChange={(e) => setCandNccGrading(e.target.value as any)}
                          className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                        >
                          <option value="A">Grade 'A'</option>
                          <option value="B">Grade 'B' (Eligible for Special Entry)</option>
                          <option value="C">Grade 'C'</option>
                        </select>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'जेईई मेन्स में उपस्थिति' : 'JEE (Main) Status'}
                      </label>
                      <select
                        value={candJee ? 'yes' : 'no'}
                        onChange={(e) => setCandJee(e.target.value === 'yes')}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="yes">Appeared (Mandatory for 10+2 TES)</option>
                        <option value="no">Not Appeared</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION D: SHAHEED FAMILY */}
              {user.category === 'shaheed_family' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <Heart className="w-5 h-5 text-purple-700" />
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">
                        {lang === 'hi' ? 'शहीद सैनिक परिवार विवरण' : 'Shaheed Family Welfare Details'}
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        {lang === 'hi'
                          ? 'सभी कल्याणकारी योजनाओं, उदारीकृत पेंशन और अनुग्रह अनुदान की गणना के लिए।'
                          : 'Used for computing ex-gratia grants, liberalised family pensions and priority support.'}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'शहीद से संबंध' : 'Relationship to Martyr'}
                      </label>
                      <select
                        value={shaheedRelation}
                        onChange={(e) => setShaheedRelation(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white font-semibold text-slate-800"
                      >
                        <option value="Widow (Veer Nari)">Widow (Veer Nari)</option>
                        <option value="Son">Son</option>
                        <option value="Daughter">Daughter</option>
                        <option value="Mother">Mother</option>
                        <option value="Father">Father</option>
                        <option value="Other Dependent">Other Dependent</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'शहादत / कैजुअल्टी का वर्ष' : 'Year of Supreme Sacrifice'}
                      </label>
                      <input
                        type="number"
                        min={1947}
                        max={2026}
                        value={shaheedYear}
                        onChange={(e) => setShaheedYear(parseInt(e.target.value) || 2020)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'शहीद का पद / रैंक' : 'Rank of Deceased Personnel'}
                      </label>
                      <input
                        type="text"
                        value={shaheedRank}
                        onChange={(e) => setShaheedRank(e.target.value)}
                        placeholder="e.g. Havildar, Major, Naik"
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'कैजुअल्टी श्रेणी (वर्गीकरण)' : 'Casualty Classification'}
                      </label>
                      <select
                        value={shaheedCasualtyCat}
                        onChange={(e) => setShaheedCasualtyCat(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="Battle Casualty (Operations)">Battle Casualty (War/Ops/Militancy)</option>
                        <option value="Attributable Military Service">Attributable to Military Service</option>
                        <option value="Physical Casualty">Physical Casualty</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'पारिवारिक पेंशन स्थिति' : 'Family Pension Status'}
                      </label>
                      <select
                        value={shaheedPensionStatus}
                        onChange={(e) => setShaheedPensionStatus(e.target.value as any)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm bg-white"
                      >
                        <option value="Liberalised Family Pension">Liberalised Family Pension (100% pay)</option>
                        <option value="Special Family Pension">Special Family Pension (60% pay)</option>
                        <option value="Ordinary Family Pension">Ordinary Family Pension (30% pay)</option>
                        <option value="None">None / Pending Application</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {lang === 'hi' ? 'बच्चों की संख्या' : 'Number of Children'}
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={8}
                        value={shaheedChildrenCount}
                        onChange={(e) => setShaheedChildrenCount(parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Button */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="submit"
              className="py-3 px-6 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-sm transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{lang === 'hi' ? 'प्रोफ़ाइल सहेजें' : 'Save & Recalculate Eligibility'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
