import React, { useState } from 'react';
import { SchemeOrExam, UserProfile } from '../types';
import { SchemeCard } from './SchemeCard';
import { translations } from '../data/translations';
import { Bookmark, BookmarkCheck, ExternalLink, ShieldCheck, ArrowRight } from 'lucide-react';

interface SavedViewProps {
  user: UserProfile | null;
  schemes: SchemeOrExam[];
  onOpenDetails: (scheme: SchemeOrExam) => void;
  onToggleSave: (id: string, isExam: boolean) => void;
  onOpenAuth: () => void;
  lang: 'en' | 'hi' | 'mr';
}

export const SavedView: React.FC<SavedViewProps> = ({
  user,
  schemes,
  onOpenDetails,
  onToggleSave,
  onOpenAuth,
  lang
}) => {
  const t = translations[lang] || translations.en;
  const [activeTab, setActiveTab] = useState<'benefits' | 'exams'>('benefits');

  if (!user) {
    return (
      <div className="max-w-xl mx-auto py-16 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center mx-auto border border-amber-200">
          <Bookmark className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">
          {lang === 'hi' ? 'सहेजे गए आइटम देखने के लिए साइन इन करें' : 'Sign in to View Your Saved Items'}
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm max-w-md mx-auto">
          {lang === 'hi'
            ? 'अपनी सहेजी गई योजनाओं और भर्ती परीक्षाओं को सुरक्षित रखने के लिए कृपया लॉगिन करें।'
            : 'Bookmarks are synced to your profile so you can revisit schemes, deadlines, and required documents anytime.'}
        </p>
        <button
          onClick={onOpenAuth}
          className="py-3 px-6 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold text-xs transition-colors cursor-pointer"
        >
          {t.login} / {t.register}
        </button>
      </div>
    );
  }

  const savedSchemes = schemes.filter(
    (s) => !s.isExam && user.savedSchemeIds.includes(s.id)
  );

  const savedExams = schemes.filter(
    (s) => s.isExam && user.savedExamIds.includes(s.id)
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {lang === 'hi' ? 'मेरे सहेजे गए आइटम' : 'My Saved Bookmarks'}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            {lang === 'hi'
              ? 'आपकी व्यक्तिगत बुकमार्क सूची: योजनाएं और सेना भर्ती परीक्षाएं।'
              : 'Your curated list of saved welfare schemes, scholarships, and Army examinations.'}
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('benefits')}
            className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'benefits'
                ? 'bg-white text-blue-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>{t.savedBenefitsTitle}</span>
            <span className="ml-1.5 text-[10px] bg-blue-100 text-blue-900 px-1.5 py-0.2 rounded-full font-bold">
              {savedSchemes.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('exams')}
            className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'exams'
                ? 'bg-white text-blue-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>{t.savedExamsTitle}</span>
            <span className="ml-1.5 text-[10px] bg-emerald-100 text-emerald-900 px-1.5 py-0.2 rounded-full font-bold">
              {savedExams.length}
            </span>
          </button>
        </div>
      </div>

      {activeTab === 'benefits' && (
        <div>
          {savedSchemes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedSchemes.map((scheme) => (
                <SchemeCard
                  key={scheme.id}
                  scheme={scheme}
                  user={user}
                  onOpenDetails={onOpenDetails}
                  onToggleSave={onToggleSave}
                  isSaved={true}
                  lang={lang}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
              <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-slate-600 text-sm max-w-md mx-auto">
                {t.emptySaved}
              </p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'exams' && (
        <div>
          {savedExams.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedExams.map((exam) => (
                <SchemeCard
                  key={exam.id}
                  scheme={exam}
                  user={user}
                  onOpenDetails={onOpenDetails}
                  onToggleSave={onToggleSave}
                  isSaved={true}
                  lang={lang}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
              <Bookmark className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-slate-600 text-sm max-w-md mx-auto">
                {lang === 'hi'
                  ? 'आपने कोई भर्ती परीक्षा सहेजी नहीं है। भर्ती टैब पर जाकर परीक्षा कार्ड पर "सुरक्षित करें" दबाएं।'
                  : "You haven't bookmarked any Army recruitment entries yet. Explore Army exams and click 'Save' to track them here."}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
