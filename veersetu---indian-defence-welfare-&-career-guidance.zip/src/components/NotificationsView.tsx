import React, { useState } from 'react';
import { OfficialNotification, UserCategory } from '../types';
import { translations } from '../data/translations';
import { Bell, Calendar, ExternalLink, ShieldCheck, AlertCircle, CheckCircle2, Filter } from 'lucide-react';

interface NotificationsViewProps {
  notices: OfficialNotification[];
  lang: 'en' | 'hi' | 'mr';
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({ notices, lang }) => {
  const t = translations[lang] || translations.en;
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const filtered = notices.filter((n) => {
    if (filterCategory === 'all') return true;
    return n.category === filterCategory;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          {t.officialNoticesTitle}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          {t.verifiedDatesOnly}
        </p>
      </div>

      {/* Trust Banner regarding official deadlines */}
      <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-xs text-blue-950 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-blue-900 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold">
            {lang === 'hi' ? 'सत्यापित आधिकारिक समय सीमा नीति' : 'Zero-Speculation Deadline Policy'}
          </p>
          <p className="text-blue-900 mt-0.5">
            {lang === 'hi'
              ? 'वीरसेतु कभी भी काल्पनिक या अनुमानित समय सीमाएं उत्पन्न नहीं करता है। सभी तिथियां केवल यूपीएससी, रक्षा मंत्रालय एवं केएसबी की आधिकारिक अधिसूचनाओं से ली गई हैं।'
              : 'VeerSetu strictly forbids fabricated deadlines. Dates are sourced verbatim from published MoD gazettes, UPSC schedules, and KSB circulars.'}
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
        {['all', 'Recruitment', 'Scholarship', 'Pension Alert', 'Welfare Update'].map((c) => (
          <button
            key={c}
            onClick={() => setFilterCategory(c)}
            className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              filterCategory === c ? 'bg-white text-blue-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {c === 'all' ? 'All Notices' : c}
          </button>
        ))}
      </div>

      {/* Notices List */}
      <div className="space-y-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:border-slate-300 transition-all space-y-3"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-bold text-amber-700 uppercase tracking-wider">
                {item.category}
              </span>
              <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Published: {item.date}
              </span>
            </div>

            <h3 className="text-base font-bold text-slate-900 leading-snug">
              {lang === 'hi' ? item.titleHindi : item.title}
            </h3>

            {item.deadline && (
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-xs flex items-center justify-between">
                <span className="text-slate-600 font-medium">
                  {lang === 'hi' ? 'आवेदन की अंतिम तिथि:' : 'Official Application Deadline:'}
                </span>
                <span className="font-bold text-blue-900 font-mono">
                  {item.deadline}
                </span>
              </div>
            )}

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium truncate max-w-xs">
                Source: {item.sourceName}
              </span>
              <a
                href={item.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1 hover:underline"
              >
                <span>{lang === 'hi' ? 'आधिकारिक स्रोत' : 'Official Portal'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
