import React, { useState, useEffect } from 'react';
import { SchemeOrExam, UserProfile, UserCategory, SchemeCategory } from '../types';
import { SchemeCard } from './SchemeCard';
import { INDIAN_STATES, translations } from '../data/translations';
import { Search, Filter, RotateCcw, Building2 } from 'lucide-react';

interface SearchViewProps {
  schemes: SchemeOrExam[];
  user: UserProfile | null;
  initialQuery?: string;
  onOpenDetails: (scheme: SchemeOrExam) => void;
  onToggleSave: (id: string, isExam: boolean) => void;
  lang: 'en' | 'hi' | 'mr';
}

export const SearchView: React.FC<SearchViewProps> = ({
  schemes,
  user,
  initialQuery = '',
  onOpenDetails,
  onToggleSave,
  lang
}) => {
  const t = translations[lang] || translations.en;
  const [query, setQuery] = useState(initialQuery);
  const [beneficiaryFilter, setBeneficiaryFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [stateFilter, setStateFilter] = useState<string>('all');

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
    }
  }, [initialQuery]);

  const categories: SchemeCategory[] = [
    'Financial',
    'Medical',
    'Education',
    'Employment',
    'Housing',
    'Pension',
    'Scholarship',
    'Recruitment',
    'CSD / Concessions',
    'Disability Support',
    'Marriage & Family Support',
    'Insurance'
  ];

  const filteredSchemes = schemes.filter((s) => {
    // 1. Beneficiary Filter
    if (beneficiaryFilter !== 'all') {
      if (s.beneficiaryType !== beneficiaryFilter && s.beneficiaryType !== 'all') {
        return false;
      }
    }

    // 2. Category Filter
    if (categoryFilter !== 'all') {
      if (s.category !== categoryFilter) return false;
    }

    // 3. Text Search Query
    if (query.trim()) {
      const q = query.toLowerCase();
      const matchName = s.name.toLowerCase().includes(q) || s.nameHindi.toLowerCase().includes(q);
      const matchBenefit = s.potentialBenefit.toLowerCase().includes(q) || s.potentialBenefitHindi.toLowerCase().includes(q);
      const matchCategory = s.category.toLowerCase().includes(q);
      const matchAudience = s.targetAudience.toLowerCase().includes(q);
      const matchDepartment = s.officialSource.name.toLowerCase().includes(q) || s.officialSource.department.toLowerCase().includes(q);

      if (!matchName && !matchBenefit && !matchCategory && !matchAudience && !matchDepartment) {
        return false;
      }
    }

    return true;
  });

  const handleResetFilters = () => {
    setQuery('');
    setBeneficiaryFilter('all');
    setCategoryFilter('all');
    setStateFilter('all');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Title */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          {lang === 'hi' ? 'सार्वभौमिक योजना एवं परीक्षा खोज' : 'Universal Defence Scheme & Exam Search'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          {lang === 'hi'
            ? 'सेना कल्याण योजनाओं, छात्रवृत्ति, ईसीएचएस, पेंशन और भर्ती परीक्षाओं की तुरंत खोज करें।'
            : 'Explore, filter and verify government welfare schemes, ECHS, scholarships and Army exams across all states.'}
        </p>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="w-full pl-12 pr-4 py-3.5 rounded-2xl border border-slate-300 bg-white text-slate-900 text-sm font-medium focus:ring-2 focus:ring-blue-900 focus:outline-none shadow-sm"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            Clear
          </button>
        )}
      </div>

      {/* Filter Row */}
      <div className="p-4 sm:p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider">
            <Filter className="w-4 h-4 text-blue-900" />
            <span>Filter Criteria</span>
          </div>

          <button
            onClick={handleResetFilters}
            className="text-xs text-slate-500 hover:text-blue-900 flex items-center gap-1 font-semibold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Beneficiary Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.filterBeneficiary}
            </label>
            <select
              value={beneficiaryFilter}
              onChange={(e) => setBeneficiaryFilter(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white font-medium text-slate-800"
            >
              <option value="all">{t.allBeneficiaries}</option>
              <option value="serving">Currently Serving Army Personnel</option>
              <option value="veteran">Veteran / Ex-Servicemen</option>
              <option value="candidate">Aspiring Army Candidate (Exams Only)</option>
              <option value="shaheed_family">Family of Shaheed Personnel</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.filterCategory}
            </label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white font-medium text-slate-800"
            >
              <option value="all">{t.allCategories}</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* State Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.filterState}
            </label>
            <select
              value={stateFilter}
              onChange={(e) => setStateFilter(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white font-medium text-slate-800"
            >
              <option value="all">{t.allStates}</option>
              {INDIAN_STATES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Results Count & Grid */}
      <div className="flex items-center justify-between text-xs text-slate-500 font-semibold px-1">
        <span>
          Showing {filteredSchemes.length} matching entries
        </span>
        <span>
          Verified against official portals
        </span>
      </div>

      {filteredSchemes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSchemes.map((scheme) => (
            <SchemeCard
              key={scheme.id}
              scheme={scheme}
              user={user}
              onOpenDetails={onOpenDetails}
              onToggleSave={onToggleSave}
              isSaved={user ? (scheme.isExam ? user.savedExamIds.includes(scheme.id) : user.savedSchemeIds.includes(scheme.id)) : false}
              lang={lang}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
          <p className="text-slate-600 text-sm mb-3">{t.noSchemesFound}</p>
          <button
            onClick={handleResetFilters}
            className="py-2.5 px-5 rounded-xl bg-blue-900 text-white text-xs font-semibold cursor-pointer"
          >
            Clear Filters & View All
          </button>
        </div>
      )}
    </div>
  );
};
