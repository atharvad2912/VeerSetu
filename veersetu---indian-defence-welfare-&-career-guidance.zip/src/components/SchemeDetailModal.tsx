import React from 'react';
import { SchemeOrExam, UserProfile } from '../types';
import { evaluateEligibility } from '../services/eligibilityEngine';
import { translations } from '../data/translations';
import { X, ExternalLink, Bookmark, BookmarkCheck, Building2, Calendar, FileText, CheckCircle2, AlertTriangle, XCircle, HelpCircle, Shield, Share2, Printer } from 'lucide-react';

interface SchemeDetailModalProps {
  scheme: SchemeOrExam | null;
  onClose: () => void;
  user: UserProfile | null;
  onToggleSave: (id: string, isExam: boolean) => void;
  isSaved: boolean;
  lang: 'en' | 'hi' | 'mr';
}

export const SchemeDetailModal: React.FC<SchemeDetailModalProps> = ({
  scheme,
  onClose,
  user,
  onToggleSave,
  isSaved,
  lang
}) => {
  if (!scheme) return null;

  const t = translations[lang] || translations.en;
  const evaluation = evaluateEligibility(scheme, user);

  const getStatusBadge = () => {
    switch (evaluation.status) {
      case 'potentially_eligible':
        return {
          icon: CheckCircle2,
          text: lang === 'hi' ? 'संभावित रूप से पात्र' : 'Potentially Eligible',
          container: 'text-emerald-800 bg-emerald-50 border-emerald-300'
        };
      case 'may_become_eligible':
        return {
          icon: AlertTriangle,
          text: lang === 'hi' ? 'पात्र हो सकते हैं' : 'May Become Eligible',
          container: 'text-amber-800 bg-amber-50 border-amber-300'
        };
      case 'not_eligible':
        return {
          icon: XCircle,
          text: lang === 'hi' ? 'वर्तमान में पात्र नहीं' : 'Currently Not Eligible',
          container: 'text-rose-800 bg-rose-50 border-rose-300'
        };
      default:
        return {
          icon: HelpCircle,
          text: lang === 'hi' ? 'अधिक जानकारी आवश्यक' : 'More Information Required',
          container: 'text-slate-800 bg-slate-100 border-slate-300'
        };
    }
  };

  const badge = getStatusBadge();
  const StatusIcon = badge.icon;

  const handlePrint = () => {
    window.print();
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: scheme.name,
        text: `${scheme.name} - VeerSetu Defence Welfare Guidance`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${scheme.name} - Official Portal: ${scheme.officialSource.url}`);
      alert(lang === 'hi' ? 'लिंक क्लिपबोर्ड पर कॉपी किया गया!' : 'Information link copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
        {/* Top Header */}
        <div className="bg-slate-900 text-white p-6 pb-5 flex items-start justify-between gap-4 border-b border-slate-800">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mb-2">
              <span className="text-amber-400 font-bold tracking-wider uppercase">
                {scheme.category}
              </span>
              <span aria-hidden="true">·</span>
              <span>{scheme.isExam ? 'Recruitment Route' : 'Defence Welfare Scheme'}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {lang === 'hi' ? 'अंतिम सत्यापित:' : 'Last Verified:'} {scheme.lastVerifiedDate}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
              {lang === 'hi' ? scheme.nameHindi : scheme.name}
            </h2>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => onToggleSave(scheme.id, scheme.isExam)}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                isSaved
                  ? 'bg-amber-500/20 text-amber-400'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title={isSaved ? 'Saved' : 'Save'}
            >
              {isSaved ? <BookmarkCheck className="w-5 h-5 fill-amber-400" /> : <Bookmark className="w-5 h-5" />}
            </button>
            <button
              onClick={handleShare}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Share"
            >
              <Share2 className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body Content */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto">
          {/* Statutory Disclaimer Alert */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-blue-900 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-slate-800 font-semibold">{t.appName}: </strong>
              {t.officialDisclaimer}
            </p>
          </div>

          {/* Eligibility Status Banner */}
          <div className={`p-4 rounded-2xl border ${badge.container}`}>
            <div className="flex items-center gap-2 mb-1.5">
              <StatusIcon className="w-5 h-5 shrink-0" />
              <span className="font-extrabold text-sm sm:text-base">{badge.text}</span>
            </div>
            <p className="text-xs sm:text-sm leading-relaxed">
              {lang === 'hi' ? evaluation.summaryHindi : evaluation.summary}
            </p>

            {scheme.isExam && (
              <p className="text-[11px] font-semibold text-amber-900 mt-2 pt-2 border-t border-amber-200">
                {t.checkLatestNotification}
              </p>
            )}
          </div>

          {/* Section 1: Target Beneficiary */}
          <div className="space-y-1.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              {lang === 'hi' ? 'लाभार्थी समूह (Who can benefit)' : 'Target Beneficiary Group'}
            </h4>
            <p className="text-sm font-semibold text-slate-900">
              {lang === 'hi' ? scheme.targetAudienceHindi : scheme.targetAudience}
            </p>
          </div>

          {/* Section 2: Potential Benefit */}
          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-1">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
              {lang === 'hi' ? 'संभावित लाभ / वित्तीय सहायता / पद' : 'Potential Benefit / Rank / Entitlement'}
            </h4>
            <p className="text-sm text-amber-950 font-medium leading-relaxed">
              {lang === 'hi' ? scheme.potentialBenefitHindi : scheme.potentialBenefit}
            </p>
          </div>

          {/* Section 3: Detailed Eligibility Checklist */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              {lang === 'hi' ? 'पात्रता मानदंड चेकलिस्ट' : 'Rule-Based Eligibility Checklist'}
            </h4>
            
            <p className="text-xs text-slate-600">
              {lang === 'hi' ? scheme.eligibilityDescriptionHindi : scheme.eligibilityDescription}
            </p>

            {evaluation.checklist.length > 0 ? (
              <div className="rounded-xl border border-slate-200 divide-y divide-slate-100 overflow-hidden bg-slate-50/40">
                {evaluation.checklist.map((item, idx) => (
                  <div key={idx} className="p-3 text-xs flex items-start gap-3">
                    <span className="shrink-0 mt-0.5 text-sm">
                      {item.isMet === true ? (
                        <span className="text-emerald-600 font-bold">✅</span>
                      ) : item.isMet === false ? (
                        <span className="text-rose-600 font-bold">❌</span>
                      ) : (
                        <span className="text-amber-600 font-bold">⏳</span>
                      )}
                    </span>
                    <div className="flex-1">
                      <span className="font-bold text-slate-900 block">
                        {lang === 'hi' ? item.labelHindi : item.label}
                      </span>
                      <span className="text-slate-600">
                        {lang === 'hi' ? item.detailHindi : item.detail}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}
          </div>

          {/* Section 4: Required Documents */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-blue-900" />
              <span>{t.requiredDocuments}</span>
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {(lang === 'hi' ? scheme.requiredDocumentsHindi : scheme.requiredDocuments).map((doc, i) => (
                <li key={i} className="flex items-start gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700">
                  <span className="text-blue-900 font-bold mt-0.5">•</span>
                  <span>{doc}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Section 5: How to Apply (Step by step) */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              {t.applicationSteps}
            </h4>
            <div className="space-y-2.5">
              {(lang === 'hi' ? scheme.howToApplyStepsHindi : scheme.howToApplySteps).map((step, idx) => (
                <div key={idx} className="flex items-start gap-3 text-xs text-slate-700">
                  <div className="w-6 h-6 rounded-full bg-blue-900 text-white font-bold flex items-center justify-center shrink-0 text-[11px]">
                    {idx + 1}
                  </div>
                  <div className="pt-0.5 flex-1">
                    <p className="leading-relaxed">{step}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Training / Deadline details if available */}
          {scheme.trainingDetails && (
            <div className="p-3.5 rounded-xl bg-slate-100 text-xs text-slate-800 space-y-1">
              <span className="font-bold block">
                {lang === 'hi' ? 'प्रशिक्षण विवरण:' : 'Training Details:'}
              </span>
              <p>{scheme.trainingDetails}</p>
            </div>
          )}

          {/* Section 6: Official Source Priority */}
          <div className="p-4 rounded-2xl border border-blue-200 bg-blue-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <span className="font-bold text-blue-950 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-blue-900" />
                {scheme.officialSource.name}
              </span>
              <span className="text-slate-600 block">
                {scheme.officialSource.department}
              </span>
              <span className="text-[11px] text-slate-500">
                {lang === 'hi' ? 'अंतिम सत्यापित तिथि: ' : 'Verified on: '}
                {scheme.lastVerifiedDate}
              </span>
            </div>

            <a
              href={scheme.officialSource.url}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-4 rounded-xl bg-blue-900 hover:bg-blue-800 text-white font-semibold flex items-center justify-center gap-1.5 transition-colors shrink-0 shadow-sm"
            >
              <span>{t.officialWebsite}</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="p-4 px-6 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={handlePrint}
            className="py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-white transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>{lang === 'hi' ? 'दस्तावेज़ चेकलिस्ट प्रिंट करें' : 'Print Checklist'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleSave(scheme.id, scheme.isExam)}
              className="py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-white transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {isSaved ? <BookmarkCheck className="w-4 h-4 text-amber-600 fill-amber-600" /> : <Bookmark className="w-4 h-4" />}
              <span>{isSaved ? t.saved : t.save}</span>
            </button>
            <button
              onClick={onClose}
              className="py-2.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
