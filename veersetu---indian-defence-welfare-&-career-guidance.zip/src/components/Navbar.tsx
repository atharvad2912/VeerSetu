import React, { useState } from 'react';
import { VeerEmblem } from './VeerEmblem';
import { UserProfile, Language, UserCategory } from '../types';
import { translations } from '../data/translations';
import { User, LogIn, LogOut, Globe, Bookmark, Bell, Search, Shield, Menu, X, Settings } from 'lucide-react';

interface NavbarProps {
  user: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onOpenProfile: () => void;
  onOpenAdmin: () => void;
  lang: Language;
  onSelectLang: (l: Language) => void;
  activeView: 'home' | 'search' | 'saved' | 'notices' | 'profile';
  onChangeView: (view: 'home' | 'search' | 'saved' | 'notices' | 'profile') => void;
  savedCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onOpenAuth,
  onLogout,
  onOpenProfile,
  onOpenAdmin,
  lang,
  onSelectLang,
  activeView,
  onChangeView,
  savedCount
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = translations[lang] || translations.en;

  const categoryLabel = (cat: UserCategory) => {
    switch (cat) {
      case 'serving':
        return lang === 'hi' ? 'सेवारत सैनिक' : 'Serving Personnel';
      case 'veteran':
        return lang === 'hi' ? 'पूर्व सैनिक' : 'Ex-Servicemen';
      case 'candidate':
        return lang === 'hi' ? 'इच्छुक अभ्यर्थी' : 'Aspiring Candidate';
      case 'shaheed_family':
        return lang === 'hi' ? 'शहीद परिवार' : 'Shaheed Family';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar Contract: 3 zones separated by gap-8 */}
        <div className="flex items-center justify-between gap-8 h-16">
          {/* ZONE 1: Single text element wordmark */}
          <div
            onClick={() => onChangeView('home')}
            className="flex items-center gap-3 cursor-pointer shrink-0"
          >
            <VeerEmblem size={38} />
            <div className="flex flex-col">
              <span className="text-lg font-black tracking-wider text-slate-900 whitespace-nowrap">
                VEER<span className="text-amber-600">SETU</span>
              </span>
              <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-tight -mt-0.5">
                {t.shortTagline}
              </span>
            </div>
          </div>

          {/* ZONE 2: 4-5 concise single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
            <button
              onClick={() => onChangeView('home')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'home' ? 'text-blue-900 border-b-2 border-blue-900 pb-0.5' : ''
              }`}
            >
              {t.navHome}
            </button>

            <button
              onClick={() => onChangeView('search')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                activeView === 'search' ? 'text-blue-900 border-b-2 border-blue-900 pb-0.5' : ''
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>{t.navSearch}</span>
            </button>

            <button
              onClick={() => onChangeView('saved')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                activeView === 'saved' ? 'text-blue-900 border-b-2 border-blue-900 pb-0.5' : ''
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>{t.navSaved}</span>
              {savedCount > 0 && (
                <span className="text-[10px] bg-amber-500 text-white font-bold px-1.5 py-0.2 rounded-full">
                  {savedCount}
                </span>
              )}
            </button>

            <button
              onClick={() => onChangeView('notices')}
              className={`hover:text-blue-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5 ${
                activeView === 'notices' ? 'text-blue-900 border-b-2 border-blue-900 pb-0.5' : ''
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span>{t.navNotifications}</span>
            </button>

            <button
              onClick={onOpenAdmin}
              className="text-slate-500 hover:text-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer text-xs flex items-center gap-1"
              title="Admin Content Management"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>{t.navAdmin}</span>
            </button>
          </nav>

          {/* ZONE 3: 1 primary action / user zone */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Language Switcher */}
            <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-xs">
              <button
                onClick={() => onSelectLang('en')}
                className={`py-1 px-2.5 rounded-md font-semibold transition-colors cursor-pointer ${
                  lang === 'en' ? 'bg-white text-blue-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => onSelectLang('hi')}
                className={`py-1 px-2.5 rounded-md font-semibold transition-colors cursor-pointer ${
                  lang === 'hi' ? 'bg-white text-blue-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                हिंदी
              </button>
            </div>

            {user ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenProfile}
                  className="flex items-center gap-2 py-1.5 px-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-colors text-xs text-left cursor-pointer"
                >
                  <div className="w-6 h-6 rounded-full bg-blue-900 text-white flex items-center justify-center font-bold text-[10px]">
                    {user.fullName.charAt(0)}
                  </div>
                  <div className="hidden sm:block">
                    <span className="font-bold text-slate-800 block truncate max-w-[120px]">
                      {user.fullName}
                    </span>
                    <span className="text-[10px] text-amber-700 font-semibold block">
                      {categoryLabel(user.category)}
                    </span>
                  </div>
                </button>

                <button
                  onClick={onLogout}
                  className="p-2 text-slate-400 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="py-2 px-4 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-xl transition-colors whitespace-nowrap shadow-sm cursor-pointer flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{t.login} / {t.register}</span>
              </button>
            )}

            {/* Mobile menu hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-2">
          <button
            onClick={() => {
              onChangeView('home');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl text-sm font-semibold text-slate-800 hover:bg-slate-100"
          >
            {t.navHome}
          </button>
          <button
            onClick={() => {
              onChangeView('search');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl text-sm font-semibold text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>{t.navSearch}</span>
            <Search className="w-4 h-4 text-slate-400" />
          </button>
          <button
            onClick={() => {
              onChangeView('saved');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl text-sm font-semibold text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>{t.navSaved}</span>
            {savedCount > 0 && (
              <span className="text-xs bg-amber-500 text-white font-bold px-2 py-0.5 rounded-full">
                {savedCount}
              </span>
            )}
          </button>
          <button
            onClick={() => {
              onChangeView('notices');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl text-sm font-semibold text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>{t.navNotifications}</span>
            <Bell className="w-4 h-4 text-slate-400" />
          </button>
          <button
            onClick={() => {
              onOpenAdmin();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2.5 px-3 rounded-xl text-sm font-semibold text-slate-800 hover:bg-slate-100 flex items-center justify-between"
          >
            <span>{t.navAdmin}</span>
            <Settings className="w-4 h-4 text-slate-400" />
          </button>

          {user ? (
            <div className="pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  onChangeView('profile');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left py-2.5 px-3 rounded-xl text-sm font-bold text-blue-900 hover:bg-blue-50"
              >
                {t.navProfile} ({user.fullName})
              </button>
            </div>
          ) : (
            <div className="pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  onOpenAuth();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-blue-900 text-white font-semibold text-sm text-center"
              >
                {t.login} / {t.register}
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
