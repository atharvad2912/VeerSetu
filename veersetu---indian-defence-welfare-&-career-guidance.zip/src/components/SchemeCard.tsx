import React from 'react';
import { SchemeOrExam, UserProfile } from '../types';
import { evaluateEligibility } from '../services/eligibilityEngine';
import { ExternalLink, Bookmark, BookmarkCheck, Calendar, ShieldCheck, ArrowRight, Building2, CheckCircle2, AlertTriangle, XCircle, HelpCircle } from 'lucide-react';

interface SchemeCardProps {
  scheme: SchemeOrExam;
  user: UserProfile | null;
  onOpenDetails: (scheme: SchemeOrExam) => void;
  onToggleSave: (id: string, isExam: boolean) => void;
  isSaved: boolean;
  lang: 'en' | 'hi' | 'mr';
}

export const SchemeCard: React.FC<SchemeCardProps> = ({
  scheme,
  user,
  onOpenDetails,
  onToggleSave,
  isSaved,
  lang
}) => {
  const evaluation = evaluateEligibility(scheme, user);

  // Status badge config
  const getStatusBadge = () => {
    switch (evaluation.status) {
      case 'potentially_eligible':
        return {
          icon: CheckCircle2,
          text: lang === 'hi' ? 'संभावित रूप से पात्र' : 'Potentially Eligible',
          container: 'text-emerald-700 bg-emerald-50 border-emerald-200'
        };
      case 'may_become_eligible':
        return {
          icon: AlertTriangle,
          text: lang === 'hi' ? 'पात्र हो सकते हैं' : 'May Become Eligible',
          container: 'text-amber-800 bg-amber-50 border-amber-200'
        };
      case 'not_eligible':
        return {
          icon: XCircle,
          text: lang === 'hi' ? 'वर्तमान में पात्र नहीं' : 'Currently Not Eligible',
          container: 'text-rose-700 bg-rose-50 border-rose-200'
        };
      default:
        return {
          icon: HelpCircle,
          text: lang === 'hi' ? 'अधिक जानकारी आवश्यक' : 'More Info Required',
          container: 'text-slate-700 bg-slate-100 border-slate-200'
        };
    }
  };

  const badge = getStatusBadge();
  const StatusIcon = badge.icon;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 hover:border-slate-300 shadow-sm hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group">
      <div className="p-5 sm:p-6 pb-4">
        {/* Category & Status Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="text-blue-900 font-bold tracking-wide">
              {scheme.category}
            </span>
            <span aria-hidden="true">·</span>
            <span>{scheme.isExam ? 'Recruitment Entry' : 'Welfare Benefit'}</span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1 text-[11px] text-slate-400">
              <Calendar className="w-3 h-3" />
              {scheme.lastVerifiedDate}
            </span>
          </div>

          <button
            onClick={() => onToggleSave(scheme.id, scheme.isExam)}
            className={`p-2 rounded-lg transition-colors cursor-pointer ${
              isSaved
                ? 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
            title={isSaved ? 'Saved to bookmarks' : 'Save for later'}
            aria-label="Bookmark"
          >
            {isSaved ? <BookmarkCheck className="w-4 h-4 fill-amber-600" /> : <Bookmark className="w-4 h-4" />}
          </button>
        </div>

        {/* Scheme / Exam Title */}
        <h3
          onClick={() => onOpenDetails(scheme)}
          className="text-base sm:text-lg font-bold text-slate-900 leading-snug group-hover:text-blue-900 cursor-pointer transition-colors mb-2"
        >
          {lang === 'hi' ? scheme.nameHindi : scheme.name}
        </h3>

        {/* Target Audience / Who can benefit */}
        <p className="text-xs text-slate-600 line-clamp-2 mb-3">
          <span className="font-semibold text-slate-800">
            {lang === 'hi' ? 'लाभार्थी: ' : 'Who can benefit: '}
          </span>
          {lang === 'hi' ? scheme.targetAudienceHindi : scheme.targetAudience}
        </p>

        {/* Potential Benefit Highlight */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs mb-4">
          <span className="font-bold text-amber-800 uppercase tracking-wider block mb-1">
            {lang === 'hi' ? 'संभावित लाभ / पद' : 'Potential Benefit / Rank'}
          </span>
          <p className="text-slate-800 font-medium line-clamp-2">
            {lang === 'hi' ? scheme.potentialBenefitHindi : scheme.potentialBenefit}
          </p>
        </div>

        {/* Rule-based Status Indicator with Explanation */}
        <div className={`p-3 rounded-xl border flex items-start gap-2.5 text-xs mb-3 ${badge.container}`}>
          <StatusIcon className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold block">{badge.text}</span>
            <p className="text-[11px] mt-0.5 opacity-90 line-clamp-2">
              {lang === 'hi' ? evaluation.summaryHindi : evaluation.summary}
            </p>
          </div>
        </div>

        {/* Official Source & Verification */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
          <span className="flex items-center gap-1.5 truncate">
            <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate">{scheme.officialSource.name}</span>
          </span>
          <span className="font-semibold text-slate-600 shrink-0">
            {scheme.status}
          </span>
        </div>
      </div>

      {/* Card Action Buttons Footer */}
      <div className="px-5 py-3.5 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between gap-2">
        <button
          onClick={() => onOpenDetails(scheme)}
          className="flex-1 py-2 px-3 rounded-lg bg-blue-900 hover:bg-blue-800 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <span>{lang === 'hi' ? 'पात्रता विवरण' : 'Check My Eligibility'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        <a
          href={scheme.officialSource.url}
          target="_blank"
          rel="noopener noreferrer"
          className="py-2 px-3 rounded-lg border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs transition-colors flex items-center gap-1 shrink-0"
        >
          <span>{lang === 'hi' ? 'आधिकारिक पोर्टल' : 'Official Portal'}</span>
          <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
        </a>
      </div>
    </div>
  );
};
