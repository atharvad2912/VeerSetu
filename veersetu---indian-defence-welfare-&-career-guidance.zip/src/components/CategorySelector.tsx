import React from 'react';
import { UserCategory } from '../types';
import { translations } from '../data/translations';
import { Shield, Award, GraduationCap, Heart, CheckCircle2 } from 'lucide-react';

interface CategorySelectorProps {
  selectedCategory?: UserCategory;
  onSelect: (category: UserCategory) => void;
  lang: 'en' | 'hi' | 'mr';
  isEmbedded?: boolean;
}

export const CategorySelector: React.FC<CategorySelectorProps> = ({
  selectedCategory,
  onSelect,
  lang,
  isEmbedded = false
}) => {
  const t = translations[lang] || translations.en;

  const categories = [
    {
      id: 'serving' as UserCategory,
      emoji: '🇮🇳',
      icon: Shield,
      accent: 'border-blue-700 hover:border-blue-800 text-blue-900 bg-blue-50/50',
      tagColor: 'text-blue-800 bg-blue-100',
      title: t.servingCategory,
      description: t.servingCategoryDesc,
      highlights: [
        lang === 'hi' ? 'एजीआईएफ बीमा एवं दिव्यांगता कवर' : 'AGIF Insurance & Disability Cover',
        lang === 'hi' ? 'सीईए बाल शिक्षा अनुदान' : 'Children Education Allowance (CEA)',
        lang === 'hi' ? 'सीएसडी कैंटीन व वाहन रियायत' : 'CSD Smart Card & AFD Car Quota',
        lang === 'hi' ? 'एडब्ल्यूएचओ आवास वरीयता' : 'AWHO Priority Allotments'
      ]
    },
    {
      id: 'veteran' as UserCategory,
      emoji: '🎖️',
      icon: Award,
      accent: 'border-amber-600 hover:border-amber-700 text-amber-950 bg-amber-50/50',
      tagColor: 'text-amber-800 bg-amber-100',
      title: t.veteranCategory,
      description: t.veteranCategoryDesc,
      highlights: [
        lang === 'hi' ? 'ईसीएचएस 100% कैशलेस चिकित्सा' : 'ECHS Cashless Hospital & Polyclinics',
        lang === 'hi' ? 'पीएमएसएस छात्रवृत्ति (केएसबी)' : 'Prime Minister Scholarship (PMSS)',
        lang === 'hi' ? 'डीजीआर पुनर्वास एवं स्वरोजगार' : 'DGR Resettlement & Security Agency',
        lang === 'hi' ? 'स्पर्श पेंशन एवं निर्धनता अनुदान' : 'SPARSH Pension & Indigent Grants'
      ]
    },
    {
      id: 'candidate' as UserCategory,
      emoji: '📚',
      icon: GraduationCap,
      accent: 'border-emerald-700 hover:border-emerald-800 text-emerald-950 bg-emerald-50/50',
      tagColor: 'text-emerald-800 bg-emerald-100',
      title: t.candidateCategory,
      description: t.candidateCategoryDesc,
      highlights: [
        lang === 'hi' ? 'एनडीए, सीडीएस, टीईएस प्रविष्टियां' : 'NDA, CDS, TES Official Entries',
        lang === 'hi' ? 'टीजीसी, एसएससी टेक, जेएजी व एनसीसी' : 'TGC, SSC Tech, JAG & NCC Special',
        lang === 'hi' ? 'अग्निवीर भर्ती रैलियां एवं सीईई' : 'Agniveer Rally Eligibility & CEE',
        lang === 'hi' ? 'सटीक कट-ऑफ एवं पात्रता मिलान' : 'Strict Recruitment Verification Only'
      ]
    },
    {
      id: 'shaheed_family' as UserCategory,
      emoji: '🕊️',
      icon: Heart,
      accent: 'border-purple-700 hover:border-purple-800 text-purple-950 bg-purple-50/50',
      tagColor: 'text-purple-800 bg-purple-100',
      title: t.shaheedCategory,
      description: t.shaheedCategoryDesc,
      highlights: [
        lang === 'hi' ? 'उदारीकृत पारिवारिक पेंशन (100% वेतन)' : 'Liberalised Family Pension (LFP)',
        lang === 'hi' ? 'मां भारती के सपूत युद्ध हताहत कोष' : 'AFBCWF (Maa Bharati Ke Sapoot)',
        lang === 'hi' ? 'ईसीएचएस निशुल्क आजीवन कार्ड' : '100% Free ECHS Medical Card for Life',
        lang === 'hi' ? 'अनुकंपा नियुक्ति एवं पुत्री विवाह सहायता' : 'Compassionate Job & Marriage Grant'
      ]
    }
  ];

  return (
    <div className={`w-full ${isEmbedded ? '' : 'max-w-5xl mx-auto py-6'}`}>
      <div className="text-center mb-8">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          {t.categoriesTitle}
        </h2>
        <p className="text-slate-600 text-sm mt-2 max-w-xl mx-auto">
          {lang === 'hi'
            ? 'अपनी श्रेणी चुनें। इसके आधार पर आपका पूरा डैशबोर्ड, नियम और योजनाएं व्यक्तिगत रूप से दिखाई देंगी।'
            : 'Select your category to personalize your VeerSetu dashboard, eligibility calculations, and official opportunities.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const Icon = cat.icon;

          return (
            <div
              key={cat.id}
              onClick={() => onSelect(cat.id)}
              className={`relative p-6 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between text-left ${
                isSelected
                  ? 'border-blue-900 bg-white shadow-xl ring-4 ring-blue-900/10'
                  : 'border-slate-200 bg-white hover:border-slate-400 hover:shadow-md'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl select-none" role="img" aria-label={cat.title}>
                      {cat.emoji}
                    </span>
                    <div>
                      <h3 className="text-lg font-bold text-slate-900 leading-tight">
                        {cat.title}
                      </h3>
                    </div>
                  </div>
                  {isSelected && (
                    <CheckCircle2 className="w-6 h-6 text-blue-900 shrink-0" />
                  )}
                </div>

                <p className="text-slate-600 text-sm leading-relaxed mb-4">
                  {cat.description}
                </p>

                {/* Micro checklist highlights */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-3">
                  {cat.highlights.map((h, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-xs text-slate-700">
                      <span className="text-emerald-600 font-bold">✓</span>
                      <span className="truncate">{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-blue-900">
                  {isSelected
                    ? (lang === 'hi' ? 'चयनित श्रेणी (Selected)' : 'Selected Category')
                    : (lang === 'hi' ? 'यह श्रेणी चुनें →' : 'Select This Category →')}
                </span>
                <span className="text-[11px] text-slate-500">
                  {cat.id === 'candidate' 
                    ? (lang === 'hi' ? 'केवल परीक्षाएं' : 'Recruitment Exams Only')
                    : (lang === 'hi' ? 'कल्याणकारी योजनाएं' : 'Welfare & Benefits')}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
