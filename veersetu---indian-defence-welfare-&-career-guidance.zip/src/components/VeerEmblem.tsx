import React, { useState } from 'react';

export const OFFICIAL_LOGO_SRC = '/assets/aistudio/WhatsApp_Image_2026-10-30_at_22.53.06_8daac979.jpeg';

interface VeerEmblemProps {
  size?: number;
  className?: string;
  showText?: boolean;
  variant?: 'icon' | 'full';
}

export const VeerEmblem: React.FC<VeerEmblemProps> = ({
  size = 48,
  className = '',
  showText = false,
  variant = 'icon'
}) => {
  const [imageError, setImageError] = useState(false);

  // If full logo variant is requested (e.g. for Splash or Hero branding)
  if (variant === 'full') {
    return (
      <div className={`inline-flex flex-col items-center ${className}`}>
        {!imageError ? (
          <img
            src={OFFICIAL_LOGO_SRC}
            alt="VeerSetu Official Logo - Connecting Heroes with Their Rights, Benefits & Opportunities"
            className="w-full h-auto object-contain rounded-2xl drop-shadow-xl select-none"
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="flex flex-col items-center">
            <FallbackVector size={size * 1.5} />
            <div className="mt-3 text-center">
              <span className="text-2xl font-black tracking-wider text-slate-900">
                VEER<span className="text-amber-600">SETU</span>
              </span>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Connecting Heroes with Their Rights, Benefits & Opportunities.
              </p>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Icon / Header mark variant
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {!imageError ? (
        <div
          style={{ width: size, height: size }}
          className="relative rounded-xl overflow-hidden shrink-0 border border-slate-700/30 shadow-xs bg-slate-950 flex items-center justify-center select-none"
        >
          <img
            src={OFFICIAL_LOGO_SRC}
            alt="VeerSetu Emblem"
            className="w-full h-full object-cover scale-110"
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
          />
        </div>
      ) : (
        <FallbackVector size={size} />
      )}

      {showText && (
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-extrabold tracking-wider text-slate-900 font-sans">
              VEER<span className="text-amber-600">SETU</span>
            </span>
          </div>
          <span className="text-[10px] font-semibold tracking-tight text-slate-500 uppercase">
            One Bridge. Every Veer.
          </span>
        </div>
      )}
    </div>
  );
};

// SVG Fallback Vector
const FallbackVector: React.FC<{ size: number }> = ({ size }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 120 120"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="shrink-0 drop-shadow-sm select-none"
    aria-label="VeerSetu Emblem"
  >
    <circle cx="60" cy="60" r="56" fill="#0B2545" />
    <path
      d="M 24 30 A 54 54 0 0 1 96 30"
      stroke="#FF9933"
      strokeWidth="3.5"
      strokeLinecap="round"
    />
    <circle cx="16" cy="60" r="1.5" fill="#FFFFFF" />
    <circle cx="104" cy="60" r="1.5" fill="#FFFFFF" />
    <path
      d="M 30 96 A 54 54 0 0 0 90 96"
      stroke="#138808"
      strokeWidth="3.5"
      strokeLinecap="round"
    />
    <circle cx="60" cy="56" r="28" stroke="#1D4ED8" strokeWidth="1.5" strokeOpacity="0.45" />
    <circle cx="60" cy="56" r="6" fill="#1D4ED8" fillOpacity="0.3" />
    {[0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165].map((angle) => (
      <line
        key={angle}
        x1="60"
        y1="28"
        x2="60"
        y2="84"
        stroke="#3B82F6"
        strokeWidth="0.8"
        strokeOpacity="0.35"
        transform={`rotate(${angle} 60 56)`}
      />
    ))}
    <path
      d="M 22 72 Q 60 62 98 72"
      stroke="#F8FAFC"
      strokeWidth="3.5"
      strokeLinecap="round"
    />
    <path
      d="M 22 72 Q 60 44 98 72"
      stroke="#FF9933"
      strokeWidth="2"
      strokeDasharray="2 1.5"
      fill="none"
    />
    <path d="M 32 74 L 32 46 L 36 46 L 36 74" fill="#E2E8F0" />
    <path d="M 84 74 L 84 46 L 88 46 L 88 74" fill="#E2E8F0" />
    <ellipse cx="60" cy="46" rx="4.5" ry="4" fill="#FFFFFF" />
    <path d="M 54.5 47 Q 60 44 65.5 47 Z" fill="#FF9933" />
    <path
      d="M 55 51 C 55 49 65 49 65 51 L 66 66 L 54 66 Z"
      fill="#FFFFFF"
    />
    <line x1="57" y1="66" x2="57" y2="72" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="63" y1="66" x2="63" y2="72" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
    <path
      d="M 60 20 L 61.2 23.5 L 64.8 23.5 L 61.9 25.6 L 63 29 L 60 26.8 L 57 29 L 58.1 25.6 L 55.2 23.5 L 58.8 23.5 Z"
      fill="#F59E0B"
    />
  </svg>
);
