export type UserCategory = 'serving' | 'veteran' | 'candidate' | 'shaheed_family';

export type Language = 'en' | 'hi' | 'mr';

export type EligibilityStatus = 
  | 'potentially_eligible' 
  | 'may_become_eligible' 
  | 'not_eligible' 
  | 'more_info_needed';

export interface EligibilityCriterionCheck {
  label: string;
  labelHindi: string;
  isMet: boolean | null; // null if more info needed
  detail: string;
  detailHindi: string;
}

export interface EligibilityEvaluation {
  status: EligibilityStatus;
  summary: string;
  summaryHindi: string;
  checklist: EligibilityCriterionCheck[];
}

export interface ServingDetails {
  rank: string;
  serviceCategory: 'Officer' | 'JCO' | 'Other Ranks / Agniveer';
  dateOfJoining: string;
  dateOfBirth: string;
  postingState: string;
  maritalStatus: 'Single' | 'Married' | 'Widowed';
  spouseName?: string;
  childrenCount: number;
  childrenAges: number[];
  educationLevel: string;
  hasDisability: boolean;
  isBattleCasualty: boolean;
}

export interface VeteranDetails {
  rankAtRetirement: string;
  serviceCategory: 'Officer' | 'JCO' | 'Other Ranks';
  dateOfRetirement: string;
  dateOfBirth: string;
  isPensioner: boolean;
  pensionType: 'Service' | 'Disability' | 'Family' | 'None';
  hasDisability: boolean;
  disabilityPercentage?: number;
  maritalStatus: 'Single' | 'Married' | 'Widowed';
  spouseName?: string;
  childrenCount: number;
  dependentsCount: number;
  state: string;
  district: string;
}

export interface CandidateDetails {
  dateOfBirth: string;
  gender: 'Male' | 'Female' | 'Other';
  educationLevel: '10th' | '12th Appearing' | '12th Pass' | 'Graduate Appearing' | 'Graduate Pass' | 'Post Graduate';
  class10Percentage?: number;
  class12Percentage?: number;
  class12Stream?: 'PCM' | 'PCB' | 'Commerce' | 'Arts';
  isGraduate: boolean;
  graduationDegree?: 'B.Tech/B.E.' | 'Law (LLB)' | 'MBBS' | 'B.Sc' | 'B.A.' | 'B.Com' | 'Other';
  engineeringBranch?: string;
  nccCertificate: 'None' | 'A' | 'B' | 'C';
  nccGrading?: 'A' | 'B' | 'C';
  jeeMainAppeared: boolean;
  medicalFitnessStatus: 'Fit' | 'Under Review' | 'Temporary Unfit';
}

export interface ShaheedFamilyDetails {
  relationshipToShaheed: 'Widow (Veer Nari)' | 'Son' | 'Daughter' | 'Mother' | 'Father' | 'Other Dependent';
  state: string;
  district: string;
  yearOfCasualty: number;
  deceasedRank: string;
  deceasedServiceCategory: 'Officer' | 'JCO' | 'Other Ranks';
  casualtyCategory: 'Battle Casualty (Operations)' | 'Physical Casualty' | 'Attributable Military Service';
  isWidowRemarried: boolean;
  childrenCount: number;
  childrenAges: number[];
  hasDisabledDependents: boolean;
  existingPensionStatus: 'Liberalised Family Pension' | 'Ordinary Family Pension' | 'Special Family Pension' | 'None';
}

export interface UserProfile {
  id: string;
  fullName: string;
  mobile: string;
  email?: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  state: string;
  district: string;
  category: UserCategory;
  servingDetails?: ServingDetails;
  veteranDetails?: VeteranDetails;
  candidateDetails?: CandidateDetails;
  shaheedFamilyDetails?: ShaheedFamilyDetails;
  savedSchemeIds: string[];
  savedExamIds: string[];
  notificationPreferences: {
    recruitment: boolean;
    scholarships: boolean;
    schemeUpdates: boolean;
  };
}

export type SchemeCategory = 
  | 'Financial' 
  | 'Medical' 
  | 'Education' 
  | 'Employment' 
  | 'Housing' 
  | 'Pension' 
  | 'Scholarship' 
  | 'Recruitment'
  | 'CSD / Concessions'
  | 'Disability Support'
  | 'Children & Scholarships'
  | 'Marriage & Family Support'
  | 'Insurance';

export interface EligibilityRules {
  minAge?: number;
  maxAge?: number;
  genders?: ('Male' | 'Female' | 'Other')[];
  beneficiaryTypes: UserCategory[];
  min12thPercentage?: number;
  requiredStream?: string[];
  requiresGraduation?: boolean;
  allowedDegrees?: string[];
  requiresNCC_C?: boolean;
  requiresJEE?: boolean;
  requiresPensioner?: boolean;
  requiresDisability?: boolean;
  allowedCasualtyCategories?: string[];
  allowedRelationships?: string[];
  allowedServiceCategories?: ('Officer' | 'JCO' | 'Other Ranks' | 'Other Ranks / Agniveer')[];
  states?: string[]; // empty means all India
}

export interface SchemeOrExam {
  id: string;
  name: string;
  nameHindi: string;
  category: SchemeCategory;
  beneficiaryType: UserCategory | 'all';
  isExam: boolean; // if true, it's an exam/recruitment route
  targetAudience: string;
  targetAudienceHindi: string;
  potentialBenefit: string;
  potentialBenefitHindi: string;
  rules: EligibilityRules;
  eligibilityDescription: string;
  eligibilityDescriptionHindi: string;
  requiredDocuments: string[];
  requiredDocumentsHindi: string[];
  howToApplySteps: string[];
  howToApplyStepsHindi: string[];
  officialSource: {
    name: string;
    url: string;
    department: string;
  };
  lastVerifiedDate: string;
  status: 'Active' | 'Updated' | 'Under Review' | 'Closed' | 'Archived';
  applicationDeadlineNotice?: string;
  trainingDetails?: string;
}

export interface OfficialNotification {
  id: string;
  title: string;
  titleHindi: string;
  date: string;
  deadline?: string;
  category: 'Recruitment' | 'Scholarship' | 'Welfare Update' | 'Pension Alert';
  targetCategory: UserCategory | 'all';
  sourceName: string;
  sourceUrl: string;
  isVerified: boolean;
}
